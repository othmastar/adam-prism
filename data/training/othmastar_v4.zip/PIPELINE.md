# Data Pipeline — OthMastar Digital Twin

## RAW FILES (untouched, original)
```
deepseek_all_348.json     5.5 MB   → 348 conversations from DeepSeek web
gemini_othmastar.json     6.1 MB   → 413 conversations from Gemini (335 full + 78 URLs)
```

## PROCESSED (generated)
```
classified/classification.json
    → 761 conversations classified by phase + layer + filter
    → 300 DeepSeek usable + 277 Gemini usable = 577 usable

raw_training_v2/
    train.jsonl (316)  /  val.jsonl (40)  /  test.jsonl (40)
    → 396 conversation examples with roles swapped:
        assistant (training target) = engineer message
        user (context)              = AI response
    → 1199 engineer message targets, median 60 chars
```

## KNOWLEDGE BASE
```
web_research_knowledge_base.md   28 KB
    → 10 sections from web search findings (security, AI/ML, CI/CD, code review, etc.)
    → Ready to convert into training data when needed
```

## KAGGLE PACKAGES
```
othmastar_v2.zip   396 conversations
    → RAW from DeepSeek (filtered + swapped)
    → MAX_LENGTH=4096, rank=16, cosine LR

othmastar_v3.zip   599 conversations
    → v2 (584) + 15 DEEP educational (code + CVEs + fix + practice)
    → model: othmastar-v3 (Ollama, gemma4:e4b base)

othmastar_v4.zip   1799 conversations
    → v3 (599) + 1200 DEEP template-generated
    → 18 domains: Linux Kernel, C/C++ Memory Safety, Rust, Docker,
      Kubernetes, Databases, Security, System Architecture, Cloud,
      Frontend, CI/CD, Observability, AI/ML, Networking, DevOps,
      Software Engineering, Embedded Systems, Cryptography
```

## DEEP FRAMEWORK (for generated educational conversations)
```
D (Discover)  = سؤال حقيقي + سياق عملي
E (Explain)   = سبب جذري، trade-offs، كيف يشتغل
Err (Error)   = أخطاء شائعة، CVE حقيقية، misconfiguration
P (Practice)  = أدوات، خطوات حل، تحذيرات production
```

## GENERATORS
```
scripts/gen_deep_edu.py       → 15 تعليمية DEEP (يدوي)
scripts/gen_arch_deep.py      → 15 معمارية DEEP (يدوي)
scripts/gen_massive_v2.py     → 118 DEEP (نصف يدوي)
scripts/gen_massive_v3.py     → 1200 DEEP (template-based, 18 domain)
```

## HOW IT WORKS
1. Load raw JSON conversations (DeepSeek / Gemini)
2. Filter out personal/non-technical (from classification.json)
3. Clean "Thought for X" from DeepSeek responses
4. Swap roles: engineer→assistant (target), AI→user (context)
5. Generate DEEP conversations (educational / architectural / massive)
6. Convert all to JSONL format (messages + topic + tokens_est)
7. Split 88/6/6 train/val/test
8. Package as ZIP with train_lora.py + metadata.json
9. train_lora.py → QLoRA on Gemma-4-E4B-it → adapter weights
10. Merge adapter into base model via ollama
11. Model learns to generate engineer messages, not AI responses
