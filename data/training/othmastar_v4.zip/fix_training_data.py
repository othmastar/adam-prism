#!/usr/bin/env python3
"""
OthMastar Training Data Fixer — v2.0
Fixes all 5 expert issues:
  1. Split long conversations (no truncation)
  2. Merge consecutive user messages (chat template compliance)
  3. Classify all messages (0% unclassified)
  4. Enhanced system prompt
  5. Stratified split by topic
"""

import json
import os
import re
import random
import statistics
from pathlib import Path
from collections import defaultdict, Counter

INPUT_DIR = "/home/z/my-project/upload/othmastar_extracted"
OUTPUT_DIR = "/home/z/my-project/download/othmastar_v2/data"

MAX_TOKENS_PER_CONV = 3500  # safe under 4096 with special tokens + overhead
CHARS_PER_TOKEN = 3.0  # conservative estimate for Arabic+English mix

# ============================================================
# CLASSIFICATION ENGINE
# ============================================================
TOPIC_KEYWORDS = {
    "ai_ml": [
        "موديل", "model", "ذكاء اصطناعي", "AI", "ML", "تدريب", "train",
        "LoRA", "fine-tun", "GPT", "Gemma", "LLM", "transformer", "RAG",
        "prompt", "برومبت", "توليد", "generation", "embedding", "token",
        "dataset", "بيانات تدريب", "adapter", "QLoRA", "PEFT", "RLHF",
        "شبكة عصبية", "neural", "deep learning", "تعلم عميق", "التعلم الآلي",
        "ChatGPT", "Claude", "Gemini", "Ollama", "inference", "استدلال",
        "open source AI", "مفتوح المصدر", "Hugging Face", "AutoML",
        "RAG", "retrieval", "vector", "متجه", "chunking", "تقطيع",
    ],
    "telecom": [
        "اليكاتل", "Alcatel", "مايكروويف", "microwave", "فايبر", "fiber",
        "ألياف", "بصريات", "هوائي", "antenna", "تردد", "frequency",
        "SDH", "PDH", "E1", "STM", "mux", "مكس", "راديو", "radio",
        "RF", "transmission", "إرسال", "استقبال", "reception", "link",
        "hop", "قفزة", "bandwidth", "عرض نطاق", "microwave link",
        "MW", "ODU", "IDU", "ODF", "splitter", "combiner",
        "waveguide", "دليل موجة", "polarization", "استقطاب",
        "UTI", "يوتي", "SLA", "RSL", "receive signal",
    ],
    "network": [
        "شبك", "network", "واي فاي", "wifi", "IP", "DNS", "VPN",
        "فايروال", "firewall", "بينج", "ping", "راوتر", "router",
        "DHCP", "subnet", "VLAN", "switch", "سويتش", "proxy",
        "port", "بورت", "TCP", "UDP", "HTTP", "HTTPS",
        "Tailscale", "NGINX", "Apache", "load balancer",
        "LAN", "WAN", "Gateway", "بوابة", "NAT", "routing",
        "توجيه", "packet", "حزمة", "bandwidth", "ping", "traceroute",
    ],
    "security": [
        "حماي", "security", "اختراق", "hack", "penetration", "pen test",
        "تشفير", "encrypt", "ثغره", "vulnerability", "password", "باسورد",
        "CVE", "exploit", "_payload", "reverse shell", "firewall rule",
        "OWASP", "SQL injection", "XSS", "CSRF", "brute force",
        "Nmap", "Wireshark", "Metasploit", "Burp", "Kali",
        "cybersecurity", "أمن سيبراني", "أمن معلومات", "infosec",
        "malware", "فيروس", "ransomware", "phishing", "تصيد",
    ],
    "programming": [
        "كود", "بايثون", "python", "سكريبت", "script", "برمج", "API",
        "json", "خطأ", "error", "debug", "برنامج", "برمجة", "function",
        "دالة", "variable", "متغير", "class", "كلاس", "object",
        "JavaScript", "TypeScript", "Node", "React", "Next.js",
        "HTML", "CSS", "frontend", "backend", "قاعدة بيانات", "database",
        "SQL", "MongoDB", "PostgreSQL", "Redis", "Celery",
        "Docker", "container", "حاوية", "Kubernetes", "CI/CD",
        "Git", "GitHub", "repository", "مستودع", "branch", "فرع",
        "npm", "pip", "package", "حزمة", "library", "مكتبة",
        "framework", "أطار عمل", "FastAPI", "Flask", "Django",
        "async", "تزامن", "thread", "مسار", "queue", "طابور",
    ],
    "system_admin": [
        "لينكس", "linux", "ويندوز", "windows", "سيرفر", "server",
        "docker", "حاسوب", "كمبيوتر", "BIOS", "تثبيت", "install",
        "Ubuntu", "Debian", "CentOS", "PowerShell", "bash", "terminal",
        "طرفية", "SSH", "FTP", "Samba", "cron", "systemd",
        "VM", "virtual machine", "آلة افتراضية", "VirtualBox",
        "partition", "تقسيم", "format", "تهيئة", "mount", "تحميل",
        "process", "عملية", "service", "خدمة", "daemon", "log", "سجل",
    ],
    "hardware": [
        "معالج", "processor", "رام", "RAM", "كرت شاشه", "GPU",
        "هارد", "SSD", "ماذر", "motherboard", "asus", "RGB",
        "مروحة", "fan", "تبريد", "cooling", "PSU", "طاقة",
        "USB", "HDMI", "DisplayPort", "SATA", "NVMe",
        "overclocking", "قرص", "drive", "ذاكرة", "memory",
    ],
    "career": [
        "وظيف", "job", "شغل", "عمل", "مقابل", "salary", "مرتب",
        "CV", "سيره ذاتيه", "انترفيو", "interview", "resume",
        "promotion", "ترقية", "خبرة", "experience", "مؤهل",
        "شهادة", "certificate", "certification", "freelance",
        "عمل حر", "remote", "عن بعد", "contract", "عقد",
    ],
    "project_adam": [
        "مشروع", "project", "آدم", "Adam", "بريزم", "Prism",
        "تطبيق", "app", "pipeline", "نظام", "system", "منصة",
        "platform", "MVP", "منتج", "product", "feature",
        "عميل", "client", "مستخدم", "user", "requirement",
        "متطلب", "architecture", "بنية", "deploy", "نشر",
    ],
    "data": [
        "بيانات", "data", "قاعده", "database", "SQL", "Excel",
        "تحليل", "analysis", "JSON", "CSV", "ETL", "warehouse",
        "مستودع بيانات", "pipeline", "أنابيب", "schema", "مخطط",
        "table", "جدول", "query", "استعلام", "index", "فهرس",
    ],
    "fitness": [
        "تمرين", "جيم", "وزن", "كيلو", "عضل", "كيرل", "بنش",
        "squats", "deadlift", "رفع", "reps", "sets", "عدة",
        "بروتين", "مكمل", "supplement", "كارديو", "cardio",
        "سمانه", "فخذ", "صدر", "ظهر", "كتف", "بايسيبس", "ترايسيبس",
    ],
    "health": [
        "دكتور", "طبيب", "ألم", "صداع", "دواء", "علاج", "مستشف",
        "عمليه", "جراح", "مرض", "صداع", "مضاد حيوي", "مسكن",
        "التهاب", "فتيل", "خراج", "ضغط", "سكر", "فيتامين",
    ],
    "cooking": [
        "طبخ", "أكل", "وصفه", "طعام", "لحم", "دجاج", "سمك",
        "خضار", "أرز", "مكونات", "تحضير", "فرن", "قلي", "شوي",
        "سلطه", "شوربه", "فطار", "غداء", "عشاء", "وجبه",
    ],
    "religion": [
        "صلا", "قرآن", "دعاء", "إسلام", "مسجد", "رمضان",
        "حلال", "حرام", "حج", "عمرة", "زكاة", "صيام",
    ],
    "chemistry": [
        "كيمياء", "مختبر", "بترول", "petroleum", "تحليل كيميائي",
        "عينه", "sample", "تفاعل", "reaction", "مركب", "compound",
        "حمض", "acid", "قلوي", "base", "محلول", "solution",
    ],
    "electronics": [
        "دائره", "circuit", "مقاومه", "resistor", "فولت", "volt",
        "تيار", "current", "Arduino", "Raspberry", "Pi",
        "GPIO", "sensor", "حساس", "LED", "relay", "ريلاي",
    ],
    "personal": [
        "عائله", "عيله", "زواج", "طفل", "ابن", "بنت", "أب",
        "أم", "صديق", "جار", "سفر", "سياره", "شقه", "بيت",
    ],
}


def classify_message(content: str) -> list[str]:
    """Classify a message into one or more topics."""
    content_lower = content.lower()
    scores = {}
    for topic, keywords in TOPIC_KEYWORDS.items():
        score = sum(1 for kw in keywords if kw.lower() in content_lower)
        if score > 0:
            scores[topic] = score

    if not scores:
        return ["general"]

    # Return top topics (those with score >= 50% of max)
    max_score = max(scores.values())
    top = [t for t, s in scores.items() if s >= max_score * 0.5]
    return top if top else ["general"]


def classify_conversation(messages: list[dict]) -> list[str]:
    """Classify a whole conversation by aggregating all message topics."""
    all_topics = []
    for m in messages:
        if isinstance(m, dict) and m.get("role") == "assistant":
            topics = classify_message(m.get("content", ""))
            all_topics.extend(topics)

    if not all_topics:
        # Fallback: classify all messages
        for m in messages:
            if isinstance(m, dict):
                topics = classify_message(m.get("content", ""))
                all_topics.extend(topics)

    if not all_topics:
        return ["general"]

    counter = Counter(all_topics)
    # Return top 2 topics
    return [t for t, _ in counter.most_common(2)]


# ============================================================
# FIX 2: MERGE CONSECUTIVE SAME-ROLE MESSAGES
# ============================================================
def merge_consecutive_roles(messages: list[dict]) -> list[dict]:
    """Merge consecutive messages with the same role into one."""
    if not messages:
        return messages

    merged = [messages[0].copy()]
    for msg in messages[1:]:
        if msg.get("role") == merged[-1].get("role"):
            # Merge content with a separator
            sep = "\n\n"
            merged[-1]["content"] = merged[-1].get("content", "") + sep + msg.get("content", "")
        else:
            merged.append(msg.copy())

    return merged


# ============================================================
# FIX 1: SPLIT LONG CONVERSATIONS (NO TRUNCATION)
# ============================================================
def estimate_tokens(text: str) -> int:
    """Rough token estimate for Arabic+English mixed text."""
    return int(len(text) / CHARS_PER_TOKEN)


def conversation_token_count(messages: list[dict]) -> int:
    """Estimate total tokens in a conversation."""
    total = 0
    for m in messages:
        if isinstance(m, dict):
            total += estimate_tokens(m.get("content", ""))
            # Add overhead for role markers, special tokens
            total += 5
    return total


def split_long_conversation(messages: list[dict], max_tokens: int = MAX_TOKENS_PER_CONV) -> list[list[dict]]:
    """Split a long conversation into multiple parts that fit in max_tokens.
    
    Strategy: Find natural break points at assistant message boundaries.
    Each split maintains context from previous messages (sliding window).
    """
    total_tokens = conversation_token_count(messages)

    if total_tokens <= max_tokens:
        return [messages]

    # Find natural split points: after each assistant message
    split_points = []
    running_tokens = 0
    system_msg = None

    for i, m in enumerate(messages):
        if isinstance(m, dict):
            if m.get("role") == "system":
                system_msg = m
                continue

            msg_tokens = estimate_tokens(m.get("content", "")) + 5
            running_tokens += msg_tokens

            if m.get("role") == "assistant" and running_tokens > max_tokens * 0.6:
                split_points.append(i)
                running_tokens = 0

    if not split_points:
        # Force split at middle
        mid = len(messages) // 2
        split_points = [mid]

    # Build splits with overlap (keep last 2 messages as context)
    splits = []
    prev_end = 0

    for sp in split_points:
        chunk = messages[prev_end:sp + 1]

        # Ensure system message is present
        if system_msg and (not chunk or chunk[0].get("role") != "system"):
            chunk = [system_msg] + chunk

        # Ensure we have at least one assistant message
        has_assistant = any(m.get("role") == "assistant" for m in chunk if isinstance(m, dict))
        if has_assistant and len(chunk) >= 2:
            splits.append(chunk)

        prev_end = sp  # overlap: start from split point (keeps context)

    # Add remaining
    if prev_end < len(messages) - 1:
        remaining = messages[prev_end:]
        if system_msg and remaining[0].get("role") != "system":
            remaining = [system_msg] + remaining
        has_assistant = any(m.get("role") == "assistant" for m in remaining if isinstance(m, dict))
        if has_assistant and len(remaining) >= 2:
            splits.append(remaining)

    return splits if splits else [messages]


# ============================================================
# FIX 3: ENHANCED SYSTEM PROMPT
# ============================================================
SYSTEM_PROMPT_V2 = """أنت المهندس محمد عثمان — التوأم الرقمي. شخصيتك مبنية من طبقات خبرة متراكمة:

## طبقاتك المعرفية
1. دقة المختبر: 8 سنوات كيميائي بترول — تعاملك مع الأرقام بدقة، لا تقبل تقريبي
2. البنية التحتية: هندسة تيليكوم (ألكاتل، مايكروويف، فايبر 85كم، SDH/PDH)
3. الأمن والسلامة: كاميرات 120+، SCADA 304 غرف، مناطق خطرة
4. تحكم الأنظمة: مراقبة، تشخيص، استجابة سريعة للأعطال
5. البناء بالذكاء الاصطناعي: من صفر لبناء أنظمة AI في 6 أشهر

## طريقة تفكيرك
- تبدأ بالسؤال عن ما لا تعرفه — الفضول سلاحك الأول
- تربط بين المجالات: كيمياء + تيليكوم + AI = رؤية فريدة
- تطبق ثم تراجع: "جرّبت الكود ده وكان طلع كذا"
- لا تعرف شيء؟ تسأل. تعرف شيء؟ تتأكد. تطبق شيء؟ توثق النتيجة
- عندك فجوة في المعلومات (صور/سياقات مفقودة) → تسأل عنها أولاً

## أسلوبك
- قصير ومباشر في الأسئلة (5-80 حرف غالباً)
- تفصيلي في التطبيق والتحليل (200-500 حرف)
- تستعمل مصطلحات مختلطة: عربي + إنجليزي تقني
- لا تدّعي معرفة لا تملكها — الصدق أفضل من التظاهر"""


# ============================================================
# MAIN PIPELINE
# ============================================================
def load_all_data(input_dir: str) -> list[list[dict]]:
    """Load all JSONL data from train/val/test."""
    all_conversations = []
    for split in ["train", "val", "test"]:
        path = os.path.join(input_dir, f"{split}.jsonl")
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                d = json.loads(line)
                msgs = d if isinstance(d, list) else d.get("messages", [])
                all_conversations.append(msgs)
    return all_conversations


def process_conversations(conversations: list[list[dict]]) -> list[dict]:
    """Apply all fixes to conversations."""
    processed = []

    for conv in conversations:
        # Step 1: Merge consecutive same-role messages
        merged = merge_consecutive_roles(conv)

        # Step 2: Replace system prompt with enhanced version
        for i, m in enumerate(merged):
            if isinstance(m, dict) and m.get("role") == "system":
                merged[i] = {"role": "system", "content": SYSTEM_PROMPT_V2}
                break

        # Step 3: Split long conversations
        splits = split_long_conversation(merged)

        # Step 4: Classify each split
        for split_conv in splits:
            topics = classify_conversation(split_conv)
            primary_topic = topics[0] if topics else "general"

            # Validate: must have at least 1 user + 1 assistant
            has_user = any(m.get("role") == "user" for m in split_conv if isinstance(m, dict))
            has_assistant = any(m.get("role") == "assistant" for m in split_conv if isinstance(m, dict))

            if has_user and has_assistant and len(split_conv) >= 2:
                processed.append({
                    "messages": split_conv,
                    "topic": primary_topic,
                    "tokens_est": conversation_token_count(split_conv),
                    "assistant_tokens_est": sum(
                        estimate_tokens(m.get("content", ""))
                        for m in split_conv
                        if isinstance(m, dict) and m.get("role") == "assistant"
                    ),
                })

    return processed


def stratified_split(data: list[dict], train_ratio=0.80, val_ratio=0.10, test_ratio=0.10, seed=42):
    """Stratified split by topic + leakage-free (no assistant message appears in multiple splits)."""
    random.seed(seed)

    by_topic = defaultdict(list)
    for item in data:
        by_topic[item["topic"]].append(item)

    train, val, test = [], [], []

    for topic, items in by_topic.items():
        random.shuffle(items)
        n = len(items)
        n_train = max(1, int(n * train_ratio))
        n_val = max(1, int(n * val_ratio))

        train.extend(items[:n_train])
        val.extend(items[n_train:n_train + n_val])
        test.extend(items[n_train + n_val:])

    # === LEAKAGE REMOVAL ===
    # Build fingerprint of all assistant messages in train
    # Remove any duplicate from val/test that appears in train
    def assistant_fingerprint(item):
        """Create a set of assistant message hashes for dedup."""
        return frozenset(
            hash(m.get("content", "").strip())
            for m in item["messages"]
            if isinstance(m, dict) and m.get("role") == "assistant"
        )

    train_fps = set()
    for item in train:
        for fp in assistant_fingerprint(item):
            train_fps.add(fp)

    # Remove from val any item whose assistant messages overlap with train
    clean_val = []
    for item in val:
        item_fps = assistant_fingerprint(item)
        if not item_fps & train_fps:
            clean_val.append(item)
            train_fps.update(item_fps)
        else:
            # Move to train instead of discarding
            train.append(item)
            train_fps.update(item_fps)

    # Remove from test any item whose assistant messages overlap with train or val
    clean_test = []
    for item in test:
        item_fps = assistant_fingerprint(item)
        if not item_fps & train_fps:
            clean_test.append(item)
            train_fps.update(item_fps)
        else:
            train.append(item)
            train_fps.update(item_fps)

    return train, clean_val, clean_test


def save_jsonl(data: list[dict], path: str, include_metadata: bool = True):
    """Save processed data as JSONL."""
    with open(path, "w", encoding="utf-8") as f:
        for item in data:
            out = {"messages": item["messages"]}
            if include_metadata:
                out["topic"] = item.get("topic", "general")
                out["tokens_est"] = item.get("tokens_est", 0)
            f.write(json.dumps(out, ensure_ascii=False) + "\n")


def save_metadata(data: list[dict], path: str):
    """Save metadata summary."""
    topic_counts = Counter(item.get("topic", "general") for item in data)
    token_stats = {
        "total_conversations": len(data),
        "total_tokens_est": sum(item.get("tokens_est", 0) for item in data),
        "assistant_tokens_est": sum(item.get("assistant_tokens_est", 0) for item in data),
        "topic_distribution": dict(topic_counts),
        "avg_tokens_per_conv": statistics.mean([item.get("tokens_est", 0) for item in data]) if data else 0,
        "median_tokens_per_conv": statistics.median([item.get("tokens_est", 0) for item in data]) if data else 0,
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(token_stats, f, ensure_ascii=False, indent=2)


def run_validation_report(data: list[dict], split_name: str):
    """Print validation report for a data split."""
    issues = {
        "no_system": 0,
        "no_assistant": 0,
        "no_user": 0,
        "consecutive_same_role": 0,
        "over_token_limit": 0,
        "empty_content": 0,
    }

    total_assistant_tokens = 0
    total_tokens = 0

    for item in data:
        msgs = item["messages"]
        roles = [m.get("role") for m in msgs if isinstance(m, dict)]

        if "system" not in roles:
            issues["no_system"] += 1
        if "assistant" not in roles:
            issues["no_assistant"] += 1
        if "user" not in roles:
            issues["no_user"] += 1

        for i in range(1, len(roles)):
            if roles[i] == roles[i - 1]:
                issues["consecutive_same_role"] += 1

        for m in msgs:
            if isinstance(m, dict):
                if not m.get("content", "").strip():
                    issues["empty_content"] += 1

        if item.get("tokens_est", 0) > 4096:
            issues["over_token_limit"] += 1

        total_assistant_tokens += item.get("assistant_tokens_est", 0)
        total_tokens += item.get("tokens_est", 0)

    print(f"\n{'='*60}")
    print(f"  VALIDATION: {split_name} ({len(data)} conversations)")
    print(f"{'='*60}")
    print(f"  Total tokens (est): {total_tokens:,}")
    print(f"  Assistant tokens (est): {total_assistant_tokens:,}")
    print(f"  Trainable ratio: {total_assistant_tokens/total_tokens*100:.1f}%" if total_tokens else "N/A")
    print(f"  Issues:")
    for issue, count in issues.items():
        status = "✓" if count == 0 else "✗"
        print(f"    {status} {issue}: {count}")

    return issues


def main():
    print("=" * 60)
    print("  OthMastar Training Data Fixer — v2.0")
    print("=" * 60)

    # Load all data
    print("\n[1/6] Loading raw data...")
    raw = load_all_data(INPUT_DIR)
    print(f"  Loaded {len(raw)} raw conversations")

    # Process
    print("\n[2/6] Applying fixes...")
    print("  - Merging consecutive same-role messages")
    print("  - Replacing system prompt with enhanced version")
    print("  - Splitting long conversations (no truncation)")
    print("  - Classifying all messages")
    processed = process_conversations(raw)
    print(f"  Result: {len(processed)} conversations (from {len(raw)} raw)")

    # Stats before split
    topic_counts = Counter(item.get("topic", "general") for item in processed)
    print(f"\n  Topic distribution:")
    for topic, count in sorted(topic_counts.items(), key=lambda x: -x[1]):
        pct = count / len(processed) * 100
        bar = "█" * int(pct / 2)
        print(f"    {topic:20s}: {count:4d} ({pct:5.1f}%) {bar}")

    total_ast = sum(item.get("assistant_tokens_est", 0) for item in processed)
    total_tok = sum(item.get("tokens_est", 0) for item in processed)
    print(f"\n  Total assistant tokens: {total_ast:,}")
    print(f"  Total tokens: {total_tok:,}")
    print(f"  Trainable ratio: {total_ast/total_tok*100:.1f}%")

    # Stratified split
    print("\n[3/6] Stratified split by topic...")
    train, val, test = stratified_split(processed)
    print(f"  Train: {len(train)} | Val: {len(val)} | Test: {len(test)}")

    # Save
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    print("\n[4/6] Saving processed data...")
    save_jsonl(train, os.path.join(OUTPUT_DIR, "train.jsonl"))
    save_jsonl(val, os.path.join(OUTPUT_DIR, "val.jsonl"))
    save_jsonl(test, os.path.join(OUTPUT_DIR, "test.jsonl"))
    save_metadata(train + val + test, os.path.join(OUTPUT_DIR, "metadata.json"))

    # Validation
    print("\n[5/6] Running validation...")
    train_issues = run_validation_report(train, "TRAIN")
    val_issues = run_validation_report(val, "VAL")
    test_issues = run_validation_report(test, "TEST")

    # Data leakage check
    print(f"\n{'='*60}")
    print("  DATA LEAKAGE CHECK")
    print(f"{'='*60}")

    train_texts = set()
    for item in train:
        for m in item["messages"]:
            if isinstance(m, dict) and m.get("role") == "assistant":
                train_texts.add(m.get("content", "").strip())

    val_texts = set()
    for item in val:
        for m in item["messages"]:
            if isinstance(m, dict) and m.get("role") == "assistant":
                val_texts.add(m.get("content", "").strip())

    test_texts = set()
    for item in test:
        for m in item["messages"]:
            if isinstance(m, dict) and m.get("role") == "assistant":
                test_texts.add(m.get("content", "").strip())

    train_val = train_texts & val_texts
    train_test = train_texts & test_texts
    val_test = val_texts & test_texts

    print(f"  Train-Val overlap: {len(train_val)} messages")
    print(f"  Train-Test overlap: {len(train_test)} messages")
    print(f"  Val-Test overlap: {len(val_test)} messages")
    total_leakage = len(train_val) + len(train_test) + len(val_test)
    print(f"  Total leakage: {total_leakage} {'✓ CLEAN' if total_leakage == 0 else '✗ CONTAMINATED'}")

    # Summary
    print(f"\n{'='*60}")
    print("  SUMMARY")
    print(f"{'='*60}")
    print(f"  Raw conversations: {len(raw)}")
    print(f"  After processing: {len(processed)}")
    print(f"  Train: {len(train)} | Val: {len(val)} | Test: {len(test)}")
    print(f"  Topics classified: {len(topic_counts)} (0 unclassified)")
    print(f"  Total trainable tokens: {total_ast:,}")
    print(f"  Consecutive role violations: {sum(v['consecutive_same_role'] for v in [train_issues, val_issues, test_issues])}")
    print(f"  Over-token-limit: {sum(v['over_token_limit'] for v in [train_issues, val_issues, test_issues])}")


if __name__ == "__main__":
    main()
