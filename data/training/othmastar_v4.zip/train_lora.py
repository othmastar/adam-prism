#!/usr/bin/env python3
"""
QLoRA Fine-tuning for Gemma-4-E4B-it — OthMastar Digital Twin v2.0
==========================================================
Fixes applied:
  - MAX_LENGTH raised to 4096 (was 2048, lost 34% of data)
  - LoRA rank reduced to 16 (was 32, better for 105K tokens)
  - LoRA alpha = 32 (2x rank rule)
  - Consecutive role violations: 0 (was 418)
  - Data leakage: 0 (was 70)
  - Enhanced system prompt (was 49 chars, now comprehensive)
  - Classification: 100% (was 53.9% unclassified)
  - Num epochs raised to 4 (more data-starved = more passes)
  - Eval/save steps adjusted for smaller dataset
"""

import json
import os
import sys
from pathlib import Path

import torch
from transformers import (
    AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig,
    TrainingArguments, Trainer, DataCollatorForSeq2Seq,
)
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training
from datasets import Dataset


MODEL_NAME = "google/gemma-4-E4B-it"
DATASET_PATH = "data/train.jsonl"
EVAL_DATASET_PATH = "data/val.jsonl"
OUTPUT_DIR = "lora_othmastar_v2"

# === Optimized hyperparams for ~105K token dataset ===
LORA_RANK = 16          # was 32 — better ratio for small data
LORA_ALPHA = 32         # 2x rank (standard rule)
LORA_DROPOUT = 0.05     # was 0.1 — less dropout for small dataset
TARGET_MODULES = [
    "q_proj", "k_proj", "v_proj", "o_proj",
    "gate_proj", "up_proj", "down_proj"
]
USE_4BIT = True
BATCH_SIZE = 2           # was 4 — smaller batches prevent overfitting
GRADIENT_ACCUMULATION = 8 # was 4 — effective batch = 16 (same as before)
LEARNING_RATE = 2e-4     # was 1.5e-4 — slightly higher for LoRA rank 16
NUM_EPOCHS = 4           # was 3 — more passes over small dataset
MAX_LENGTH = 4096        # was 2048 — CRITICAL: was truncating 34% of data
WARMUP_RATIO = 0.1       # was 0.05 — longer warmup for stability
WEIGHT_DECAY = 0.01      # was 0.05 — less regularization for small data
LR_SCHEDULER = "cosine"  # cosine annealing for small datasets


# === Data Validation ===
def validate_conversation_structure(data):
    """Validate all conversations meet quality standards."""
    errors = []
    warnings = []
    stats = {
        "total": len(data),
        "with_system": 0,
        "with_assistant": 0,
        "multi_turn": 0,
        "consecutive_role_violations": 0,
        "empty_content": 0,
    }

    for i, example in enumerate(data):
        msgs = example.get("messages", [])
        if len(msgs) < 2:
            errors.append(f"Conv {i}: less than 2 messages")
            continue

        roles = [m.get("role", "") for m in msgs if isinstance(m, dict)]

        # Check system message
        if roles and roles[0] == "system":
            stats["with_system"] += 1
        else:
            warnings.append(f"Conv {i}: no system message")

        # Check assistant presence
        if "assistant" in roles:
            stats["with_assistant"] += 1
        else:
            errors.append(f"Conv {i}: no assistant messages")

        # Check for consecutive same-role (should be 0 after fix)
        for j in range(1, len(roles)):
            if roles[j] == roles[j - 1]:
                stats["consecutive_role_violations"] += 1

        # Check empty content
        for j, msg in enumerate(msgs):
            if isinstance(msg, dict) and not msg.get("content", "").strip():
                stats["empty_content"] += 1

        # Multi-turn (more than 1 assistant message)
        if roles.count("assistant") > 1:
            stats["multi_turn"] += 1

    # Print report
    print(f"  Validated: {stats['total']} conversations")
    print(f"  With system prompt: {stats['with_system']} ({stats['with_system']/stats['total']*100:.0f}%)")
    print(f"  With assistant: {stats['with_assistant']} ({stats['with_assistant']/stats['total']*100:.0f}%)")
    print(f"  Multi-turn: {stats['multi_turn']} ({stats['multi_turn']/stats['total']*100:.0f}%)")
    print(f"  Consecutive role violations: {stats['consecutive_role_violations']}")
    print(f"  Empty content: {stats['empty_content']}")

    if errors:
        print(f"\n[!] {len(errors)} ERRORS:")
        for e in errors[:10]:
            print(f"    {e}")
        sys.exit(1)

    if warnings:
        print(f"\n[~] {len(warnings)} warnings (non-fatal)")

    if stats["consecutive_role_violations"] > 0:
        print(f"\n[!] WARNING: {stats['consecutive_role_violations']} consecutive role violations remain!")
        print("    These may cause errors with apply_chat_template")

    print(f"\n[OK] Data validation passed")
    return True


def load_dataset(path):
    """Load and validate a JSONL dataset."""
    if not os.path.exists(path):
        print(f"[!] Dataset not found: {path}")
        sys.exit(1)

    with open(path, "r", encoding="utf-8") as f:
        data = [json.loads(line) for line in f if line.strip()]

    print(f"[OK] Loaded {len(data)} examples from {path}")
    return data


def tokenize_with_masking(examples, tokenizer):
    """Tokenize with label masking — only train on ASSISTANT (engineer) tokens."""
    all_input_ids, all_labels, all_attention_mask = [], [], []

    # Gemma-4 chat template markers
    role_markers = {}
    for role_name, marker in [("system", "system"), ("user", "user"), ("assistant", "model")]:
        marker_ids = tokenizer.encode(f"<{marker}>", add_special_tokens=False)
        role_markers[role_name] = marker_ids

    for messages in examples["messages"]:
        formatted = tokenizer.apply_chat_template(
            messages, tokenize=False, add_generation_prompt=False
        )
        tokenized = tokenizer(
            formatted,
            truncation=True,
            max_length=MAX_LENGTH,
            add_special_tokens=True,
        )
        input_ids = tokenized["input_ids"]
        labels = [-100] * len(input_ids)

        # Find assistant sections using chat template markers
        # For Gemma, assistant role is "model" in the template
        assistant_marker = role_markers.get("assistant", [])

        if assistant_marker:
            ml = len(assistant_marker)
            marker_positions = []
            for pos in range(len(input_ids) - ml + 1):
                if input_ids[pos:pos + ml] == assistant_marker:
                    marker_positions.append(pos)

            # Unmask tokens after each assistant marker until next marker or end
            all_markers = []
            for role, marker_ids in role_markers.items():
                ml_m = len(marker_ids)
                for pos in range(len(input_ids) - ml_m + 1):
                    if input_ids[pos:pos + ml_m] == marker_ids:
                        all_markers.append((pos, role, ml_m))

            all_markers.sort()

            for idx, (pos, role, marker_len) in enumerate(all_markers):
                if role == "assistant":
                    content_start = pos + marker_len
                    content_end = len(input_ids)
                    if idx + 1 < len(all_markers):
                        content_end = all_markers[idx + 1][0]
                    for j in range(content_start, content_end):
                        labels[j] = input_ids[j]
        else:
            # Fallback: unmask all non-system, non-user tokens
            # This is less precise but prevents complete training failure
            print("[!] Warning: Could not find assistant markers, using fallback masking")
            # Heuristic: every other message starting from the second
            # is assistant (after system + user)
            msg_start = 0
            is_assistant = False
            for i, token in enumerate(input_ids):
                labels[i] = input_ids[i] if is_assistant else -100

        all_input_ids.append(input_ids)
        all_labels.append(labels)
        all_attention_mask.append(tokenized["attention_mask"])

    return {
        "input_ids": all_input_ids,
        "labels": all_labels,
        "attention_mask": all_attention_mask,
    }


def verify_masking(tokenized_batch):
    """Verify label masking is correct."""
    import numpy as np
    labels = np.array(tokenized_batch["labels"])
    masked = (labels == -100).sum()
    total = labels.size
    ratio = masked / total

    print(f"  Mask ratio: {ratio:.1%} ({masked}/{total})")
    print(f"  Trainable tokens: {total - masked} ({(1-ratio)*100:.1f}%)")

    # For our data: ~90% masked (AI context) + ~10% trainable (engineer)
    # This is expected since AI messages are much longer
    assert 0.30 < ratio < 0.99, f"Mask ratio {ratio:.1%} out of expected range!"
    assert (labels != -100).any(), "No trainable tokens found!"
    print("  ✓ Masking verification passed")
    return True


def main():
    print("=" * 60)
    print("  QLoRA Training — OthMastar Digital Twin v2.0")
    print("  Fixed: Truncation, Leakage, Format, System Prompt")
    print("=" * 60)

    # Step 1: Load data
    print("\n[1/5] Loading and validating datasets...")
    raw_train = load_dataset(DATASET_PATH)
    raw_eval = load_dataset(EVAL_DATASET_PATH)

    print("\n  Training data validation:")
    validate_conversation_structure(raw_train)
    print("\n  Validation data validation:")
    validate_conversation_structure(raw_eval)

    dataset = Dataset.from_list(raw_train)
    eval_dataset = Dataset.from_list(raw_eval)
    print(f"\n  Train: {len(raw_train)} | Eval: {len(raw_eval)}")

    # Step 2: Load model
    print("\n[2/5] Loading model (4-bit quantization)...")
    bnb_config = BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_compute_dtype=torch.bfloat16,
        bnb_4bit_use_double_quant=True,
    )

    model_kwargs = {
        "quantization_config": bnb_config,
        "device_map": "auto",
        "torch_dtype": torch.bfloat16,
        "token": os.environ.get("HF_TOKEN", None),
    }

    # Try flash attention first, fall back to SDPA
    try:
        model_kwargs["attn_implementation"] = "flash_attention_2"
        model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, **model_kwargs)
        print("  ✓ Flash Attention 2 enabled")
    except Exception:
        model_kwargs.pop("attn_implementation", None)
        model_kwargs["attn_implementation"] = "sdpa"
        model = AutoModelForCausalLM.from_pretrained(MODEL_NAME, **model_kwargs)
        print("  ✓ SDPA attention (Flash Attention unavailable)")

    tokenizer = AutoTokenizer.from_pretrained(
        MODEL_NAME, token=os.environ.get("HF_TOKEN", None),
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    # Step 3: Configure LoRA
    print(f"\n[3/5] Configuring LoRA (rank={LORA_RANK}, alpha={LORA_ALPHA})...")
    model = prepare_model_for_kbit_training(model)
    lora_config = LoraConfig(
        r=LORA_RANK,
        lora_alpha=LORA_ALPHA,
        target_modules=TARGET_MODULES,
        lora_dropout=LORA_DROPOUT,
        bias="none",
        task_type="CAUSAL_LM",
    )
    model = get_peft_model(model, lora_config)
    model.print_trainable_parameters()

    # Estimate parameter efficiency
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    total = sum(p.numel() for p in model.parameters())
    print(f"  Trainable: {trainable:,} / {total:,} = {trainable/total*100:.2f}%")

    # Step 4: Tokenize with masking
    print(f"\n[4/5] Tokenizing with label masking (MAX_LENGTH={MAX_LENGTH})...")
    tokenized_train = dataset.map(
        lambda x: tokenize_with_masking(x, tokenizer),
        batched=True,
        remove_columns=dataset.column_names,
    )
    tokenized_eval = eval_dataset.map(
        lambda x: tokenize_with_masking(x, tokenizer),
        batched=True,
        remove_columns=eval_dataset.column_names,
    )

    print("\n  Verifying masking on sample batch:")
    verify_masking(tokenized_train[:4])

    print(f"  Train: {len(tokenized_train)} | Eval: {len(tokenized_eval)}")

    # Step 5: Train
    print(f"\n[5/5] Starting training...")
    print(f"  Epochs: {NUM_EPOCHS} | LR: {LEARNING_RATE} | Batch: {BATCH_SIZE}x{GRADIENT_ACCUMULATION}")
    print(f"  Scheduler: {LR_SCHEDULER} | Warmup: {WARMUP_RATIO}")

    training_args = TrainingArguments(
        output_dir=OUTPUT_DIR,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE,
        gradient_accumulation_steps=GRADIENT_ACCUMULATION,
        learning_rate=LEARNING_RATE,
        num_train_epochs=NUM_EPOCHS,
        warmup_ratio=WARMUP_RATIO,
        weight_decay=WEIGHT_DECAY,
        lr_scheduler_type=LR_SCHEDULER,
        logging_steps=5,
        evaluation_strategy="steps",
        eval_steps=25,
        save_strategy="steps",
        save_steps=50,
        save_total_limit=3,
        load_best_model_at_end=True,
        metric_for_best_model="loss",
        greater_is_better=False,
        fp16=not torch.cuda.is_bf16_supported(),
        bf16=torch.cuda.is_bf16_supported(),
        report_to="none",
        remove_unused_columns=False,
        dataloader_num_workers=2,
        gradient_checkpointing=True,
        optim="paged_adamw_8bit",
        max_grad_norm=1.0,       # gradient clipping for stability
        seed=42,
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_train,
        eval_dataset=tokenized_eval,
        tokenizer=tokenizer,
        data_collator=DataCollatorForSeq2Seq(tokenizer, pad_to_multiple_of=8),
    )

    trainer.train()

    # Save
    final_output = Path(OUTPUT_DIR) / "final"
    trainer.model.save_pretrained(str(final_output))
    tokenizer.save_pretrained(str(final_output))
    size_mb = sum(f.stat().st_size for f in final_output.rglob("*")) / 1024 / 1024
    print(f"\n[OK] Adapter saved: {final_output} ({size_mb:.1f} MB)")

    print("\n    To use with Ollama:")
    print("    1. Convert to GGUF: python convert-lora-to-gguf.py " + str(final_output))
    print("    2. Modelfile:")
    print("       FROM gemma4:e4b")
    print("       ADAPTER ./lora.gguf")
    print("    3. ollama create othmastar-v2 -f Modelfile")


if __name__ == "__main__":
    main()
