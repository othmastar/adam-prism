# Adam Prism v3 — Complete Desktop Edition

## 🎯 ما هذا؟

النسخة الكاملة من Adam Prism بـ:
- **Long-term Memory** مع vector embeddings (semantic search حقيقي)
- **Playwright Browser** (مش httpx) — automation كامل
- **Desktop App** بـ PyWebView (أخف من Electron بـ 100x)
- **Context Compression** ذكي بـ LLM auxiliary
- **Session Management** قوي بـ SQLite WAL
- **21 أداة** مع retry و timeout
- **Auto-extraction** للذكريات من المحادثات
- **Hybrid Search** (BM25 + Vector)

## 📦 المحتويات

```
adam-prism-desktop/
├── backend/
│   └── adam/
│       ├── engine/
│       │   ├── enhanced_engine.py      # v2 base engine
│       │   └── engine_v3.py            # v3 engine (LTM + Browser)
│       ├── api/
│       │   └── server_v3.py            # FastAPI server v3
│       ├── memory/
│       │   ├── store.py                # Short-term memory
│       │   └── long_term.py            # LTM مع vector embeddings
│       ├── browser/
│       │   └── playwright_browser.py   # Playwright integration
│       └── desktop/
│           └── launcher.py             # Desktop app launcher
├── test_v3.py                          # اختبارات شاملة
├── requirements.txt
└── CLOUD_MODEL_SETUP.md                # دليل التشغيل التفصيلي
```

## 🚀 التشغيل السريع

```bash
# 1. ثبّت الـ dependencies
pip install -r requirements.txt
playwright install chromium

# 2. ثبّت موديلات Ollama
ollama pull qwen2.5:0.5b nomic-embed-text qwen2.5:3b

# 3. شغّل الاختبار (بدون LLM)
python test_v3.py

# 4. شغّل API server
cd backend
uvicorn adam.api.server_v3:app --host 0.0.0.0 --port 8000 --reload

# 5. أو شغّل Desktop app
python -m adam.desktop.launcher
```

## 📊 الإحصائيات

- **3,500+ سطر كود**
- **21 أداة** (browser, memory, file, shell, python, etc.)
- **40+ API endpoints**
- **21/21 اختبار API نجح**
- **LTM vector search** شغّال
- **Playwright browser** شغّال

## 🎯 الفجوات اللي اتقفلت

| الفجوة | قبل | بعد |
|---|---|---|
| Context compression | headroom mock | ✅ LLM + fallback |
| Long-term memory | SQLite + FTS5 فقط | ✅ + Vector embeddings (semantic search) |
| Browser automation | httpx فقط | ✅ Playwright حقيقي |
| Session management | stub | ✅ SQLite WAL كامل |
| Tool execution | mock | ✅ حقيقي مع retry |
| Desktop app | غير موجود | ✅ PyWebView |
| Memory auto-extraction | غير موجود | ✅ LLM-based |
| Hybrid search | غير موجود | ✅ BM25 + Vector |
| Memory consolidation | غير موجود | ✅ Automatic merging |

## 📖 التوثيق الكامل

اقرأ `CLOUD_MODEL_SETUP.md` للدليل التفصيلي خطوة بخطوة.

## 🛠️ المواصفات المطلوبة

- Python 3.10+
- 8GB RAM (16GB موصى به)
- 5GB مساحة فارغة
- Ollama

## 📝 الترخيص

Apache 2.0 — نفس ترخيص المشروع الأصلي.
