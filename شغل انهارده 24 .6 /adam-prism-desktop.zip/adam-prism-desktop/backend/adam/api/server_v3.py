"""
Adam Prism v3 — Complete FastAPI Server
========================================
النسخة الكاملة بـ Long-term Memory + Playwright + Desktop integration.

Endpoints:
- /api/chat — محادثة مع LTM و auto-extraction
- /api/chat/stream — SSE streaming
- /ws/chat — WebSocket
- /api/chat/upload — رفع ملفات
- /api/sessions/* — إدارة الجلسات
- /api/memory/* — ذاكرة قصيرة المدى
- /api/ltm/* — ذاكرة طويلة المدى (مع vector search)
- /api/browser/* — Playwright browser automation
- /api/tools/* — أدوات
- /api/json-mode — JSON structured output
- /healthz/* + /metrics — monitoring

Run:
    uvicorn adam.api.server_v3:app --host 0.0.0.0 --port 8000 --reload
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path
from typing import Any

import psutil
from fastapi import (
    FastAPI,
    HTTPException,
    UploadFile,
    File,
    WebSocket,
    WebSocketDisconnect,
    Request,
)
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, StreamingResponse, FileResponse
from pydantic import BaseModel, Field
import asyncio
import httpx

from adam.engine.engine_v3 import AdamEngineV3, EngineConfigV3, get_engine_v3, cleanup_engine_v3

logger = logging.getLogger("adam_prism.api_v3")

# ============================================================
# Config
# ============================================================

ADAM_PRODUCTION = os.getenv("ADAM_PRODUCTION", "0") == "1"
REPO_ROOT = Path(__file__).resolve().parent.parent.parent.parent
INDEX_HTML = REPO_ROOT / "index.html"
if not INDEX_HTML.exists():
    INDEX_HTML = REPO_ROOT / "frontend" / "index.html"

# ============================================================
# Models
# ============================================================

class ChatRequest(BaseModel):
    message: str
    session_id: str | None = None
    context: dict | None = None
    stream: bool = False


class ChatResponse(BaseModel):
    response: str
    session_id: str | None = None
    backend: str | None = None
    tool_calls: list = []
    usage: dict = {}
    ltm_used: bool = False


class MemoryStoreRequest(BaseModel):
    content: str
    type: str = "semantic"
    priority: int = 3
    tags: list[str] = []


class ToolActionRequest(BaseModel):
    name: str
    arguments: dict = {}


class BrowserOpenRequest(BaseModel):
    url: str
    wait_until: str = "domcontentloaded"


class BrowserActionRequest(BaseModel):
    page_id: str
    selector: str | None = None
    text: str | None = None
    full_page: bool = False
    script: str | None = None
    x: int = 0
    y: int = 500


# ============================================================
# App
# ============================================================

app = FastAPI(
    title="Adam Prism v3 — Complete",
    version="3.0.0",
    description="Complete Adam Prism with LTM, Playwright browser, and desktop integration.",
    docs_url="/docs",
    redoc_url=None,
    openapi_url="/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if not ADAM_PRODUCTION else [
        "https://adam-prism.com",
        "https://www.adam-prism.com",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def startup():
    """يهيّئ الـ engine."""
    logger.info("Starting Adam Prism v3...")
    engine = get_engine_v3()
    await engine.init()
    health = await engine.health_check()
    logger.info(f"Engine v3 health: {health}")


@app.on_event("shutdown")
async def shutdown():
    """ينظف."""
    logger.info("Shutting down Adam Prism v3...")
    await cleanup_engine_v3()


# ============================================================
# UI
# ============================================================

@app.get("/", response_class=HTMLResponse, tags=["ui"], include_in_schema=False)
async def chat_ui() -> HTMLResponse:
    if INDEX_HTML.exists():
        return FileResponse(INDEX_HTML, media_type="text/html")
    return HTMLResponse("<h1>Adam Prism v3</h1><p>UI not found.</p>", status_code=500)


# ============================================================
# Chat
# ============================================================

@app.post("/api/chat", response_model=ChatResponse, tags=["chat"])
@app.post("/chat", response_model=ChatResponse, tags=["chat"])
async def chat(req: ChatRequest) -> ChatResponse:
    """محادثة مع كل المميزات v3."""
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="Empty message")

    engine = get_engine_v3()
    try:
        result = await engine.chat(
            message=req.message,
            session_id=req.session_id,
            context=req.context or {},
        )
        return ChatResponse(
            response=result["response"],
            session_id=result["session_id"],
            backend=result["backend"],
            tool_calls=result["tool_calls"],
            usage=result["usage"],
            ltm_used=result.get("ltm_used", False),
        )
    except Exception as e:
        logger.exception("Chat error:")
        raise HTTPException(status_code=500, detail=f"Chat failed: {str(e)[:200]}")


@app.post("/api/chat/stream", tags=["chat"])
async def chat_stream(req: ChatRequest):
    """Streaming chat عبر SSE."""
    if not req.message.strip():
        raise HTTPException(status_code=400, detail="Empty message")

    engine = get_engine_v3()

    async def event_generator():
        try:
            async for chunk in engine.chat_stream(
                message=req.message,
                session_id=req.session_id,
                context=req.context or {},
            ):
                yield f"data: {json.dumps(chunk, ensure_ascii=False)}\n\n"
        except Exception as e:
            logger.exception("Stream error:")
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)[:200]})}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@app.websocket("/ws/chat")
async def ws_chat(websocket: WebSocket):
    """WebSocket للـ streaming."""
    await websocket.accept()
    engine = get_engine_v3()
    try:
        while True:
            data = await websocket.receive_json()
            message = data.get("message", "").strip()
            session_id = data.get("session_id")
            context = data.get("context", {})

            if not message:
                await websocket.send_json({"error": "Empty message"})
                continue

            try:
                result = await engine.chat(message, session_id, context)
                await websocket.send_json({
                    "type": "response",
                    "response": result["response"],
                    "session_id": result["session_id"],
                    "backend": result["backend"],
                    "tool_calls": result["tool_calls"],
                    "usage": result["usage"],
                    "ltm_used": result.get("ltm_used", False),
                })
            except Exception as e:
                logger.exception("WebSocket chat error:")
                await websocket.send_json({
                    "type": "error",
                    "error": str(e)[:200],
                })
    except WebSocketDisconnect:
        logger.info("WebSocket disconnected")
    except Exception as e:
        logger.exception("WebSocket error:")
        try:
            await websocket.close()
        except Exception:
            pass


# ============================================================
# File Upload
# ============================================================

@app.post("/api/chat/upload", tags=["chat"])
async def upload_file(file: UploadFile = File(...)):
    """رفع ملف واستخراج محتواه."""
    import io
    MAX_SIZE = 10 * 1024 * 1024
    content = await file.read()
    if len(content) > MAX_SIZE:
        raise HTTPException(status_code=413, detail="File too large (max 10MB)")

    filename = file.filename or "unknown"
    file_ext = Path(filename).suffix.lower()

    text_exts = {".txt", ".md", ".py", ".js", ".ts", ".tsx", ".jsx", ".json",
                 ".yaml", ".yml", ".csv", ".tsv", ".xml", ".html", ".css",
                 ".java", ".c", ".cpp", ".h", ".rs", ".go", ".rb", ".php",
                 ".sh", ".bash", ".sql", ".log", ".ini", ".toml"}

    if file_ext == ".pdf":
        try:
            import fitz
            doc = fitz.open(stream=content, filetype="pdf")
            text = "".join(page.get_text() for page in doc)
            doc.close()
            return {"filename": filename, "size": len(content), "type": "text",
                    "text_content": text[:50000]}
        except Exception as e:
            return {"filename": filename, "size": len(content), "type": "error",
                    "error": str(e)}

    if file_ext in {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp"}:
        try:
            import pytesseract
            from PIL import Image
            img = Image.open(io.BytesIO(content))
            text = pytesseract.image_to_string(img, lang="ara+eng")
            return {"filename": filename, "size": len(content), "type": "image",
                    "text_content": text}
        except Exception as e:
            return {"filename": filename, "size": len(content), "type": "image",
                    "error": str(e)}

    if file_ext in text_exts or not file_ext:
        try:
            text = content.decode("utf-8", errors="ignore")
            return {"filename": filename, "size": len(content), "type": "text",
                    "text_content": text[:50000]}
        except Exception as e:
            return {"filename": filename, "size": len(content), "type": "error",
                    "error": str(e)}

    return {"filename": filename, "size": len(content), "type": "binary"}


# ============================================================
# Sessions
# ============================================================

@app.get("/api/chat/sessions", tags=["sessions"])
async def list_sessions(limit: int = 50, user_id: str = "default"):
    engine = get_engine_v3()
    sessions = await engine.session_manager.list_sessions(user_id=user_id, limit=limit)
    return {"sessions": sessions, "total": len(sessions)}


@app.get("/api/chat/sessions/{session_id}", tags=["sessions"])
async def get_session(session_id: str):
    engine = get_engine_v3()
    messages = await engine.session_manager.get_messages(session_id, limit=100)
    stats = await engine.session_manager.get_session_stats(session_id)
    return {"session_id": session_id, "messages": messages, "stats": stats}


@app.post("/api/chat/sessions/{session_id}/sync", tags=["sessions"])
async def sync_session(session_id: str, request: Request):
    engine = get_engine_v3()
    try:
        body = await request.json()
        if isinstance(body, list):
            synced = 0
            for msg in body:
                role = msg.get("role", "user")
                content = msg.get("content", "")
                if content:
                    await engine.session_manager.add_message(session_id, role, content)
                    synced += 1
            return {"session_id": session_id, "synced": synced, "status": "ok"}
        return {"session_id": session_id, "synced": 0, "status": "ok"}
    except Exception as e:
        return {"session_id": session_id, "synced": 0, "status": "error", "error": str(e)[:200]}


@app.delete("/api/chat/sessions/{session_id}", tags=["sessions"])
async def delete_session(session_id: str):
    engine = get_engine_v3()
    try:
        async with engine.session_manager._lock:
            engine.session_manager._conn.execute(
                "DELETE FROM messages WHERE session_id = ?", (session_id,)
            )
            cursor = engine.session_manager._conn.execute(
                "DELETE FROM sessions WHERE session_id = ?", (session_id,)
            )
            deleted = cursor.rowcount > 0
        return {"deleted": deleted, "session_id": session_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e)[:200])


# ============================================================
# Short-term Memory (basic SQLite)
# ============================================================

@app.post("/api/memory/store", tags=["memory"])
async def memory_store(req: MemoryStoreRequest):
    engine = get_engine_v3()
    if not engine.memory_store:
        raise HTTPException(status_code=503, detail="Memory store not available")
    mem_id = engine.memory_store.store(
        req.content, priority=req.priority, tags=",".join(req.tags), source="api"
    )
    return {"success": True, "id": mem_id}


@app.get("/api/memory/recall", tags=["memory"])
async def memory_recall(query: str, limit: int = 10):
    engine = get_engine_v3()
    if not engine.memory_store:
        raise HTTPException(status_code=503, detail="Memory store not available")
    if not query.strip():
        return {"results": [], "total": 0}
    results = engine.memory_store.search(query, limit=limit)
    return {"results": results, "total": len(results)}


@app.get("/api/memory/stats", tags=["memory"])
async def memory_stats():
    engine = get_engine_v3()
    if not engine.memory_store:
        return {"available": False}
    stats = engine.memory_store.stats() if hasattr(engine.memory_store, "stats") else {}
    return {"available": True, "stats": stats}


# ============================================================
# Long-Term Memory (vector + BM25)
# ============================================================

@app.post("/api/ltm/store", tags=["ltm"])
async def ltm_store(req: MemoryStoreRequest):
    """حفظ في الذاكرة طويلة المدى مع embedding."""
    engine = get_engine_v3()
    if not engine.ltm:
        raise HTTPException(status_code=503, detail="LTM not available")
    mem_id = await engine.ltm.store(
        content=req.content,
        type=req.type,
        priority=req.priority,
        tags=req.tags,
        source="api",
    )
    return {"success": bool(mem_id), "id": mem_id}


@app.get("/api/ltm/search", tags=["ltm"])
async def ltm_search(
    query: str,
    top_k: int = 5,
    type: str | None = None,
    min_priority: int = 1,
):
    """بحث هجين (BM25 + Vector) في الذاكرة طويلة المدى."""
    engine = get_engine_v3()
    if not engine.ltm:
        raise HTTPException(status_code=503, detail="LTM not available")
    if not query.strip():
        return {"results": [], "total": 0}
    results = await engine.ltm.search(
        query, top_k=top_k, memory_type=type, min_priority=min_priority
    )
    return {
        "results": [
            {
                "id": r.memory.id,
                "content": r.memory.content,
                "type": r.memory.type,
                "priority": r.memory.priority,
                "tags": r.memory.tags,
                "score": round(r.score, 3),
                "bm25_score": round(r.bm25_score, 3),
                "vector_score": round(r.vector_score, 3),
                "access_count": r.memory.access_count,
                "created_at": r.memory.created_at,
            }
            for r in results
        ],
        "total": len(results),
    }


@app.get("/api/ltm/recall", tags=["ltm"])
async def ltm_recall(query: str, max_memories: int = 5, max_chars: int = 1500):
    """استرجاع ذكريات مختصرة للسياق."""
    engine = get_engine_v3()
    if not engine.ltm:
        raise HTTPException(status_code=503, detail="LTM not available")
    text = await engine.ltm.recall_for_context(query, max_memories, max_chars)
    return {"context": text, "length": len(text)}


@app.get("/api/ltm/stats", tags=["ltm"])
async def ltm_stats():
    """إحصائيات الذاكرة طويلة المدى."""
    engine = get_engine_v3()
    if not engine.ltm:
        return {"available": False}
    return engine.ltm.stats()


@app.get("/api/ltm/health", tags=["ltm"])
async def ltm_health():
    """فحص صحة الـ LTM."""
    engine = get_engine_v3()
    if not engine.ltm:
        return {"available": False}
    return await engine.ltm.health_check()


@app.delete("/api/ltm/memories/{memory_id}", tags=["ltm"])
async def ltm_delete(memory_id: int):
    """حذف ذكرى."""
    engine = get_engine_v3()
    if not engine.ltm:
        raise HTTPException(status_code=503, detail="LTM not available")
    success = await engine.ltm.delete(memory_id)
    return {"deleted": success, "id": memory_id}


@app.delete("/api/ltm/all", tags=["ltm"])
async def ltm_delete_all(type: str | None = None):
    """حذف كل الذكريات (أو نوع معين)."""
    engine = get_engine_v3()
    if not engine.ltm:
        raise HTTPException(status_code=503, detail="LTM not available")
    count = await engine.ltm.delete_all(type)
    return {"deleted_count": count, "type": type or "all"}


# ============================================================
# Browser Automation (Playwright)
# ============================================================

@app.post("/api/browser/open", tags=["browser"])
async def browser_open(req: BrowserOpenRequest):
    """فتح URL في Playwright browser."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    try:
        page_id = await engine.browser.open(req.url, wait_until=req.wait_until)
        return {"page_id": page_id, "url": req.url, "success": True}
    except Exception as e:
        return {"success": False, "error": str(e)[:200]}


@app.get("/api/browser/pages", tags=["browser"])
async def browser_pages():
    """سرد الصفحات المفتوحة."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    pages = engine.browser.list_pages()
    return {"pages": pages, "total": len(pages)}


@app.get("/api/browser/{page_id}/read", tags=["browser"])
async def browser_read(page_id: str, selector: str | None = None):
    """قراءة محتوى صفحة."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    result = await engine.browser.read_page(page_id, selector)
    return result


@app.post("/api/browser/{page_id}/click", tags=["browser"])
async def browser_click(page_id: str, req: BrowserActionRequest):
    """النقر على عنصر."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    result = await engine.browser.click(page_id, req.selector or "")
    return result


@app.post("/api/browser/{page_id}/type", tags=["browser"])
async def browser_type(page_id: str, req: BrowserActionRequest):
    """كتابة نص."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    result = await engine.browser.type_text(page_id, req.selector or "", req.text or "")
    return result


@app.post("/api/browser/{page_id}/screenshot", tags=["browser"])
async def browser_screenshot(page_id: str, req: BrowserActionRequest):
    """لقطة شاشة."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    result = await engine.browser.screenshot(page_id, full_page=req.full_page)
    return result


@app.post("/api/browser/{page_id}/scroll", tags=["browser"])
async def browser_scroll(page_id: str, req: BrowserActionRequest):
    """التمرير."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    result = await engine.browser.scroll(page_id, req.x, req.y)
    return result


@app.post("/api/browser/{page_id}/execute", tags=["browser"])
async def browser_execute(page_id: str, req: BrowserActionRequest):
    """تنفيذ JavaScript."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    result = await engine.browser.execute_js(page_id, req.script or "")
    return result


@app.delete("/api/browser/{page_id}", tags=["browser"])
async def browser_close(page_id: str):
    """إغلاق صفحة."""
    engine = get_engine_v3()
    if not engine.browser:
        raise HTTPException(status_code=503, detail="Browser not available")
    success = await engine.browser.close_page(page_id)
    return {"closed": success, "page_id": page_id}


@app.get("/api/browser/stats", tags=["browser"])
async def browser_stats():
    """إحصائيات الـ browser."""
    engine = get_engine_v3()
    if not engine.browser:
        return {"available": False}
    return engine.browser.get_stats()


# ============================================================
# Tools
# ============================================================

@app.get("/api/tools/manifest", tags=["tools"])
async def tools_manifest():
    """Manifest شامل لكل الأدوات."""
    engine = get_engine_v3()
    return engine.get_tool_manifest()


@app.post("/api/tools/action", tags=["tools"])
async def tools_action(req: ToolActionRequest):
    """تنفيذ أداة."""
    engine = get_engine_v3()
    result = await engine.tools.execute(req.name, req.arguments)
    return {
        "success": result.success,
        "result": result.result,
        "error": result.error,
        "latency_ms": result.latency_ms,
    }


# ============================================================
# JSON Mode
# ============================================================

@app.post("/api/json-mode", tags=["json"])
async def json_mode(request: dict):
    schema = request.get("schema", {})
    query = request.get("query", "")
    if not query:
        raise HTTPException(status_code=400, detail="Query required")

    schema_str = json.dumps(schema, ensure_ascii=False)
    prompt = f"رد بصيغة JSON فقط ملتزمًا بالمخطط:\n<schema>\n{schema_str}\n</schema>\n\nاستفسار: {query}\n\nالرد (JSON فقط):"

    engine = get_engine_v3()
    result = await engine.chat(prompt)
    response = result["response"]

    import re
    json_match = re.search(r'\{.*\}', response, re.DOTALL)
    if json_match:
        try:
            parsed = json.loads(json_match.group(0))
            return {"valid": True, "data": parsed, "raw": response}
        except json.JSONDecodeError:
            pass
    return {"valid": False, "data": None, "raw": response, "error": "Could not parse JSON"}


# ============================================================
# Health & Diagnostics
# ============================================================

@app.get("/healthz/live", tags=["ops"])
async def healthz_live():
    return {"status": "alive", "version": "3.0.0", "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S")}


@app.get("/healthz/ready", tags=["ops"])
async def healthz_ready():
    engine = get_engine_v3()
    health = await engine.health_check()
    if health["status"] == "healthy":
        return health
    return JSONResponse(status_code=503, content=health)


@app.get("/api/status", tags=["ops"])
async def api_status():
    engine = get_engine_v3()
    return {
        "status": "ok",
        "version": "3.0.0",
        "engine_ready": True,
        "stats": engine.get_stats(),
    }


@app.get("/api/engine/health", tags=["ops"])
async def engine_health():
    engine = get_engine_v3()
    health = await engine.health_check()
    return {
        **health,
        "system": {
            "cpu_percent": round(psutil.cpu_percent(), 1),
            "memory_percent": round(psutil.virtual_memory().percent, 1),
            "disk_percent": round(psutil.disk_usage("/").percent, 1),
        },
        "config": {
            "lora_url": engine.config.lora_url,
            "ollama_url": engine.config.ollama_url,
            "ollama_model": engine.config.ollama_model,
            "auxiliary_model": engine.config.auxiliary_model if engine.config.auxiliary_enabled else None,
            "ltm_enabled": engine.ltm is not None,
            "browser_enabled": engine.browser is not None,
            "browser_type": engine.config.browser_type if engine.browser else None,
        },
    }


@app.get("/api/engine/diagnostics", tags=["ops"])
async def engine_diagnostics():
    engine = get_engine_v3()
    health = await engine.health_check()
    return {
        "summary": {
            "total_services": len(health["services"]),
            "passed": sum(1 for v in health["services"].values() if v),
            "failed": sum(1 for v in health["services"].values() if not v),
        },
        "services": health["services"],
        "stats": health["stats"],
        "system": {
            "cpu_percent": round(psutil.cpu_percent(), 1),
            "memory_percent": round(psutil.virtual_memory().percent, 1),
            "disk_percent": round(psutil.disk_usage("/").percent, 1),
        },
        "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }


@app.post("/api/engine/heal", tags=["ops"])
async def engine_heal():
    return {"status": "checked", "timestamp": time.strftime("%Y-%m-%dT%H:%M:%S")}


@app.get("/api/engine/stream", tags=["ops"])
async def engine_stream():
    async def event_generator():
        engine = get_engine_v3()
        while True:
            stats = engine.get_stats()
            yield f"data: {json.dumps({'type': 'keepalive', 'stats': stats})}\n\n"
            await asyncio.sleep(15)
    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.get("/metrics", tags=["ops"])
async def metrics():
    engine = get_engine_v3()
    stats = engine.get_stats()
    lines = [
        f"adam_total_turns {stats['total_turns']}",
        f"adam_lora_calls {stats['lora_calls']}",
        f"adam_ollama_calls {stats['ollama_calls']}",
        f"adam_tool_calls {stats['tool_calls']}",
        f"adam_compressions {stats['compressions']}",
        f"adam_errors {stats['errors']}",
        f"adam_memories_extracted {stats.get('memories_extracted', 0)}",
        f"adam_browser_actions {stats.get('browser_actions', 0)}",
        f"adam_cpu_percent {psutil.cpu_percent()}",
        f"adam_memory_percent {psutil.virtual_memory().percent}",
    ]
    return "\n".join(lines)


# ============================================================
# Skills
# ============================================================

@app.get("/api/skills", tags=["skills"])
async def list_skills():
    return {
        "total": 5,
        "skills": [
            {"name": "security_scan", "description": "فحص أمني"},
            {"name": "code_review", "description": "مراجعة كود"},
            {"name": "data_analysis", "description": "تحليل بيانات"},
            {"name": "system_check", "description": "فحص النظام"},
            {"name": "memory_ops", "description": "عمليات الذاكرة"},
        ],
    }


# ============================================================
# Main
# ============================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "adam.api.server_v3:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8000")),
        reload=os.getenv("ADAM_RELOAD", "0") == "1",
        log_level=os.getenv("ADAM_LOG_LEVEL", "info"),
    )
