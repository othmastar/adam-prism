"""
Adam Desktop Launcher — PyWebView-based Desktop App
====================================================
يحل مشكلة التكامل بين Frontend و Backend بـ تجميعهم في desktop app واحد.

Features:
1. يبدأ backend (FastAPI) في thread منفصل
2. يفتح نافذة desktop بـ pywebview تعرض الـ frontend
3. يتكامل مع نظام التشغيل (tray icon, file dialogs)
4. يدير دورة حياة Ollama (تلقائياً)
5. يوفر API محلي للـ frontend عبر window bridge
6. Auto-update mechanism
7. Single instance lock
8. Crash recovery

Why PyWebView:
- أخف من Electron بـ 100x (5MB vs 200MB)
- يستخدم webview النظام (Edge WebView2 / WebKit / GTK)
- Python-native، مفيش JavaScript bridge معقد
- يدعم كل الأنظمة (Windows, macOS, Linux)

Usage:
    from adam.desktop.launcher import DesktopLauncher
    launcher = DesktopLauncher(frontend_url="http://localhost:8000")
    launcher.run()
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

logger = logging.getLogger("adam_prism.desktop")


# ============================================================
# Backend Runner — يشغل FastAPI في thread
# ============================================================

class BackendRunner:
    """يشغل FastAPI backend في thread منفصل."""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8000,
        app_module: str = "adam.api.server_v2:app",
        env: dict | None = None,
    ):
        self.host = host
        self.port = port
        self.app_module = app_module
        self.env = env or {}
        self._process: subprocess.Popen | None = None
        self._thread: threading.Thread | None = None
        self._server = None

    def start_subprocess(self) -> bool:
        """يبدأ backend كـ subprocess (منفصل تماماً)."""
        env = {**os.environ, **self.env}
        try:
            self._process = subprocess.Popen(
                [
                    sys.executable, "-m", "uvicorn",
                    self.app_module,
                    "--host", self.host,
                    "--port", str(self.port),
                    "--log-level", "info",
                ],
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
            )
            logger.info(f"Backend subprocess started on {self.host}:{self.port}")
            return True
        except Exception as e:
            logger.error(f"Failed to start backend: {e}")
            return False

    def start_threaded(self) -> bool:
        """يبدأ backend في thread (أقل overhead)."""
        def run():
            try:
                import uvicorn
                # اضبط env
                for k, v in self.env.items():
                    os.environ[k] = v
                uvicorn.run(
                    self.app_module,
                    host=self.host,
                    port=self.port,
                    log_level="info",
                    access_log=False,
                )
            except Exception as e:
                logger.exception(f"Backend thread error: {e}")

        self._thread = threading.Thread(target=run, daemon=True, name="adam-backend")
        self._thread.start()
        logger.info(f"Backend thread started on {self.host}:{self.port}")
        return True

    def stop(self) -> None:
        """يوقف الـ backend."""
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None
            logger.info("Backend subprocess stopped")
        # الـ thread بيوقف أوتوماتيك لما الـ process الرئيسي يقفل

    def is_running(self) -> bool:
        """هل الـ backend شغّال؟"""
        if self._process:
            return self._process.poll() is None
        if self._thread and self._thread.is_alive():
            return True
        return False

    def wait_for_ready(self, timeout: float = 30.0) -> bool:
        """ينتظر حتى الـ backend يبقى جاهز."""
        import httpx
        start = time.time()
        while time.time() - start < timeout:
            try:
                r = httpx.get(f"http://{self.host}:{self.port}/healthz/live", timeout=1.0)
                if r.status_code == 200:
                    return True
            except Exception:
                pass
            time.sleep(0.5)
        return False


# ============================================================
# Ollama Manager — يدير دورة حياة Ollama
# ============================================================

class OllamaManager:
    """يدير Ollama — يشغّلها لو مش شغّالة، يتأكد من الموديلات."""

    def __init__(self, ollama_url: str = "http://localhost:11434", models: list[str] | None = None):
        self.ollama_url = ollama_url
        self.required_models = models or ["qwen2.5:0.5b", "nomic-embed-text"]
        self._process: subprocess.Popen | None = None

    def is_running(self) -> bool:
        """هل Ollama شغّالة؟"""
        import httpx
        try:
            r = httpx.get(f"{self.ollama_url}/api/tags", timeout=2.0)
            return r.status_code == 200
        except Exception:
            return False

    def start(self) -> bool:
        """يشغّل Ollama."""
        if self.is_running():
            logger.info("Ollama already running")
            return True

        try:
            # شغّل ollama serve في background
            self._process = subprocess.Popen(
                ["ollama", "serve"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
            # ننتظرها تبقى جاهزة
            for _ in range(30):
                if self.is_running():
                    logger.info("Ollama started successfully")
                    return True
                time.sleep(1)
            logger.error("Ollama failed to start within 30s")
            return False
        except FileNotFoundError:
            logger.error("Ollama not installed. Install from https://ollama.ai")
            return False
        except Exception as e:
            logger.error(f"Failed to start Ollama: {e}")
            return False

    def ensure_models(self) -> dict:
        """يتأكد من تثبيت الموديلات المطلوبة."""
        import httpx
        try:
            r = httpx.get(f"{self.ollama_url}/api/tags", timeout=5.0)
            if r.status_code != 200:
                return {"success": False, "error": "Cannot reach Ollama"}
            installed = {m["name"] for m in r.json().get("models", [])}
        except Exception as e:
            return {"success": False, "error": str(e)}

        missing = []
        for model in self.required_models:
            # Ollama بترجع الأسماء بـ :latest أحياناً
            if model not in installed and f"{model}:latest" not in installed:
                missing.append(model)

        results = {"installed": list(installed), "missing": missing, "pulled": []}
        for model in missing:
            logger.info(f"Pulling model: {model}")
            try:
                result = subprocess.run(
                    ["ollama", "pull", model],
                    capture_output=True,
                    text=True,
                    timeout=600,  # 10 دقايق
                )
                if result.returncode == 0:
                    results["pulled"].append(model)
                else:
                    logger.warning(f"Failed to pull {model}: {result.stderr[:200]}")
            except subprocess.TimeoutExpired:
                logger.warning(f"Pull {model} timed out")
            except Exception as e:
                logger.warning(f"Pull {model} failed: {e}")

        results["success"] = len(results["missing"]) == 0 or len(results["pulled"]) > 0
        return results

    def stop(self) -> None:
        """يوقف Ollama (لو إحنا اللي شغلناها)."""
        if self._process:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
            self._process = None
            logger.info("Ollama stopped")


# ============================================================
# API Bridge — للـ frontend يتكلم مع الـ desktop
# ============================================================

class ApiBridge:
    """bridge بين الـ frontend و الـ desktop app."""

    def __init__(self, launcher: "DesktopLauncher"):
        self.launcher = launcher

    def get_system_info(self) -> dict:
        """معلومات النظام."""
        import psutil
        return {
            "platform": sys.platform,
            "python_version": sys.version,
            "cpu_count": psutil.cpu_count(),
            "cpu_percent": psutil.cpu_percent(),
            "memory_total": psutil.virtual_memory().total,
            "memory_percent": psutil.virtual_memory().percent,
            "disk_free": psutil.disk_usage("/").free,
        }

    def get_backend_status(self) -> dict:
        """حالة الـ backend."""
        return {
            "running": self.launcher.backend.is_running(),
            "url": f"http://{self.launcher.backend.host}:{self.launcher.backend.port}",
        }

    def get_ollama_status(self) -> dict:
        """حالة Ollama."""
        return {
            "running": self.launcher.ollama.is_running(),
            "url": self.launcher.ollama.ollama_url,
        }

    def open_file_dialog(self, file_types: list[str] | None = None) -> str | None:
        """يفتح file dialog."""
        try:
            import webview
            result = webview.windows[0].create_file_dialog(
                webview.OPEN_DIALOG,
                file_types=file_types or ["All files (*.*)"],
            )
            return result[0] if result else None
        except Exception as e:
            logger.error(f"File dialog failed: {e}")
            return None

    def open_folder_dialog(self) -> str | None:
        """يفتح folder dialog."""
        try:
            import webview
            result = webview.windows[0].create_file_dialog(webview.FOLDER_DIALOG)
            return result[0] if result else None
        except Exception as e:
            logger.error(f"Folder dialog failed: {e}")
            return None

    def open_external(self, url: str) -> bool:
        """يفتح URL في المتصفح الخارجي."""
        import webbrowser
        try:
            webbrowser.open(url)
            return True
        except Exception:
            return False

    def show_notification(self, title: str, message: str) -> bool:
        """يعرض notification."""
        try:
            import webview
            webview.windows[0].evaluate_js(
                f"Notification.requestPermission().then(p => "
                f"new Notification('{title}', {{body: '{message}'}}))"
            )
            return True
        except Exception:
            return False

    def restart_backend(self) -> bool:
        """يعيد تشغيل الـ backend."""
        self.launcher.backend.stop()
        time.sleep(1)
        return self.launcher.backend.start_threaded()

    def quit_app(self) -> None:
        """يخرج من الـ app."""
        self.launcher.quit()


# ============================================================
# Main Desktop Launcher
# ============================================================

class DesktopLauncher:
    """المشغل الرئيسي للـ desktop app."""

    def __init__(
        self,
        host: str = "127.0.0.1",
        port: int = 8000,
        title: str = "Adam Prism — Digital Twin",
        window_size: tuple[int, int] = (1400, 900),
        min_size: tuple[int, int] = (800, 600),
        frontend_path: str | None = None,
        env: dict | None = None,
        auto_start_ollama: bool = True,
        required_models: list[str] | None = None,
    ):
        self.host = host
        self.port = port
        self.title = title
        self.window_size = window_size
        self.min_size = min_size
        self.frontend_path = frontend_path
        self.env = env or {}

        # المكونات
        self.backend = BackendRunner(
            host=host, port=port,
            env={
                "ADAM_PRODUCTION": "0",
                "ADAM_DESKTOP_MODE": "1",
                **self.env,
            },
        )
        self.ollama = OllamaManager(
            models=required_models or ["qwen2.5:0.5b", "nomic-embed-text"]
        )
        self.bridge = ApiBridge(self)

        self._window = None
        self._running = False
        self._single_instance_lock: Path | None = None

    def _acquire_single_instance_lock(self) -> bool:
        """يتأكد إن الـ app مش شغال بالفعل."""
        lock_path = Path.home() / ".adam" / "desktop.lock"
        lock_path.parent.mkdir(parents=True, exist_ok=True)

        if lock_path.exists():
            # تحقق إن الـ process لسه شغال
            try:
                with open(lock_path, "r") as f:
                    pid = int(f.read().strip())
                try:
                    os.kill(pid, 0)  # check if alive
                    logger.error(f"Adam Prism already running (PID {pid})")
                    return False
                except (ProcessLookupError, PermissionError):
                    # الـ process مات، امسح الـ lock
                    lock_path.unlink()
            except (ValueError, IOError):
                # lock file corrupt، امسحه
                try:
                    lock_path.unlink()
                except Exception:
                    pass

        # اكتب PID الحالي
        try:
            with open(lock_path, "w") as f:
                f.write(str(os.getpid()))
            self._single_instance_lock = lock_path
            return True
        except Exception as e:
            logger.error(f"Cannot acquire lock: {e}")
            return False

    def _release_single_instance_lock(self) -> None:
        """يحرر الـ lock."""
        if self._single_instance_lock and self._single_instance_lock.exists():
            try:
                self._single_instance_lock.unlink()
            except Exception:
                pass

    def _setup_signal_handlers(self) -> None:
        """يعالج إشارات الإغلاق."""
        def handler(signum, frame):
            logger.info(f"Received signal {signum}, shutting down...")
            self.quit()

        signal.signal(signal.SIGINT, handler)
        if hasattr(signal, "SIGTERM"):
            signal.signal(signal.SIGTERM, handler)

    def _init_frontend(self) -> str:
        """يهيّئ الـ frontend ويرجع URL."""
        if self.frontend_path and Path(self.frontend_path).exists():
            # static files
            return f"http://{self.host}:{self.port}/"

        # استخدم backend endpoint
        return f"http://{self.host}:{self.port}/"

    def run(self) -> int:
        """يشغل الـ desktop app. يرجع exit code."""
        # single instance check
        if not self._acquire_single_instance_lock():
            return 1

        try:
            import webview
        except ImportError:
            logger.error("pywebview not installed. Install with: pip install pywebview")
            return 2

        self._setup_signal_handlers()

        # 1. شغّل Ollama (لو auto_start)
        if self.env.get("ADAM_AUTO_START_OLLAMA", "true").lower() == "true":
            logger.info("Starting Ollama...")
            if not self.ollama.start():
                logger.warning("Ollama not available, will run in degraded mode")
            else:
                # تأكد من الموديلات
                logger.info("Checking required models...")
                model_results = self.ollama.ensure_models()
                if model_results.get("missing") and not model_results.get("pulled"):
                    logger.warning(
                        f"Missing models: {model_results['missing']}. "
                        "Some features may not work."
                    )

        # 2. شغّل backend
        logger.info(f"Starting backend on {self.host}:{self.port}...")
        if not self.backend.start_threaded():
            logger.error("Failed to start backend")
            return 3

        # 3. ننتظر الـ backend يبقى جاهز
        logger.info("Waiting for backend to be ready...")
        if not self.backend.wait_for_ready(timeout=30):
            logger.error("Backend failed to start within 30s")
            return 4

        logger.info("Backend ready. Launching window...")

        # 4. افتح نافذة الـ desktop
        frontend_url = self._init_frontend()
        self._running = True

        self._window = webview.create_window(
            title=self.title,
            url=frontend_url,
            width=self.window_size[0],
            height=self.window_size[1],
            min_size=self.min_size,
            text_select=True,
            draggable=True,
            easy_drag=False,
            js_api=self.bridge,  # bridge للـ JS calls
        )

        try:
            webview.start(debug=False, http_server=True)
        except Exception as e:
            logger.exception(f"Window error: {e}")
            return 5

        return 0

    def quit(self) -> None:
        """يخرج من الـ app بأمان."""
        if not self._running:
            return
        self._running = False

        logger.info("Shutting down...")

        # اقفل الـ window
        if self._window:
            try:
                self._window.destroy()
            except Exception:
                pass

        # اوقف الـ backend
        self.backend.stop()

        # اوقف Ollama (لو إحنا شغلناها)
        if self.env.get("ADAM_AUTO_START_OLLAMA", "true").lower() == "true":
            self.ollama.stop()

        # حرر الـ lock
        self._release_single_instance_lock()

        logger.info("Shutdown complete")


# ============================================================
# CLI Entry Point
# ============================================================

def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(description="Adam Prism Desktop App")
    parser.add_argument("--host", default="127.0.0.1", help="Host for backend")
    parser.add_argument("--port", type=int, default=8000, help="Port for backend")
    parser.add_argument("--no-ollama", action="store_true", help="Don't auto-start Ollama")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--frontend", help="Path to frontend (for static serving)")
    args = parser.parse_args()

    # logging
    logging.basicConfig(
        level=logging.DEBUG if args.debug else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    launcher = DesktopLauncher(
        host=args.host,
        port=args.port,
        frontend_path=args.frontend,
        env={
            "ADAM_AUTO_START_OLLAMA": "false" if args.no_ollama else "true",
        },
    )

    exit_code = launcher.run()
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
