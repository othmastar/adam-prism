"""
Adam Engine v3 — The Complete Integrated Engine
=================================================
يجمع كل المكونات:
- Long-term Memory مع vector embeddings
- Playwright browser automation
- Session management مع SQLite WAL
- Auxiliary client
- Tool dispatcher
- Context compressor

يجب أن يُستخدم مع server_v3.py الذي يقدم endpoints كاملة.

Usage:
    from adam.engine.engine_v3 import AdamEngineV3, EngineConfigV3
    config = EngineConfigV3.from_env()
    engine = AdamEngineV3(config)
    await engine.init()
    result = await engine.chat("مرحبا", session_id="...")
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, AsyncIterator

import httpx

# استيراد المكونات
from adam.engine.enhanced_engine import (
    AdamEngineV2,
    EngineConfig,
    SessionManager,
    AuxiliaryClient,
    ContextCompressor,
    ToolDispatcher,
    ToolResult,
    estimate_tokens,
    estimate_messages_tokens,
)
from adam.memory.long_term import LongTermMemory
from adam.browser.playwright_browser import BrowserAutomation, get_browser

logger = logging.getLogger("adam_prism.engine_v3")


# ============================================================
# V3 Configuration
# ============================================================

@dataclass
class EngineConfigV3(EngineConfig):
    """إعدادات V3 — مع LTM و Browser."""
    # Long-term memory
    ltm_db_path: str = "~/.adam/ltm.db"
    ltm_embedding_model: str = "nomic-embed-text"
    ltm_enable_consolidation: bool = True
    ltm_enable_decay: bool = True

    # Browser automation
    browser_enabled: bool = True
    browser_headless: bool = True
    browser_type: str = "chromium"  # chromium, firefox, webkit
    browser_max_pages: int = 5
    browser_default_timeout: float = 30.0

    # Auto-extraction
    auto_extract_memories: bool = True

    @classmethod
    def from_env(cls) -> "EngineConfigV3":
        """يبني config من environment variables."""
        base = EngineConfig.from_env()
        return cls(
            # inherit from v2
            lora_url=base.lora_url,
            lora_timeout=base.lora_timeout,
            lora_max_chars=base.lora_max_chars,
            lora_max_retries=base.lora_max_retries,
            ollama_url=base.ollama_url,
            ollama_model=base.ollama_model,
            ollama_timeout=base.ollama_timeout,
            ollama_api_key=base.ollama_api_key,
            auxiliary_enabled=base.auxiliary_enabled,
            auxiliary_url=base.auxiliary_url,
            auxiliary_model=base.auxiliary_model,
            auxiliary_timeout=base.auxiliary_timeout,
            max_context_tokens=base.max_context_tokens,
            reserve_for_response=base.reserve_for_response,
            compression_threshold=base.compression_threshold,
            protect_last_n=base.protect_last_n,
            max_history_messages=base.max_history_messages,
            max_tool_calls_per_turn=base.max_tool_calls_per_turn,
            tool_timeout=base.tool_timeout,
            tool_max_retries=base.tool_max_retries,
            session_db_path=base.session_db_path,
            session_ttl_days=base.session_ttl_days,
            memory_db_path=base.memory_db_path,
            # v3 additions
            ltm_db_path=os.getenv("ADAM_LTM_DB", "~/.adam/ltm.db"),
            ltm_embedding_model=os.getenv("ADAM_EMBEDDING_MODEL", "nomic-embed-text"),
            browser_enabled=os.getenv("ADAM_BROWSER_ENABLED", "true").lower() == "true",
            browser_headless=os.getenv("ADAM_BROWSER_HEADLESS", "true").lower() == "true",
            browser_type=os.getenv("ADAM_BROWSER_TYPE", "chromium"),
            auto_extract_memories=os.getenv("ADAM_AUTO_EXTRACT", "true").lower() == "true",
        )


# ============================================================
# Extended Tool Dispatcher — مع Browser + LTM
# ============================================================

class ToolDispatcherV3(ToolDispatcher):
    """Tool Dispatcher مع Playwright browser + LTM integration."""

    def __init__(
        self,
        max_retries: int = 2,
        timeout: float = 30.0,
        memory_store=None,
        ltm: LongTermMemory | None = None,
        browser: BrowserAutomation | None = None,
    ):
        super().__init__(max_retries, timeout, memory_store)
        self.ltm = ltm
        self.browser = browser

    async def _execute_once(self, tool_name: str, params: dict) -> ToolResult:
        """تنفيذ مرة واحدة — مع browser و LTM tools."""

        # === Browser Tools (Playwright حقيقي) ===
        if tool_name == "browser_open" and self.browser:
            url = params.get("url", "")
            try:
                page_id = await self.browser.open(url)
                return ToolResult(
                    True,
                    {"page_id": page_id, "url": url, "opened": True},
                )
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "browser_fetch" and self.browser:
            url = params.get("url", "")
            try:
                page_id = await self.browser.open(url)
                content = await self.browser.get_text(page_id)
                # اقفل الصفحة لتوفير الموارد
                await self.browser.close_page(page_id)
                return ToolResult(
                    True,
                    {"content": content[:10000], "url": url, "page_id": page_id},
                )
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "browser_click" and self.browser:
            page_id = params.get("page_id", "")
            selector = params.get("selector", "")
            if not page_id or not selector:
                return ToolResult(False, error="page_id and selector required")
            result = await self.browser.click(page_id, selector)
            return ToolResult(result["success"], result, result.get("error"))

        if tool_name == "browser_type" and self.browser:
            page_id = params.get("page_id", "")
            selector = params.get("selector", "")
            text = params.get("text", "")
            if not all([page_id, selector, text]):
                return ToolResult(False, error="page_id, selector, text required")
            result = await self.browser.type_text(page_id, selector, text)
            return ToolResult(result["success"], result, result.get("error"))

        if tool_name == "browser_read" and self.browser:
            page_id = params.get("page_id", "")
            selector = params.get("selector")
            if not page_id:
                return ToolResult(False, error="page_id required")
            result = await self.browser.read_page(page_id, selector)
            return ToolResult(result["success"], result, result.get("error"))

        if tool_name == "browser_screenshot" and self.browser:
            page_id = params.get("page_id", "")
            full_page = params.get("full_page", False)
            if not page_id:
                return ToolResult(False, error="page_id required")
            result = await self.browser.screenshot(page_id, full_page=full_page)
            return ToolResult(result["success"], result, result.get("error"))

        if tool_name == "browser_scroll" and self.browser:
            page_id = params.get("page_id", "")
            x = int(params.get("x", 0))
            y = int(params.get("y", 500))
            if not page_id:
                return ToolResult(False, error="page_id required")
            result = await self.browser.scroll(page_id, x, y)
            return ToolResult(result["success"], result, result.get("error"))

        if tool_name == "browser_close" and self.browser:
            page_id = params.get("page_id", "")
            if not page_id:
                return ToolResult(False, error="page_id required")
            success = await self.browser.close_page(page_id)
            return ToolResult(success, {"closed": success, "page_id": page_id})

        if tool_name == "browser_pages" and self.browser:
            pages = self.browser.list_pages()
            return ToolResult(True, {"pages": pages, "total": len(pages)})

        if tool_name == "browser_execute_js" and self.browser:
            page_id = params.get("page_id", "")
            script = params.get("script", "")
            if not all([page_id, script]):
                return ToolResult(False, error="page_id and script required")
            result = await self.browser.execute_js(page_id, script)
            return ToolResult(result["success"], result, result.get("error"))

        # === Long-term Memory Tools ===
        if tool_name == "memory_store" and self.ltm:
            content = params.get("content", "")
            mem_type = params.get("type", "semantic")
            priority = int(params.get("priority", 3))
            tags = params.get("tags", [])
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",") if t.strip()]
            try:
                mem_id = await self.ltm.store(
                    content=content,
                    type=mem_type,
                    priority=priority,
                    tags=tags,
                    source="tool",
                )
                return ToolResult(
                    bool(mem_id),
                    {"stored": bool(mem_id), "id": mem_id, "type": mem_type},
                )
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "memory_recall" and self.ltm:
            query = params.get("query", "")
            top_k = int(params.get("top_k", 5))
            try:
                results = await self.ltm.search(query, top_k=top_k)
                return ToolResult(
                    True,
                    {
                        "results": [
                            {
                                "id": r.memory.id,
                                "content": r.memory.content,
                                "type": r.memory.type,
                                "score": round(r.score, 3),
                                "bm25_score": round(r.bm25_score, 3),
                                "vector_score": round(r.vector_score, 3),
                                "priority": r.memory.priority,
                            }
                            for r in results
                        ],
                        "total": len(results),
                    },
                )
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "memory_search_semantic" and self.ltm:
            query = params.get("query", "")
            top_k = int(params.get("top_k", 5))
            mem_type = params.get("type")
            try:
                results = await self.ltm.search(
                    query, top_k=top_k, memory_type=mem_type
                )
                return ToolResult(
                    True,
                    {
                        "results": [
                            {
                                "content": r.memory.content,
                                "type": r.memory.type,
                                "score": round(r.score, 3),
                            }
                            for r in results
                        ],
                    },
                )
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "memory_delete" and self.ltm:
            mem_id = int(params.get("id", 0))
            if not mem_id:
                return ToolResult(False, error="id required")
            success = await self.ltm.delete(mem_id)
            return ToolResult(success, {"deleted": success, "id": mem_id})

        if tool_name == "memory_stats" and self.ltm:
            stats = self.ltm.stats()
            return ToolResult(True, stats)

        # === Fallback للـ tools الأساسية ===
        return await super()._execute_once(tool_name, params)


# ============================================================
# Main Engine V3
# ============================================================

class AdamEngineV3(AdamEngineV2):
    """المحرك v3 — يجمع كل المكونات."""

    def __init__(self, config: EngineConfigV3 | None = None):
        # استدعِ الـ __init__ الأب (v2)
        if config is None:
            config = EngineConfigV3.from_env()
        # bypass الأب ونادي جد v2 بـ config v3
        # (لأن v3 inherited من v2 config)
        # نعملها يدوياً:
        self.config = config
        self.session_manager = SessionManager(config.session_db_path)

        # Auxiliary client
        self.auxiliary: AuxiliaryClient | None = None
        if config.auxiliary_enabled:
            self.auxiliary = AuxiliaryClient(
                base_url=config.auxiliary_url,
                model=config.auxiliary_model,
                timeout=config.auxiliary_timeout,
            )

        # Context compressor
        self.compressor = ContextCompressor(
            auxiliary_client=self.auxiliary,
            max_context_tokens=config.max_context_tokens,
            reserve_for_response=config.reserve_for_response,
            compression_threshold=config.compression_threshold,
            protect_last_n=config.protect_last_n,
        )

        # Memory store (short-term, basic SQLite)
        self.memory_store = None
        try:
            from adam.memory.store import MemoryStore
            self.memory_store = MemoryStore(config.memory_db_path)
        except Exception as e:
            logger.warning(f"MemoryStore unavailable: {e}")

        # === V3 additions ===

        # Long-term memory with vector embeddings
        self.ltm: LongTermMemory | None = None
        try:
            self.ltm = LongTermMemory(
                db_path=config.ltm_db_path,
                ollama_url=config.ollama_url,
                embedding_model=config.ltm_embedding_model,
                auxiliary_client=self.auxiliary,
                enable_consolidation=config.ltm_enable_consolidation,
                enable_decay=config.ltm_enable_decay,
            )
            logger.info("Long-term memory initialized (will init DB on first use)")
        except Exception as e:
            logger.warning(f"LTM unavailable: {e}")

        # Browser automation
        self.browser: BrowserAutomation | None = None
        if config.browser_enabled:
            try:
                self.browser = BrowserAutomation(
                    headless=config.browser_headless,
                    browser_type=config.browser_type,
                    max_pages=config.browser_max_pages,
                    default_timeout=config.browser_default_timeout,
                )
                logger.info(f"Browser automation ready ({config.browser_type})")
            except Exception as e:
                logger.warning(f"Browser unavailable: {e}")

        # Tool dispatcher (v3 with browser + LTM)
        self.tools = ToolDispatcherV3(
            max_retries=config.tool_max_retries,
            timeout=config.tool_timeout,
            memory_store=self.memory_store,
            ltm=self.ltm,
            browser=self.browser,
        )

        # HTTP clients
        self._lora_client: httpx.AsyncClient | None = None
        self._ollama_client: httpx.AsyncClient | None = None

        # Stats
        self._stats = {
            "total_turns": 0,
            "lora_calls": 0,
            "ollama_calls": 0,
            "tool_calls": 0,
            "compressions": 0,
            "errors": 0,
            "memories_extracted": 0,
            "browser_actions": 0,
        }

        self._initialized = False

        logger.info(
            f"AdamEngineV3 ready: lora={config.lora_url}, "
            f"aux={config.auxiliary_model if config.auxiliary_enabled else 'off'}, "
            f"ltm={'on' if self.ltm else 'off'}, "
            f"browser={'on' if self.browser else 'off'}"
        )

    async def init(self) -> None:
        """يهيّئ المكونات async (LTM + Browser)."""
        if self._initialized:
            return

        # Init LTM
        if self.ltm:
            try:
                await self.ltm.init()
                logger.info("LTM initialized")
            except Exception as e:
                logger.error(f"LTM init failed: {e}")
                self.ltm = None

        # Init Browser
        if self.browser:
            try:
                await self.browser.init()
                logger.info("Browser initialized")
            except Exception as e:
                logger.error(f"Browser init failed: {e}")
                self.browser = None
                # عطل الـ browser في الـ tools dispatcher
                self.tools.browser = None

        self._initialized = True

    async def chat(
        self,
        message: str,
        session_id: str | None = None,
        context: dict | None = None,
    ) -> dict:
        """دردشة v3 — مع LTM recall و auto-extraction."""
        if not self._initialized:
            await self.init()

        start = time.time()
        self._stats["total_turns"] += 1
        context = context or {}

        # أنشئ session لو مش موجود
        if not session_id:
            session_id = await self.session_manager.create_session(
                model=self.config.ollama_model
            )

        # === V3: استرجع ذكريات من LTM ===
        ltm_context = ""
        if self.ltm:
            try:
                ltm_context = await self.ltm.recall_for_context(
                    message, max_memories=5, max_chars=1500
                )
                if ltm_context:
                    context["memory"] = ltm_context.split("\n")
                    logger.debug(f"LTM recalled {len(ltm_context)} chars for context")
            except Exception as e:
                logger.warning(f"LTM recall failed: {e}")

        # اجمع التاريخ
        history = await self.session_manager.get_messages(session_id, limit=50)
        history.extend(context.get("history", []))

        # ابنِ messages
        messages = self._build_messages(message, history, context)

        # اضغط السياق لو لازم
        messages, compression_stats = await self.compressor.compress(messages)
        if compression_stats.get("compressed"):
            self._stats["compressions"] += 1

        # جرب LoRA الأول
        response_text = None
        used_backend = None
        tokens_in = estimate_messages_tokens(messages)

        try:
            response_text = await self._call_lora(messages)
            used_backend = "lora"
            self._stats["lora_calls"] += 1
        except Exception as e:
            logger.warning(f"LoRA call failed: {e}")
            self._stats["errors"] += 1

        if response_text is None:
            try:
                response_text = await self._call_ollama(messages)
                used_backend = "ollama"
                self._stats["ollama_calls"] += 1
            except Exception as e:
                logger.warning(f"Ollama call failed: {e}")
                self._stats["errors"] += 1
                response_text = self._mock_response(message)
                used_backend = "mock"

        # استخرج tool calls ونفذها
        tool_calls_made = []
        if "<tool_call>" in response_text:
            response_text, tool_calls_made = await self._process_tool_calls(
                response_text, message, session_id, messages
            )
            # عدّل browser_actions stat
            browser_tools = {"browser_open", "browser_fetch", "browser_click",
                             "browser_type", "browser_read", "browser_screenshot",
                             "browser_scroll", "browser_close", "browser_execute_js"}
            if any(tc["name"] in browser_tools for tc in tool_calls_made):
                self._stats["browser_actions"] += 1

        tokens_out = estimate_tokens(response_text)
        latency_ms = int((time.time() - start) * 1000)

        # سجل في الـ session
        await self.session_manager.add_message(
            session_id, "user", message,
            tokens_in=tokens_in, latency_ms=0,
        )
        await self.session_manager.add_message(
            session_id, "assistant", response_text,
            tokens_out=tokens_out, latency_ms=latency_ms,
            tool_calls=tool_calls_made,
            metadata={
                "backend": used_backend,
                "compression": compression_stats,
                "ltm_used": bool(ltm_context),
            },
        )

        # === V3: auto-extract memories في الخلفية ===
        if self.config.auto_extract_memories and self.ltm and response_text:
            asyncio.create_task(self._auto_extract_memories(
                message, response_text, session_id
            ))

        # === V3: ولّد عنوان للجلسة لو أول رسالة ===
        if len(history) <= 1 and self.auxiliary:
            try:
                title = await self.auxiliary.generate_title(message, response_text)
                await self.session_manager.set_session_title(session_id, title)
            except Exception:
                pass

        return {
            "response": response_text,
            "session_id": session_id,
            "backend": used_backend,
            "tool_calls": tool_calls_made,
            "compression": compression_stats,
            "ltm_used": bool(ltm_context),
            "usage": {
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "latency_ms": latency_ms,
            },
        }

    async def _auto_extract_memories(
        self,
        user_message: str,
        assistant_response: str,
        session_id: str,
    ) -> None:
        """يستخرج ذكريات من المحادثة في الخلفية."""
        if not self.ltm:
            return
        try:
            mem_ids = await self.ltm.store_from_conversation(
                user_message, assistant_response, session_id
            )
            if mem_ids:
                self._stats["memories_extracted"] += len(mem_ids)
                logger.info(f"Auto-extracted {len(mem_ids)} memories")
        except Exception as e:
            logger.debug(f"Auto-extraction failed: {e}")

    # ============================================================
    # V3: Enhanced Tool Manifest
    # ============================================================

    def get_tool_manifest(self) -> dict:
        """يرجع manifest شامل لكل الأدوات المتاحة في v3."""
        tools = {
            # Memory
            "memory_store": {
                "description": "حفظ معلومة في الذاكرة الدائمة مع embedding",
                "parameters": {
                    "content": {"type": "string", "required": True},
                    "type": {"type": "string", "enum": ["episodic", "semantic", "procedural", "preference"]},
                    "priority": {"type": "integer", "min": 1, "max": 5},
                    "tags": {"type": "array"},
                },
                "available": self.ltm is not None,
            },
            "memory_recall": {
                "description": "بحث هجين (BM25 + Vector) في الذكريات",
                "parameters": {
                    "query": {"type": "string", "required": True},
                    "top_k": {"type": "integer"},
                },
                "available": self.ltm is not None,
            },
            "memory_search_semantic": {
                "description": "بحث semantic فقط (vector similarity)",
                "parameters": {
                    "query": {"type": "string", "required": True},
                    "type": {"type": "string"},
                },
                "available": self.ltm is not None,
            },
            "memory_stats": {
                "description": "إحصائيات الذاكرة",
                "parameters": {},
                "available": self.ltm is not None,
            },
            # Browser (Playwright)
            "browser_open": {
                "description": "فتح URL في متصفح Playwright حقيقي",
                "parameters": {"url": {"type": "string", "required": True}},
                "available": self.browser is not None,
            },
            "browser_fetch": {
                "description": "جلب محتوى URL (Playwright + SSRF protection)",
                "parameters": {"url": {"type": "string", "required": True}},
                "available": self.browser is not None,
            },
            "browser_click": {
                "description": "النقر على عنصر في الصفحة",
                "parameters": {
                    "page_id": {"type": "string", "required": True},
                    "selector": {"type": "string", "required": True},
                },
                "available": self.browser is not None,
            },
            "browser_type": {
                "description": "كتابة نص في حقل",
                "parameters": {
                    "page_id": {"type": "string", "required": True},
                    "selector": {"type": "string", "required": True},
                    "text": {"type": "string", "required": True},
                },
                "available": self.browser is not None,
            },
            "browser_read": {
                "description": "قراءة محتوى صفحة (أو عنصر)",
                "parameters": {
                    "page_id": {"type": "string", "required": True},
                    "selector": {"type": "string"},
                },
                "available": self.browser is not None,
            },
            "browser_screenshot": {
                "description": "أخذ لقطة شاشة",
                "parameters": {
                    "page_id": {"type": "string", "required": True},
                    "full_page": {"type": "boolean"},
                },
                "available": self.browser is not None,
            },
            "browser_scroll": {
                "description": "التمرير في الصفحة",
                "parameters": {
                    "page_id": {"type": "string", "required": True},
                    "x": {"type": "integer"},
                    "y": {"type": "integer"},
                },
                "available": self.browser is not None,
            },
            "browser_pages": {
                "description": "سرد الصفحات المفتوحة",
                "parameters": {},
                "available": self.browser is not None,
            },
            "browser_close": {
                "description": "إغلاق صفحة",
                "parameters": {"page_id": {"type": "string", "required": True}},
                "available": self.browser is not None,
            },
            "browser_execute_js": {
                "description": "تنفيذ JavaScript في الصفحة",
                "parameters": {
                    "page_id": {"type": "string", "required": True},
                    "script": {"type": "string", "required": True},
                },
                "available": self.browser is not None,
            },
            # File operations (inherited)
            "file_read": {
                "description": "قراءة ملف",
                "parameters": {"path": {"type": "string", "required": True}},
                "available": True,
            },
            "file_write": {
                "description": "كتابة ملف",
                "parameters": {
                    "path": {"type": "string", "required": True},
                    "content": {"type": "string", "required": True},
                },
                "available": True,
            },
            "file_download": {
                "description": "تحميل ملف من URL",
                "parameters": {
                    "url": {"type": "string", "required": True},
                    "save_path": {"type": "string"},
                },
                "available": True,
            },
            # Shell & System
            "shell": {
                "description": "تنفيذ أمر (مع whitelist حماية)",
                "parameters": {"command": {"type": "string", "required": True}},
                "available": True,
            },
            "python_exec": {
                "description": "تنفيذ بايثون في sandbox",
                "parameters": {"code": {"type": "string", "required": True}},
                "available": True,
            },
            "disk_space": {
                "description": "مساحة القرص",
                "parameters": {},
                "available": True,
            },
            "search_knowledge": {
                "description": "بحث معرفي (alias لـ memory_recall)",
                "parameters": {"query": {"type": "string", "required": True}},
                "available": self.ltm is not None,
            },
        }

        # رتّب
        available_count = sum(1 for t in tools.values() if t["available"])
        return {
            "total": len(tools),
            "available": available_count,
            "tools": tools,
            "format": '<tool_call>{"name": "...", "arguments": {...}}</tool_call>',
        }

    async def health_check(self) -> dict:
        """فحص صحة شامل لـ v3."""
        if not self._initialized:
            await self.init()

        # inherited checks
        base_health = await super().health_check()

        # V3 additions
        if self.ltm:
            ltm_health = await self.ltm.health_check()
            base_health["services"]["ltm"] = ltm_health.get("db_connected", False)
            base_health["services"]["embeddings"] = ltm_health.get("embedding_available", False)
        else:
            base_health["services"]["ltm"] = False
            base_health["services"]["embeddings"] = False

        if self.browser:
            base_health["services"]["browser"] = await self.browser.health_check()
        else:
            base_health["services"]["browser"] = False

        # status
        all_healthy = all(base_health["services"].values())
        base_health["status"] = "healthy" if all_healthy else "degraded"

        return base_health

    def get_stats(self) -> dict:
        """إحصائيات v3."""
        base_stats = super().get_stats()
        base_stats.update({
            "memories_extracted": self._stats["memories_extracted"],
            "browser_actions": self._stats["browser_actions"],
        })
        return base_stats

    async def cleanup(self) -> None:
        """ينظف كل الموارد."""
        # Cleanup browser
        if self.browser:
            try:
                await self.browser.close()
            except Exception:
                pass

        # Cleanup LTM
        if self.ltm:
            try:
                await self.ltm.close()
            except Exception:
                pass

        # Cleanup parent
        await super().cleanup()


# ============================================================
# Module-level singleton
# ============================================================

_engine_v3: AdamEngineV3 | None = None


def get_engine_v3() -> AdamEngineV3:
    """يرجع الـ engine v3 المشترك."""
    global _engine_v3
    if _engine_v3 is None:
        _engine_v3 = AdamEngineV3()
    return _engine_v3


async def cleanup_engine_v3() -> None:
    """ينظف الـ engine v3."""
    global _engine_v3
    if _engine_v3 is not None:
        await _engine_v3.cleanup()
        _engine_v3 = None
