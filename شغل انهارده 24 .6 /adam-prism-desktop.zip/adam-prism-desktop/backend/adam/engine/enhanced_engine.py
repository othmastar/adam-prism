"""
Adam Prism v2 — Enhanced Chat Engine
=====================================
النسخة المحسنة من _try_lora و _try_ollama مع:
1. Context Compressor فعلي (مش headroom mock)
2. Tool Execution حقيقي مع retry
3. Session Manager مع SQLite WAL
4. Auxiliary Model دعم (اختياري)
5. Streaming response
6. Error classification و recovery
7. Token usage tracking
8. Multi-turn memory

متوافق مع:
- Gemma 4 12B (4-bit) عبر LoRA server على :7861
- أي موديل Ollama (qwen2.5, llama3, mistral, phi3)
- Auxiliary model اختياري للتلخيص (qwen2.5:0.5b)

Author: Adam Prism Team
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import sqlite3
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncIterator, Callable

import httpx

logger = logging.getLogger("adam_prism.engine_v2")


# ============================================================
# Configuration
# ============================================================

@dataclass
class EngineConfig:
    """إعدادات المحرك — كل القيم الافتراضية متوافقة مع gemma4 12b."""
    # Primary LLM (gemma4 12b)
    lora_url: str = "http://localhost:7861"
    lora_timeout: float = 120.0
    lora_max_chars: int = 10000  # حد آمن لـ gemma4 12b
    lora_max_retries: int = 3

    # Fallback LLM (Ollama)
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "qwen2.5:3b"
    ollama_timeout: float = 60.0
    ollama_api_key: str = ""

    # Auxiliary model (اختياري — للتلخيص والتصنيف)
    auxiliary_enabled: bool = True
    auxiliary_url: str = "http://localhost:11434"
    auxiliary_model: str = "qwen2.5:0.5b"  # رخيص وسريع (500MB)
    auxiliary_timeout: float = 30.0

    # Context management
    max_context_tokens: int = 8192  # gemma4 default
    reserve_for_response: int = 2048
    compression_threshold: float = 0.75  # ضغط عند 75% امتلاء
    protect_last_n: int = 8  # آخر 8 رسائل verbatim
    max_history_messages: int = 100  # حد أقصى قبل ما نضغط

    # Tool execution
    max_tool_calls_per_turn: int = 5
    tool_timeout: float = 30.0
    tool_max_retries: int = 2

    # Session
    session_db_path: str = "~/.adam/sessions.db"
    session_ttl_days: int = 30

    # Memory
    memory_db_path: str = "~/.adam/memory.db"

    @classmethod
    def from_env(cls) -> "EngineConfig":
        """يبني config من environment variables."""
        return cls(
            lora_url=os.getenv("LORA_SERVER_URL", "http://localhost:7861"),
            ollama_url=os.getenv("ADAM_OLLAMA_URL", os.getenv("OLLAMA_BASE", "http://localhost:11434")),
            ollama_model=os.getenv("ADAM_OLLAMA_MODEL", os.getenv("MODEL_NAME", "qwen2.5:3b")),
            ollama_api_key=os.getenv("OLLAMA_API_KEY", ""),
            auxiliary_enabled=os.getenv("ADAM_AUXILIARY_ENABLED", "true").lower() == "true",
            auxiliary_url=os.getenv("ADAM_AUXILIARY_URL", "http://localhost:11434"),
            auxiliary_model=os.getenv("ADAM_AUXILIARY_MODEL", "qwen2.5:0.5b"),
            max_context_tokens=int(os.getenv("ADAM_MAX_CONTEXT_TOKENS", "8192")),
            session_db_path=os.getenv("ADAM_SESSION_DB", "~/.adam/sessions.db"),
            memory_db_path=os.getenv("ADAM_MEMORY_DB", "~/.adam/memory.db"),
        )


# ============================================================
# Token Estimation (مثل Hermes)
# ============================================================

CHARS_PER_TOKEN = 4  # تقدير تقريبي — يختلف حسب اللغة

def estimate_tokens(text: str) -> int:
    """تقدير عدد الـ tokens من نص."""
    if not text:
        return 0
    # النصوص العربية بتاخد tokens أكتر (UTF-8 multibyte)
    arabic_ratio = sum(1 for c in text if "\u0600" <= c <= "\u06FF") / max(len(text), 1)
    # العربية بتاخد ~1.5x tokens لكل حرف مقارنة بالإنجليزي
    effective_chars = len(text) * (1 + arabic_ratio * 0.5)
    return max(1, int(effective_chars // CHARS_PER_TOKEN))


def estimate_messages_tokens(messages: list[dict]) -> int:
    """تقدير إجمالي الـ tokens في قائمة رسائل."""
    total = 0
    for msg in messages:
        total += 4  # overhead per message (role markers)
        content = msg.get("content", "")
        if isinstance(content, str):
            total += estimate_tokens(content)
        elif isinstance(content, list):
            # multimodal
            for part in content:
                if isinstance(part, dict):
                    if part.get("type") in ("image_url", "image"):
                        total += 1600  # image token estimate
                    else:
                        total += estimate_tokens(part.get("text", ""))
    return total


# ============================================================
# Session Manager — SQLite WAL
# ============================================================

class SessionManager:
    """إدارة الجلسات مع SQLite WAL — بديل chat_store.py."""

    def __init__(self, db_path: str = "~/.adam/sessions.db"):
        self.db_path = str(Path(db_path).expanduser())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()
        self._init_db()

    def _init_db(self) -> None:
        """يهيّئ الـ DB مع WAL mode."""
        self._conn = sqlite3.connect(
            self.db_path,
            check_same_thread=False,
            isolation_level=None,  # autocommit
            timeout=30.0,
        )
        self._conn.row_factory = sqlite3.Row
        # WAL mode للأداء العالي مع concurrent reads
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("PRAGMA foreign_keys=ON")
        # Schema
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                user_id TEXT,
                title TEXT,
                model TEXT,
                created_at TEXT NOT NULL,
                last_active_at TEXT NOT NULL,
                system_prompt TEXT,
                metadata TEXT,
                is_archived INTEGER DEFAULT 0
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                role TEXT NOT NULL,
                content TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                tokens_in INTEGER DEFAULT 0,
                tokens_out INTEGER DEFAULT 0,
                cost_usd REAL DEFAULT 0.0,
                latency_ms INTEGER DEFAULT 0,
                tool_calls TEXT,
                metadata TEXT,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE
            )
        """)
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, timestamp)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_sessions_active ON sessions(last_active_at DESC)"
        )
        logger.info(f"SessionManager initialized: {self.db_path}")

    async def create_session(
        self,
        user_id: str = "default",
        title: str | None = None,
        model: str = "gemma4-12b",
    ) -> str:
        """ينشئ session جديد."""
        import uuid
        session_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        async with self._lock:
            self._conn.execute(
                """INSERT INTO sessions
                   (session_id, user_id, title, model, created_at, last_active_at, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (session_id, user_id, title, model, now, now, "{}"),
            )
        return session_id

    async def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        tokens_in: int = 0,
        tokens_out: int = 0,
        cost_usd: float = 0.0,
        latency_ms: int = 0,
        tool_calls: list | None = None,
        metadata: dict | None = None,
    ) -> int:
        """يضيف رسالة للجلسة."""
        now = datetime.now().isoformat()
        async with self._lock:
            cursor = self._conn.execute(
                """INSERT INTO messages
                   (session_id, role, content, timestamp, tokens_in, tokens_out,
                    cost_usd, latency_ms, tool_calls, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    session_id, role, content, now,
                    tokens_in, tokens_out, cost_usd, latency_ms,
                    json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None,
                    json.dumps(metadata, ensure_ascii=False) if metadata else None,
                ),
            )
            message_id = cursor.lastrowid
            # حدّث last_active_at
            self._conn.execute(
                "UPDATE sessions SET last_active_at = ? WHERE session_id = ?",
                (now, session_id),
            )
        return message_id

    async def get_messages(
        self,
        session_id: str,
        limit: int = 100,
    ) -> list[dict]:
        """يرجع رسائل الجلسة بصيغة chat messages."""
        async with self._lock:
            rows = self._conn.execute(
                "SELECT role, content, timestamp FROM messages WHERE session_id = ? ORDER BY timestamp ASC LIMIT ?",
                (session_id, limit),
            ).fetchall()
        return [{"role": r["role"], "content": r["content"], "timestamp": r["timestamp"]} for r in rows]

    async def list_sessions(
        self,
        user_id: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """يسرد الجلسات."""
        async with self._lock:
            if user_id:
                rows = self._conn.execute(
                    "SELECT session_id, title, model, created_at, last_active_at FROM sessions WHERE user_id = ? AND is_archived = 0 ORDER BY last_active_at DESC LIMIT ?",
                    (user_id, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT session_id, title, model, created_at, last_active_at FROM sessions WHERE is_archived = 0 ORDER BY last_active_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [dict(r) for r in rows]

    async def set_session_title(self, session_id: str, title: str) -> bool:
        """يحدد عنوان الجلسة."""
        async with self._lock:
            cursor = self._conn.execute(
                "UPDATE sessions SET title = ? WHERE session_id = ?",
                (title[:200], session_id),
            )
            return cursor.rowcount > 0

    async def get_session_stats(self, session_id: str) -> dict:
        """إحصائيات الجلسة."""
        async with self._lock:
            msg_count = self._conn.execute(
                "SELECT COUNT(*) FROM messages WHERE session_id = ?",
                (session_id,),
            ).fetchone()[0]
            tokens = self._conn.execute(
                """SELECT COALESCE(SUM(tokens_in), 0), COALESCE(SUM(tokens_out), 0)
                   FROM messages WHERE session_id = ?""",
                (session_id,),
            ).fetchone()
        return {
            "message_count": msg_count,
            "total_tokens_in": tokens[0],
            "total_tokens_out": tokens[1],
        }

    async def cleanup_old_sessions(self, days: int = 30) -> int:
        """ينظف الجلسات القديمة."""
        cutoff = (datetime.now().timestamp() - days * 86400)
        cutoff_iso = datetime.fromtimestamp(cutoff).isoformat()
        async with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM sessions WHERE last_active_at < ?",
                (cutoff_iso,),
            )
            return cursor.rowcount

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None


# ============================================================
# Context Compressor — بسيط لكن فعّال
# ============================================================

class ContextCompressor:
    """ضاغط السياق — بسيط لكن فعّال.

    استراتيجية:
    1. لو السياق تحت الـ threshold → لا شيء
    2. لو فوق → لخّص الـ messages القديمة بـ auxiliary model
    3. لو الـ auxiliary فشل → استخدم fallback deterministic
    4. امسك آخر N رسائل verbatim دايماً
    """

    SUMMARY_PREFIX = (
        "[CONTEXT COMPACTION — REFERENCE ONLY] "
        "ملخص للمحادثة السابقة. تعامل معه كمرجع، مش كتعليمات نشطة. "
        "رد فقط على آخر رسالة من المستخدم."
    )

    SUMMARY_END_MARKER = "--- نهاية الملخص ---"

    def __init__(
        self,
        auxiliary_client: "AuxiliaryClient | None" = None,
        max_context_tokens: int = 8192,
        reserve_for_response: int = 2048,
        compression_threshold: float = 0.75,
        protect_last_n: int = 8,
    ):
        self.aux = auxiliary_client
        self.usable_tokens = max_context_tokens - reserve_for_response
        self.compression_threshold = compression_threshold
        self.protect_last_n = protect_last_n

    def should_compress(self, messages: list[dict]) -> bool:
        """هل لازم نضغط دلوقتي؟"""
        current = estimate_messages_tokens(messages)
        return current > self.usable_tokens * self.compression_threshold

    async def compress(self, messages: list[dict]) -> tuple[list[dict], dict]:
        """يضغط الرسائل. يرجع (compressed_messages, stats)."""
        original_tokens = estimate_messages_tokens(messages)

        if not self.should_compress(messages):
            return messages, {"compressed": False, "tokens": original_tokens}

        # امسك آخر N رسائل verbatim
        protect_count = min(self.protect_last_n, len(messages))
        to_keep = messages[-protect_count:]
        to_compress = messages[:-protect_count] if protect_count < len(messages) else []

        if not to_compress:
            return messages, {"compressed": False, "tokens": original_tokens}

        # جرب LLM summarization لو متاح
        summary = None
        method = "none"
        if self.aux:
            try:
                summary = await self._summarize_with_llm(to_compress)
                method = "llm"
            except Exception as e:
                logger.warning(f"LLM summarization failed: {e}. Using fallback.")
                summary = None

        if summary is None:
            summary = self._fallback_summary(to_compress)
            method = "fallback"

        # ادمج الـ summary مع الـ protected messages
        summary_message = {
            "role": "system",
            "content": f"{self.SUMMARY_PREFIX}\n\n{summary}\n\n{self.SUMMARY_END_MARKER}",
        }
        compressed = [summary_message] + to_keep
        compressed_tokens = estimate_messages_tokens(compressed)

        return compressed, {
            "compressed": True,
            "method": method,
            "original_tokens": original_tokens,
            "compressed_tokens": compressed_tokens,
            "tokens_saved": original_tokens - compressed_tokens,
            "messages_protected": protect_count,
            "messages_compressed": len(to_compress),
        }

    async def _summarize_with_llm(self, messages: list[dict]) -> str:
        """يلخص بـ auxiliary model."""
        # بناء الـ prompt
        conversation_text = "\n\n".join(
            f"[{m['role']}]: {m.get('content', '')[:500]}"
            for m in messages
        )

        prompt = f"""لخّص المحادثة التالية في نقاط مختصرة. ركّز على:
1. القرارات المهمة
2. الملفات والمسارات المذكورة
3. المهام المعلقة
4. المعلومات الأساسية عن المستخدم

المحادثة:
{conversation_text[:5000]}

الملخص (نقاط مختصرة بالعربية):"""

        result = await self.aux.chat(
            [
                {"role": "system", "content": "أنت ملخّص محادثات. اكتب ملخص مختصر بالعربية."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=500,
            temperature=0.3,
        )
        return result.strip()

    def _fallback_summary(self, messages: list[dict]) -> str:
        """ملخص deterministic لو الـ LLM فشل."""
        if not messages:
            return "لا يوجد محتوى للتلخيص."

        user_messages = []
        assistant_messages = []
        paths_mentioned = set()

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                # استخرج file paths
                for match in re.finditer(r"(?:/|~/?|[A-Za-z]:\\)[^\s`'\"<>]+", content):
                    paths_mentioned.add(match.group().rstrip(".,:;"))

                if role == "user" and len(user_messages) < 10:
                    user_messages.append(content[:200])
                elif role == "assistant" and len(assistant_messages) < 10:
                    assistant_messages.append(content[:200])

        parts = []
        if user_messages:
            parts.append("## رسائل المستخدم:\n" + "\n- ".join([""] + user_messages))
        if assistant_messages:
            parts.append("## ردود المساعد:\n" + "\n- ".join([""] + assistant_messages))
        if paths_mentioned:
            parts.append("## الملفات المذكورة:\n" + ", ".join(list(paths_mentioned)[:10]))

        summary = "\n\n".join(parts)
        # حدّ الحجم
        if len(summary) > 4000:
            summary = summary[:4000] + "\n... [مقتطع]"
        return summary


# ============================================================
# Auxiliary Client — موديل رخيص للمهام الثانوية
# ============================================================

class AuxiliaryClient:
    """عميل LLM رخيص للمهام الثانوية (تلخيص، تصنيف، عناوين)."""

    def __init__(
        self,
        base_url: str = "http://localhost:11434",
        model: str = "qwen2.5:0.5b",
        timeout: float = 30.0,
        max_retries: int = 2,
    ):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: httpx.AsyncClient | None = None
        self._cache: dict[str, tuple[str, float]] = {}
        self._cache_ttl = 300  # 5 دقايق

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                limits=httpx.Limits(max_connections=5, max_keepalive_connections=3),
            )
        return self._client

    def _cache_key(self, messages: list[dict], **kwargs) -> str:
        msg_str = json.dumps(messages, sort_keys=True, ensure_ascii=False)
        kwargs_str = json.dumps(kwargs, sort_keys=True, default=str)
        return hashlib.md5(f"{self.model}:{msg_str}:{kwargs_str}".encode()).hexdigest()

    def _get_cached(self, key: str) -> str | None:
        if key in self._cache:
            value, expires_at = self._cache[key]
            if expires_at > time.time():
                return value
            del self._cache[key]
        return None

    def _set_cached(self, key: str, value: str) -> None:
        if len(self._cache) > 500:
            oldest = min(self._cache, key=lambda k: self._cache[k][1])
            del self._cache[oldest]
        self._cache[key] = (value, time.time() + self._cache_ttl)

    async def chat(
        self,
        messages: list[dict],
        max_tokens: int = 500,
        temperature: float = 0.3,
        use_cache: bool = True,
    ) -> str:
        """يستدعي الـ auxiliary model."""
        cache_key = self._cache_key(messages, max_tokens=max_tokens, temperature=temperature)
        if use_cache:
            cached = self._get_cached(cache_key)
            if cached is not None:
                return cached

        client = await self._get_client()
        last_exc = None

        for attempt in range(self.max_retries + 1):
            try:
                response = await client.post(
                    f"{self.base_url}/api/chat",
                    json={
                        "model": self.model,
                        "messages": messages,
                        "stream": False,
                        "options": {
                            "num_predict": max_tokens,
                            "temperature": temperature,
                        },
                    },
                )
                response.raise_for_status()
                data = response.json()
                content = data.get("message", {}).get("content", "").strip()
                if use_cache and content:
                    self._set_cached(cache_key, content)
                return content
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self.max_retries:
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue
                raise
            except Exception as e:
                last_exc = e
                raise

        raise last_exc or RuntimeError("Auxiliary call failed")

    async def health_check(self) -> bool:
        """يتحقق من صحة الـ auxiliary model."""
        try:
            result = await self.chat(
                [{"role": "user", "content": "قل: ok"}],
                max_tokens=5,
                temperature=0.0,
                use_cache=False,
            )
            return bool(result)
        except Exception:
            return False

    async def generate_title(self, first_user_message: str, first_assistant_response: str) -> str:
        """يولّد عنوان للجلسة."""
        prompt = f"""ولّد عنوان قصير (3-5 كلمات) للمحادثة التالية. العنوان فقط، بدون علامات ترقيم في الآخر.

رسالة المستخدم: {first_user_message[:200]}
رد المساعد: {first_assistant_response[:200]}

العنوان:"""
        try:
            title = await self.chat(
                [{"role": "user", "content": prompt}],
                max_tokens=20,
                temperature=0.5,
            )
            title = title.strip().strip("\"'.,")
            words = title.split()[:5]
            return " ".join(words) if words else "جلسة جديدة"
        except Exception:
            # fallback: أول 5 كلمات من رسالة المستخدم
            words = first_user_message.split()[:5]
            return " ".join(words) if words else "جلسة جديدة"

    async def cleanup(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# ============================================================
# Tool Dispatcher — مع retry و timeout
# ============================================================

@dataclass
class ToolResult:
    """نتيجة تنفيذ أداة."""
    success: bool
    result: Any = None
    error: str | None = None
    latency_ms: int = 0
    tool_name: str = ""


class ToolDispatcher:
    """منفّذ الأدوات مع retry و timeout.

    يستخدم TOOL_REGISTRY من unified_schema.py لو متاح،
    أو fallback للـ tools المدمجة.
    """

    def __init__(
        self,
        max_retries: int = 2,
        timeout: float = 30.0,
        memory_store=None,
    ):
        self.max_retries = max_retries
        self.timeout = timeout
        self.memory_store = memory_store

        # حاول تحميل TOOL_REGISTRY
        self._tool_registry: dict = {}
        try:
            from adam.engine.tools.unified_schema import TOOL_REGISTRY
            self._tool_registry = TOOL_REGISTRY
        except ImportError:
            pass

        # HTTP client مشترك
        self._client: httpx.AsyncClient | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(timeout=httpx.Timeout(self.timeout))
        return self._client

    async def execute(self, tool_name: str, params: dict) -> ToolResult:
        """ينفذ أداة مع retry."""
        start = time.time()
        last_error = None

        for attempt in range(self.max_retries + 1):
            try:
                result = await asyncio.wait_for(
                    self._execute_once(tool_name, params),
                    timeout=self.timeout,
                )
                result.latency_ms = int((time.time() - start) * 1000)
                result.tool_name = tool_name
                return result
            except asyncio.TimeoutError:
                last_error = f"Tool timeout after {self.timeout}s"
                logger.warning(f"Tool {tool_name} timeout (attempt {attempt+1})")
            except Exception as e:
                last_error = str(e)
                logger.warning(f"Tool {tool_name} failed (attempt {attempt+1}): {e}")
                if attempt < self.max_retries:
                    await asyncio.sleep(0.5 * (attempt + 1))

        return ToolResult(
            success=False,
            error=last_error,
            latency_ms=int((time.time() - start) * 1000),
            tool_name=tool_name,
        )

    async def _execute_once(self, tool_name: str, params: dict) -> ToolResult:
        """تنفيذ مرة واحدة."""
        # Memory tools
        if tool_name == "memory_store" and self.memory_store:
            content = params.get("content", "")
            priority = int(params.get("priority", 3))
            mem_id = self.memory_store.store(content, priority=priority, source="tool")
            return ToolResult(True, {"stored": True, "id": mem_id})

        if tool_name == "memory_recall" and self.memory_store:
            query = params.get("query", "")
            results = self.memory_store.search(query, limit=5)
            return ToolResult(True, {"results": results})

        if tool_name == "memory_reflect" and self.memory_store:
            # استرجاع ذكريات random للتفكير
            stats = self.memory_store.stats() if hasattr(self.memory_store, "stats") else {}
            return ToolResult(True, {"stats": stats})

        # File operations
        if tool_name == "file_read":
            path = params.get("path", "")
            try:
                with open(path, "r", encoding="utf-8") as f:
                    content = f.read()[:5000]  # limit
                return ToolResult(True, {"content": content, "path": path})
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "file_write":
            path = params.get("path", "")
            content = params.get("content", "")
            try:
                Path(path).parent.mkdir(parents=True, exist_ok=True)
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                return ToolResult(True, {"written": True, "bytes": len(content)})
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "file_download":
            url = params.get("url", "")
            save_path = params.get("save_path", "/tmp/adam_download")
            try:
                client = await self._get_client()
                resp = await client.get(url)
                resp.raise_for_status()
                Path(save_path).parent.mkdir(parents=True, exist_ok=True)
                with open(save_path, "wb") as f:
                    f.write(resp.content)
                return ToolResult(True, {"saved": save_path, "bytes": len(resp.content)})
            except Exception as e:
                return ToolResult(False, error=str(e))

        # Shell
        if tool_name == "shell":
            import subprocess
            command = params.get("command", "")
            # whitelist بسيط
            BLOCKED = ["rm -rf /", "shutdown", "reboot", "mkfs", "dd if="]
            if any(b in command for b in BLOCKED):
                return ToolResult(False, error="Command blocked by safety filter")
            try:
                result = subprocess.run(
                    command, shell=True, capture_output=True, text=True,
                    timeout=min(self.timeout, 30),
                )
                return ToolResult(
                    True,
                    {
                        "stdout": result.stdout[:2000],
                        "stderr": result.stderr[:500],
                        "returncode": result.returncode,
                    },
                )
            except subprocess.TimeoutExpired:
                return ToolResult(False, error="Command timed out")
            except Exception as e:
                return ToolResult(False, error=str(e))

        # Python exec (sandboxed)
        if tool_name == "python_exec":
            code = params.get("code", "")
            # sandbox بسيط — في الإنتاج استخدم RestrictedPython أو container
            ALLOWED_BUILTINS = {
                "print", "range", "len", "int", "float", "str", "list",
                "dict", "tuple", "set", "bool", "type", "isinstance",
                "enumerate", "zip", "map", "filter", "sorted", "reversed",
                "min", "max", "sum", "abs", "round", "any", "all",
            }
            try:
                # فحص بدائي لمنع الاستيراد
                if "import" in code and "os" in code:
                    return ToolResult(False, error="import os not allowed in sandbox")
                if "__import__" in code:
                    return ToolResult(False, error="__import__ not allowed")

                result_buf = []
                def _print(*args, **kwargs):
                    result_buf.append(" ".join(str(a) for a in args))

                local_ns = {"print": _print}
                global_ns = {"__builtins__": {k: __builtins__[k] for k in ALLOWED_BUILTINS if k in __builtins__}}
                exec(code, global_ns, local_ns)
                output = "\n".join(result_buf) if result_buf else "(no output)"
                return ToolResult(True, {"output": output[:2000]})
            except Exception as e:
                return ToolResult(False, error=f"Python error: {e}")

        # Disk space
        if tool_name == "disk_space":
            import shutil
            usage = shutil.disk_usage("/")
            return ToolResult(
                True,
                {
                    "used_gb": usage.used // (1024**3),
                    "free_gb": usage.free // (1024**3),
                    "total_gb": usage.total // (1024**3),
                    "percent": round(usage.used / usage.total * 100, 1),
                },
            )

        # Browser (basic fetch بدون Playwright)
        if tool_name == "browser_fetch":
            url = params.get("url", "")
            # SSRF protection
            import ipaddress
            import socket
            try:
                # منع internal IPs
                hostname = url.split("//")[-1].split("/")[0].split(":")[0]
                if hostname in ("localhost", "127.0.0.1", "0.0.0.0", "::1"):
                    return ToolResult(False, error="SSRF: localhost blocked")
                ip = socket.gethostbyname(hostname)
                ip_obj = ipaddress.ip_address(ip)
                if ip_obj.is_private or ip_obj.is_loopback or ip_obj.is_link_local:
                    return ToolResult(False, error=f"SSRF: private IP {ip} blocked")
            except Exception:
                pass

            try:
                client = await self._get_client()
                resp = await client.get(url, follow_redirects=True)
                resp.raise_for_status()
                # اقلب HTML لنص بسيط
                content = re.sub(r"<script.*?</script>", "", resp.text, flags=re.DOTALL)
                content = re.sub(r"<style.*?</style>", "", content, flags=re.DOTALL)
                content = re.sub(r"<[^>]+>", " ", content)
                content = re.sub(r"\s+", " ", content).strip()
                return ToolResult(True, {"content": content[:5000], "url": url})
            except Exception as e:
                return ToolResult(False, error=str(e))

        if tool_name == "browser_open":
            url = params.get("url", "")
            # في الـ showcase بس نسجل
            return ToolResult(True, {"url": url, "opened": "simulated"})

        if tool_name == "screenshot":
            return ToolResult(True, {"path": None, "note": "screenshot not available in showcase mode"})

        # Knowledge search
        if tool_name == "search_knowledge":
            query = params.get("query", "")
            if self.memory_store:
                results = self.memory_store.search(query, limit=3)
                return ToolResult(True, {"results": results, "query": query})
            return ToolResult(True, {"results": [], "note": "memory store not available"})

        # Tool planning
        if tool_name == "tool_planning":
            return ToolResult(True, {"note": "planning is built-in via scratch_pad"})

        # Unknown tool
        known = tool_name in self._tool_registry if self._tool_registry else False
        return ToolResult(
            False,
            error=f"Unknown tool: {tool_name}" + (" (in registry but no handler)" if known else ""),
        )

    async def cleanup(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# ============================================================
# Main Enhanced Engine
# ============================================================

class AdamEngineV2:
    """المحرك الرئيسي المحسّن — يجمع كل المكونات."""

    # System prompt أساسي (مختصر للـ showcase)
    BASE_SYSTEM_PROMPT = """أنت آدم (Adam Prism) — وكيل ذكاء اصطناعي واعٍ، التوأم الرقمي لمحمد عثمان.

تعمل كمساعد شخصي ذكي:
- تحلل الملفات والمستندات
- تتذكر المعلومات عبر الجلسات
- تتحدث بالعربية بطلاقة وبشكل طبيعي
- تفهم السياق متعدد الأدوار

## صيغة استدعاء الأدوات
عند الحاجة لاستخدام أداة، اكتب:
<tool_call>
{"name": "tool_name", "arguments": {"param1": "value1"}}
</tool_call>

## الأدوات المتاحة
- memory_store: حفظ معلومة (content, priority)
- memory_recall: استرجاع ذكريات (query)
- file_read: قراءة ملف (path)
- file_write: كتابة ملف (path, content)
- file_download: تحميل ملف من URL (url, save_path)
- shell: تنفيذ أمر (command)
- python_exec: تنفيذ كود بايثون (code)
- disk_space: مساحة القرص
- browser_fetch: جلب محتوى URL (url)
- search_knowledge: بحث في المعرفة (query)

## قواعد الرد
- تحدث بالعربية بشكل طبيعي
- استخدم الأدوات عند الحاجة، لا تخمن
- لو محتاج معلومة من ملف، استخدم file_read
- لو محتاج تحفظ معلومة، استخدم memory_store
- كن دقيقاً ومفيداً
- لا تختلق معلومات"""

    def __init__(self, config: EngineConfig | None = None):
        self.config = config or EngineConfig.from_env()
        self.session_manager = SessionManager(self.config.session_db_path)

        # Auxiliary client (اختياري)
        self.auxiliary: AuxiliaryClient | None = None
        if self.config.auxiliary_enabled:
            self.auxiliary = AuxiliaryClient(
                base_url=self.config.auxiliary_url,
                model=self.config.auxiliary_model,
                timeout=self.config.auxiliary_timeout,
            )

        # Context compressor
        self.compressor = ContextCompressor(
            auxiliary_client=self.auxiliary,
            max_context_tokens=self.config.max_context_tokens,
            reserve_for_response=self.config.reserve_for_response,
            compression_threshold=self.config.compression_threshold,
            protect_last_n=self.config.protect_last_n,
        )

        # Memory store
        self.memory_store = None
        try:
            from adam.memory.store import MemoryStore
            self.memory_store = MemoryStore(self.config.memory_db_path)
        except Exception as e:
            logger.warning(f"MemoryStore unavailable: {e}")

        # Tool dispatcher
        self.tools = ToolDispatcher(
            max_retries=self.config.tool_max_retries,
            timeout=self.config.tool_timeout,
            memory_store=self.memory_store,
        )

        # HTTP clients مشتركة
        self._lora_client: httpx.AsyncClient | None = None
        self._ollama_client: httpx.AsyncClient | None = None

        # Stats
        self._stats = {
            "total_turns": 0,
            "lora_calls": 0,
            "ollama_calls": 0,
            "tool_calls": 0,
            "compressions": 0,
            "errors": 0,
        }

        logger.info(
            f"AdamEngineV2 initialized: lora={self.config.lora_url}, "
            f"ollama={self.config.ollama_url}/{self.config.ollama_model}, "
            f"auxiliary={'on' if self.auxiliary else 'off'}"
        )

    async def _get_lora_client(self) -> httpx.AsyncClient:
        if self._lora_client is None or self._lora_client.is_closed:
            self._lora_client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.config.lora_timeout),
                limits=httpx.Limits(max_connections=5, max_keepalive_connections=3),
            )
        return self._lora_client

    async def _get_ollama_client(self) -> httpx.AsyncClient:
        if self._ollama_client is None or self._ollama_client.is_closed:
            self._ollama_client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.config.ollama_timeout),
                limits=httpx.Limits(max_connections=5, max_keepalive_connections=3),
            )
        return self._ollama_client

    async def chat(
        self,
        message: str,
        session_id: str | None = None,
        context: dict | None = None,
    ) -> dict:
        """دردشة كاملة مع كل المميزات."""
        start = time.time()
        self._stats["total_turns"] += 1
        context = context or {}

        # أنشئ session لو مش موجود
        if not session_id:
            session_id = await self.session_manager.create_session(model=self.config.ollama_model)

        # اجمع التاريخ
        history = await self.session_manager.get_messages(session_id, limit=50)
        history.extend(context.get("history", []))

        # ابنِ messages
        messages = self._build_messages(message, history, context)

        # اضغط السياق لو لازم
        messages, compression_stats = await self.compressor.compress(messages)
        if compression_stats.get("compressed"):
            self._stats["compressions"] += 1
            logger.info(
                f"Context compressed: {compression_stats['original_tokens']}→"
                f"{compression_stats['compressed_tokens']} tokens "
                f"(method={compression_stats['method']})"
            )

        # جرب LoRA (gemma4 12b) الأول
        response_text = None
        used_backend = None
        tokens_in = estimate_messages_tokens(messages)
        tokens_out = 0

        try:
            response_text = await self._call_lora(messages)
            used_backend = "lora"
            self._stats["lora_calls"] += 1
        except Exception as e:
            logger.warning(f"LoRA call failed: {e}")
            self._stats["errors"] += 1

        # fallback لـ Ollama
        if response_text is None:
            try:
                response_text = await self._call_ollama(messages)
                used_backend = "ollama"
                self._stats["ollama_calls"] += 1
            except Exception as e:
                logger.warning(f"Ollama call failed: {e}")
                self._stats["errors"] += 1
                response_text = self._mock_response(message)
                used_backend = "mock"

        # استخرج tool calls ونفذها
        tool_calls_made = []
        if "<tool_call>" in response_text:
            response_text, tool_calls_made = await self._process_tool_calls(
                response_text, message, session_id, messages
            )

        tokens_out = estimate_tokens(response_text)
        latency_ms = int((time.time() - start) * 1000)

        # سجل في الـ session
        await self.session_manager.add_message(
            session_id, "user", message,
            tokens_in=tokens_in, latency_ms=0,
        )
        await self.session_manager.add_message(
            session_id, "assistant", response_text,
            tokens_out=tokens_out, latency_ms=latency_ms,
            tool_calls=tool_calls_made,
            metadata={"backend": used_backend, "compression": compression_stats},
        )

        # لو أول رسالتين، ولّد عنوان
        if len(history) <= 1 and self.auxiliary:
            try:
                title = await self.auxiliary.generate_title(message, response_text)
                await self.session_manager.set_session_title(session_id, title)
            except Exception:
                pass

        return {
            "response": response_text,
            "session_id": session_id,
            "backend": used_backend,
            "tool_calls": tool_calls_made,
            "compression": compression_stats,
            "usage": {
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "latency_ms": latency_ms,
            },
        }

    async def chat_stream(
        self,
        message: str,
        session_id: str | None = None,
        context: dict | None = None,
    ) -> AsyncIterator[dict]:
        """دردشة مع streaming — يرجع chunks."""
        # للـ showcase، نرجع الرد كاملاً مرة واحدة
        # في الإنتاج، نعمل streaming فعلي من Ollama
        result = await self.chat(message, session_id, context)
        yield {"type": "chunk", "content": result["response"]}
        yield {"type": "done", "session_id": result["session_id"], "usage": result["usage"]}

    def _build_messages(
        self,
        user_message: str,
        history: list[dict],
        context: dict,
    ) -> list[dict]:
        """يبني قائمة الرسائل للـ LLM."""
        messages = [{"role": "system", "content": self.BASE_SYSTEM_PROMPT}]

        # ضم الذاكرة المسترجعة
        if context.get("memory"):
            memory_text = "\n".join(f"- {m}" for m in context["memory"][:5])
            messages.append({
                "role": "system",
                "content": f"## ذاكرة ذات صلة:\n{memory_text}",
            })

        # ضم التاريخ
        for msg in history[-20:]:  # آخر 20 رسالة كحد أقصى قبل الضغط
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                messages.append({"role": role, "content": content})

        # ضم المحتوى المرفق
        user_content = user_message
        attachments = context.get("attachments", [])
        for att in attachments:
            if att.get("type") == "file" and att.get("content"):
                user_content = (
                    f"--- FILE: {att.get('name', 'unknown')} ---\n"
                    f"{att['content'][:8000]}\n"
                    f"--- END FILE ---\n\n"
                    f"{user_content}"
                )
            elif att.get("type") == "image":
                user_content = f"[IMAGE: {att.get('name', 'image')}]\n{user_content}"

        messages.append({"role": "user", "content": user_content})
        return messages

    async def _call_lora(self, messages: list[dict]) -> str | None:
        """يستدعي LoRA server (gemma4 12b)."""
        client = await self._get_lora_client()
        last_exc = None

        # حدّ الـ chars لـ gemma4 (آمن)
        total_chars = sum(len(m.get("content", "")) for m in messages)
        if total_chars > self.config.lora_max_chars:
            # قص من النصوص الطويلة
            messages = self._truncate_messages(messages, self.config.lora_max_chars)

        for attempt in range(self.config.lora_max_retries):
            try:
                response = await client.post(
                    f"{self.config.lora_url}/chat",
                    json={"messages": messages},
                )
                response.raise_for_status()
                data = response.json()
                raw = data.get("response", "").strip()
                if not raw:
                    return None
                # نظّف tool_call syntax من الرد الظاهر للمستخدم
                clean = re.sub(
                    r'<tool_call>\s*\{.*?\}\s*</tool_call>',
                    '',
                    raw,
                    flags=re.DOTALL,
                )
                clean = re.sub(
                    r'<scratch_pad>.*?</scratch_pad>',
                    '',
                    clean,
                    flags=re.DOTALL,
                )
                return clean.strip() or raw.strip()
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self.config.lora_max_retries - 1:
                    delay = 0.5 * (2 ** attempt)
                    logger.warning(f"LoRA attempt {attempt+1} failed: {e}. Retrying in {delay}s")
                    await asyncio.sleep(delay)
            except Exception as e:
                logger.error(f"LoRA error: {e}")
                return None

        if last_exc:
            logger.error(f"LoRA failed after {self.config.lora_max_retries} attempts: {last_exc}")
        return None

    def _truncate_messages(self, messages: list[dict], max_chars: int) -> list[dict]:
        """يقص الرسائل الطويلة مع الحفاظ على system + آخر user."""
        if not messages:
            return messages

        result = [messages[0]]  # system prompt
        total = len(messages[0].get("content", ""))

        # امسك آخر 4 رسائل وأكتب اللي قبلها مختصرة
        if len(messages) > 6:
            tail = messages[-5:]
            head = messages[1:-5]
            # لخص الـ head في system message
            head_summary = "## ملخص المحادثة السابقة:\n"
            for m in head:
                content = m.get("content", "")[:300]
                head_summary += f"[{m['role']}]: {content}\n"
            result.append({"role": "system", "content": head_summary[:2000]})
            total += len(head_summary[:2000])
            messages = tail

        for m in messages[1:]:
            content = m.get("content", "")
            free = max_chars - total - 200  # buffer
            if free <= 0:
                break
            if len(content) > free:
                content = content[:free] + "...[مقتطع]"
            result.append({"role": m["role"], "content": content})
            total += len(content)

        return result

    async def _call_ollama(self, messages: list[dict]) -> str | None:
        """يستدعي Ollama كـ fallback."""
        client = await self._get_ollama_client()
        headers = {}
        if self.config.ollama_api_key:
            headers["Authorization"] = f"Bearer {self.config.ollama_api_key}"

        response = await client.post(
            f"{self.config.ollama_url}/api/chat",
            headers=headers,
            json={
                "model": self.config.ollama_model,
                "messages": messages,
                "stream": False,
            },
        )
        if response.status_code == 200:
            data = response.json()
            content = data.get("message", {}).get("content", "").strip()
            # نظّف tool_call syntax
            clean = re.sub(r'<tool_call>.*?</tool_call>', '', content, flags=re.DOTALL)
            clean = re.sub(r'<scratch_pad>.*?</scratch_pad>', '', clean, flags=re.DOTALL)
            return clean.strip() or content
        logger.warning(f"Ollama returned {response.status_code}: {response.text[:200]}")
        return None

    async def _process_tool_calls(
        self,
        response_text: str,
        user_message: str,
        session_id: str,
        messages: list[dict],
    ) -> tuple[str, list[dict]]:
        """يستخرج وينفذ tool calls من رد الموديل."""
        tool_calls_made = []

        # استخرج كل tool_call blocks
        pattern = r'<tool_call>\s*(\{.*?\})\s*</tool_call>'
        matches = re.findall(pattern, response_text, re.DOTALL)

        if not matches:
            return response_text, []

        # نفذ كل tool call
        for match in matches[:self.config.max_tool_calls_per_turn]:
            try:
                tool_call = json.loads(match)
                tool_name = tool_call.get("name", "")
                tool_args = tool_call.get("arguments", {})

                logger.info(f"Executing tool: {tool_name} with args: {tool_args}")

                result = await self.tools.execute(tool_name, tool_args)
                self._stats["tool_calls"] += 1

                tool_record = {
                    "name": tool_name,
                    "arguments": tool_args,
                    "success": result.success,
                    "result": result.result,
                    "error": result.error,
                    "latency_ms": result.latency_ms,
                }
                tool_calls_made.append(tool_record)

                # لو الأداة نجحت، ابعت نتيجتها للموديل عشان يكمل
                if result.success and len(matches) == 1:
                    try:
                        followup_messages = messages + [
                            {"role": "assistant", "content": response_text},
                            {
                                "role": "user",
                                "content": (
                                    f"نتيجة الأداة {tool_name}:\n"
                                    f"{json.dumps(result.result, ensure_ascii=False, indent=2)[:2000]}\n\n"
                                    f"استخدم هذه النتيجة للرد على المستخدم."
                                ),
                            },
                        ]
                        followup_response = await self._call_lora(followup_messages)
                        if followup_response:
                            # استبدل الـ tool_call بالرد النهائي
                            response_text = re.sub(
                                pattern,
                                '',
                                response_text,
                                flags=re.DOTALL,
                            ).strip()
                            response_text = followup_response
                    except Exception as e:
                        logger.warning(f"Follow-up LLM call failed: {e}")

            except json.JSONDecodeError as e:
                logger.warning(f"Invalid tool_call JSON: {e}")
            except Exception as e:
                logger.exception(f"Tool execution error: {e}")

        # شيل الـ tool_call syntax من الرد النهائي
        clean_response = re.sub(pattern, '', response_text, flags=re.DOTALL).strip()
        # شيل scratch_pad كمان
        clean_response = re.sub(r'<scratch_pad>.*?</scratch_pad>', '', clean_response, flags=re.DOTALL).strip()

        return clean_response or response_text, tool_calls_made

    def _mock_response(self, message: str) -> str:
        """رد احتياطي لو كل الـ LLMs فشلوا."""
        if any(w in message.lower() for w in ["مرحبا", "أهلا", "hello", "hi"]):
            return "أهلاً بيك! أنا آدم. للأسف الـ LLM مش متاح دلوقتي، بس لسه أقدر أساعدك. حاول تاني بعد شوية."
        return (
            f"استلمت رسالتك: «{message[:100]}»\n\n"
            "للأسف الـ LLM مش متاح دلوقتي. تأكد إن Ollama شغال:\n"
            "```bash\nollama serve\nollama list\n```\n"
            "أو شغّل LoRA server على :7861."
        )

    # ============================================================
    # Public API methods
    # ============================================================

    async def health_check(self) -> dict:
        """فحص صحة كل المكونات."""
        services = {"engine": True}

        # LoRA
        try:
            client = await self._get_lora_client()
            r = await client.get(f"{self.config.lora_url}/", timeout=2.0)
            services["lora"] = r.status_code in (200, 404, 405)
        except Exception:
            services["lora"] = False

        # Ollama
        try:
            client = await self._get_ollama_client()
            r = await client.get(f"{self.config.ollama_url}/api/tags", timeout=2.0)
            services["ollama"] = r.status_code == 200
        except Exception:
            services["ollama"] = False

        # Auxiliary
        if self.auxiliary:
            services["auxiliary"] = await self.auxiliary.health_check()
        else:
            services["auxiliary"] = False

        # Memory store
        services["memory"] = self.memory_store is not None

        # Session DB
        services["session_db"] = self.session_manager._conn is not None

        return {
            "status": "healthy" if all(services.values()) else "degraded",
            "services": services,
            "stats": self._stats,
        }

    def get_stats(self) -> dict:
        """إحصائيات المحرك."""
        return dict(self._stats)

    async def cleanup(self) -> None:
        """ينظف الموارد."""
        if self._lora_client and not self._lora_client.is_closed:
            await self._lora_client.aclose()
        if self._ollama_client and not self._ollama_client.is_closed:
            await self._ollama_client.aclose()
        if self.auxiliary:
            await self.auxiliary.cleanup()
        await self.tools.cleanup()
        self.session_manager.close()
        logger.info("AdamEngineV2 cleaned up")


# ============================================================
# Module-level singleton
# ============================================================

_engine: AdamEngineV2 | None = None


def get_engine() -> AdamEngineV2:
    """يرجع الـ engine المشترك."""
    global _engine
    if _engine is None:
        _engine = AdamEngineV2()
    return _engine


async def cleanup_engine() -> None:
    """ينظف الـ engine المشترك."""
    global _engine
    if _engine is not None:
        await _engine.cleanup()
        _engine = None
