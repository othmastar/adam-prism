"""
Adam Long-Term Memory with Vector Embeddings
=============================================
يغلق فجوة الـ "Memory drifts" مع Hermes-style persistent memory.

Features:
1. Vector embeddings عبر Ollama (nomic-embed-text) — semantic search حقيقي
2. SQLite + sqlite-vec للـ vector storage (بدون Qdrant external)
3. Hybrid search: BM25 (FTS5) + Vector similarity
4. Memory consolidation — دمج الذكريات المتشابهة
5. Memory decay — نقص الأولوية مع الوقت لو لم تُستخدم
6. Memory types: episodic, semantic, procedural, preference
7. Cross-session recall — استرجاع من جلسات سابقة
8. Auto-extraction — استخراج ذكريات تلقائياً من المحادثات

Schema:
  memories(id, content, embedding BLOB, type, priority, tags, source,
           session_id, created_at, accessed_at, access_count, decay_score)
  memories_fts (FTS5 virtual table for BM25)
  memory_consolidations (history of merges)

Usage:
    from adam.memory.long_term import LongTermMemory
    ltm = LongTermMemory(db_path="~/.adam/ltm.db",
                         ollama_url="http://localhost:11434",
                         embedding_model="nomic-embed-text")
    await ltm.init()
    await ltm.store("User likes Python", type="preference", priority=5)
    results = await ltm.search("programming languages", top_k=5)
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import os
import re
import sqlite3
import time
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger("adam_prism.ltm")


# ============================================================
# Constants
# ============================================================

EMBEDDING_DIM = 768  # nomic-embed-text default
DECAY_HALF_LIFE_DAYS = 30  # الأولوية تنصsf بعد 30 يوم لو لم تُستخدم
CONSOLIDATION_SIMILARITY_THRESHOLD = 0.85  # لو تشابه > 85%، ادمج
MAX_MEMORIES_PER_TYPE = 1000  # حد لكل نوع
DEFAULT_TOP_K = 5
BM25_WEIGHT = 0.4
VECTOR_WEIGHT = 0.6


# ============================================================
# Data Classes
# ============================================================

@dataclass
class Memory:
    """ذكرى واحدة."""
    id: int | None
    content: str
    type: str  # episodic, semantic, procedural, preference
    priority: int
    tags: list[str]
    source: str
    session_id: str | None
    created_at: str
    accessed_at: str | None
    access_count: int
    decay_score: float
    metadata: dict = field(default_factory=dict)


@dataclass
class SearchResult:
    """نتيجة بحث."""
    memory: Memory
    score: float
    bm25_score: float
    vector_score: float


# ============================================================
# Embedding Client
# ============================================================

class EmbeddingClient:
    """عميل embeddings عبر Ollama."""

    def __init__(
        self,
        ollama_url: str = "http://localhost:11434",
        model: str = "nomic-embed-text",
        timeout: float = 30.0,
        batch_size: int = 16,
    ):
        self.ollama_url = ollama_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.batch_size = batch_size
        self._client: httpx.AsyncClient | None = None
        self._cache: dict[str, list[float]] = {}

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                limits=httpx.Limits(max_connections=5, max_keepalive_connections=3),
            )
        return self._client

    def _hash(self, text: str) -> str:
        return hashlib.sha256(text.encode()).hexdigest()[:16]

    async def embed(self, text: str) -> list[float]:
        """يرجع embedding لنص واحد."""
        # cache check
        h = self._hash(text)
        if h in self._cache:
            return self._cache[h]

        client = await self._get_client()
        try:
            response = await client.post(
                f"{self.ollama_url}/api/embeddings",
                json={"model": self.model, "prompt": text[:8000]},  # limit
            )
            response.raise_for_status()
            data = response.json()
            embedding = data.get("embedding", [])
            if embedding and len(embedding) == EMBEDDING_DIM:
                # cache (limit size)
                if len(self._cache) > 500:
                    # evict random half
                    keys = list(self._cache.keys())[:250]
                    for k in keys:
                        del self._cache[k]
                self._cache[h] = embedding
                return embedding
            logger.warning(f"Bad embedding dim: {len(embedding)} (expected {EMBEDDING_DIM})")
            return []
        except Exception as e:
            logger.warning(f"Embedding failed: {e}")
            return []

    async def embed_batch(self, texts: list[str]) -> list[list[float]]:
        """يرجع embeddings لعدة نصوص."""
        results = []
        for i in range(0, len(texts), self.batch_size):
            batch = texts[i:i + self.batch_size]
            batch_embeddings = await asyncio.gather(*[self.embed(t) for t in batch])
            results.extend(batch_embeddings)
        return results

    async def health_check(self) -> bool:
        """يتحقق من توفر الـ embedding model."""
        try:
            emb = await self.embed("test")
            return len(emb) == EMBEDDING_DIM
        except Exception:
            return False

    async def cleanup(self) -> None:
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# ============================================================
# Vector Similarity (Cosine)
# ============================================================

def cosine_similarity(a: list[float], b: list[float]) -> float:
    """حساب التشابه الكوسينوسي بين متجهين."""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def serialize_vector(vec: list[float]) -> bytes:
    """يحول vector لـ bytes للتخزين."""
    import struct
    return struct.pack(f"{len(vec)}f", *vec)


def deserialize_vector(data: bytes) -> list[float]:
    """يرجع vector من bytes."""
    import struct
    if not data:
        return []
    n = len(data) // 4
    return list(struct.unpack(f"{n}f", data))


# ============================================================
# Memory Extractor — يستخرج ذكريات من المحادثات
# ============================================================

MEMORY_EXTRACTION_PROMPT = """Analyze this conversation and extract memories worth remembering for future interactions.

Output JSON only:
{
  "memories": [
    {
      "content": "concise factual statement",
      "type": "episodic|semantic|procedural|preference",
      "priority": 1-5,
      "tags": ["tag1", "tag2"]
    }
  ]
}

Memory types:
- episodic: specific events ("User asked about X yesterday")
- semantic: facts ("User's name is Mohamed", "User works at Y")
- procedural: how-to ("User prefers code in Python 3.12")
- preference: likes/dislikes ("User dislikes verbose responses")

Rules:
- Only extract WORTH REMEMBERING info (not small talk)
- Be concise (max 200 chars per memory)
- Skip if nothing worth remembering
- Output JSON only, no markdown"""

class MemoryExtractor:
    """يستخرج ذكريات من المحادثات بـ auxiliary LLM."""

    def __init__(self, auxiliary_client):
        self.aux = auxiliary_client

    async def extract(self, user_message: str, assistant_response: str) -> list[dict]:
        """يستخرج ذكريات من interaction."""
        if not self.aux:
            return []
        try:
            prompt = f"User: {user_message[:500]}\n\nAssistant: {assistant_response[:500]}"
            result = await self.aux.chat(
                [
                    {"role": "system", "content": MEMORY_EXTRACTION_PROMPT},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=400,
                temperature=0.1,
            )
            # parse JSON
            result = result.strip()
            if result.startswith("```"):
                result = re.sub(r"^```\w*\n?", "", result)
                result = re.sub(r"\n?```$", "", result)
            data = json.loads(result)
            return data.get("memories", [])
        except Exception as e:
            logger.debug(f"Memory extraction failed: {e}")
            return []


# ============================================================
# Main Long-Term Memory Class
# ============================================================

class LongTermMemory:
    """ذاكرة طويلة المدى مع vector embeddings."""

    def __init__(
        self,
        db_path: str = "~/.adam/ltm.db",
        ollama_url: str = "http://localhost:11434",
        embedding_model: str = "nomic-embed-text",
        auxiliary_client=None,
        enable_consolidation: bool = True,
        enable_decay: bool = True,
    ):
        self.db_path = str(Path(db_path).expanduser())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self.embedding_client = EmbeddingClient(ollama_url, embedding_model)
        self.extractor = MemoryExtractor(auxiliary_client) if auxiliary_client else None
        self.enable_consolidation = enable_consolidation
        self.enable_decay = enable_decay
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()

    async def init(self) -> None:
        """يهيّئ الـ DB والـ schema."""
        self._conn = sqlite3.connect(
            self.db_path,
            check_same_thread=False,
            isolation_level=None,
            timeout=30.0,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")

        # جدول الذكريات
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                content_hash TEXT NOT NULL,
                embedding BLOB,
                type TEXT NOT NULL DEFAULT 'semantic',
                priority INTEGER DEFAULT 3,
                tags TEXT DEFAULT '',
                source TEXT DEFAULT 'chat',
                session_id TEXT,
                created_at TEXT NOT NULL,
                accessed_at TEXT,
                access_count INTEGER DEFAULT 0,
                decay_score REAL DEFAULT 1.0,
                metadata TEXT DEFAULT '{}'
            )
        """)

        # فهرس الـ hash لمنع التكرار
        self._conn.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_memories_hash ON memories(content_hash)"
        )

        # FTS5 للبحث الكامل (BM25)
        try:
            self._conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
                USING fts5(content, tags, type, content='memories', content_rowid='id')
            """)
            # triggers
            self._conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories
                BEGIN
                    INSERT INTO memories_fts(rowid, content, tags, type)
                    VALUES (new.id, new.content, new.tags, new.type);
                END
            """)
            self._conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories
                BEGIN
                    INSERT INTO memories_fts(memories_fts, rowid, content, tags, type)
                    VALUES('delete', old.id, old.content, old.tags, old.type);
                END
            """)
            self._conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories
                BEGIN
                    INSERT INTO memories_fts(memories_fts, rowid, content, tags, type)
                    VALUES('delete', old.id, old.content, old.tags, old.type);
                    INSERT INTO memories_fts(rowid, content, tags, type)
                    VALUES (new.id, new.content, new.tags, new.type);
                END
            """)
        except sqlite3.OperationalError as e:
            logger.warning(f"FTS5 unavailable: {e}")

        # فهارس إضافية
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type, priority DESC)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_memories_session ON memories(session_id)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_memories_priority ON memories(decay_score DESC, priority DESC)"
        )

        # جدول consolidations
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS memory_consolidations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_ids TEXT NOT NULL,
                target_id INTEGER NOT NULL,
                similarity_score REAL,
                timestamp TEXT NOT NULL,
                FOREIGN KEY (target_id) REFERENCES memories(id)
            )
        """)

        logger.info(f"LTM initialized: {self.db_path}")

    async def close(self) -> None:
        """يقفل الـ DB."""
        await self.embedding_client.cleanup()
        if self._conn:
            self._conn.close()
            self._conn = None

    # ============================================================
    # Store
    # ============================================================

    async def store(
        self,
        content: str,
        type: str = "semantic",
        priority: int = 3,
        tags: list[str] | None = None,
        source: str = "chat",
        session_id: str | None = None,
        metadata: dict | None = None,
        skip_embedding: bool = False,
    ) -> int | None:
        """يخزّن ذكرى جديدة مع embedding."""
        if not content.strip():
            return None

        content = content.strip()[:2000]  # limit
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]

        async with self._lock:
            # تحقق من التكرار
            existing = self._conn.execute(
                "SELECT id, priority FROM memories WHERE content_hash = ?",
                (content_hash,),
            ).fetchone()
            if existing:
                # حدّث priority لو أعلى
                new_priority = max(existing["priority"], priority)
                self._conn.execute(
                    "UPDATE memories SET priority = ?, accessed_at = ?, access_count = access_count + 1 WHERE id = ?",
                    (new_priority, datetime.now().isoformat(), existing["id"]),
                )
                return existing["id"]

        # احسب embedding
        embedding = []
        if not skip_embedding:
            embedding = await self.embedding_client.embed(content)

        now = datetime.now().isoformat()
        tags_str = ",".join(tags) if tags else ""

        async with self._lock:
            cursor = self._conn.execute(
                """INSERT INTO memories
                   (content, content_hash, embedding, type, priority, tags, source,
                    session_id, created_at, accessed_at, access_count, decay_score, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    content,
                    content_hash,
                    serialize_vector(embedding) if embedding else None,
                    type,
                    max(1, min(5, priority)),
                    tags_str,
                    source,
                    session_id,
                    now,
                    now,
                    0,
                    1.0,
                    json.dumps(metadata or {}, ensure_ascii=False),
                ),
            )
            mem_id = cursor.lastrowid

        logger.debug(f"Stored memory {mem_id}: type={type}, priority={priority}")
        return mem_id

    async def store_from_conversation(
        self,
        user_message: str,
        assistant_response: str,
        session_id: str | None = None,
    ) -> list[int]:
        """يستخرج ويخزّن ذكريات من محادثة."""
        if not self.extractor:
            return []

        memories_data = await self.extractor.extract(user_message, assistant_response)
        stored_ids = []
        for mem in memories_data[:5]:  # limit per turn
            try:
                mem_id = await self.store(
                    content=mem.get("content", ""),
                    type=mem.get("type", "semantic"),
                    priority=int(mem.get("priority", 3)),
                    tags=mem.get("tags", []),
                    source="auto_extracted",
                    session_id=session_id,
                )
                if mem_id:
                    stored_ids.append(mem_id)
            except Exception as e:
                logger.warning(f"Failed to store extracted memory: {e}")

        if stored_ids:
            logger.info(f"Auto-extracted {len(stored_ids)} memories from conversation")

        # ادمج لو فيه ذكريات جديدة
        if self.enable_consolidation and stored_ids:
            asyncio.create_task(self._consolidate_similar())

        return stored_ids

    # ============================================================
    # Search — Hybrid (BM25 + Vector)
    # ============================================================

    async def search(
        self,
        query: str,
        top_k: int = DEFAULT_TOP_K,
        memory_type: str | None = None,
        min_priority: int = 1,
        session_id: str | None = None,
    ) -> list[SearchResult]:
        """بحث هجين: BM25 + Vector similarity."""
        if not query.strip():
            return []

        # طبّق decay الأول
        if self.enable_decay:
            self._apply_decay()

        # 1. BM25 search
        bm25_results = self._bm25_search(query, limit=top_k * 3, memory_type=memory_type,
                                          min_priority=min_priority, session_id=session_id)

        # 2. Vector search
        query_embedding = await self.embedding_client.embed(query)
        vector_results = []
        if query_embedding:
            vector_results = self._vector_search(
                query_embedding, limit=top_k * 3,
                memory_type=memory_type, min_priority=min_priority, session_id=session_id,
            )

        # 3. ادمج النتائج (hybrid)
        merged = self._merge_results(bm25_results, vector_results)

        # 4. رتّب وحدّد
        merged.sort(key=lambda x: x.score, reverse=True)
        results = merged[:top_k]

        # 5. حدّث access_count
        for r in results:
            async with self._lock:
                self._conn.execute(
                    "UPDATE memories SET access_count = access_count + 1, accessed_at = ? WHERE id = ?",
                    (datetime.now().isoformat(), r.memory.id),
                )

        return results

    def _bm25_search(
        self,
        query: str,
        limit: int,
        memory_type: str | None,
        min_priority: int,
        session_id: str | None,
    ) -> list[tuple[Memory, float]]:
        """بحث BM25 عبر FTS5."""
        # بناء استعلام FTS5
        clean = re.sub(r'[^\w\s\u0600-\u06FF]', ' ', query)
        words = clean.split()
        if not words:
            return []
        fts_query = " OR ".join(f'"{w}"*' for w in words[:5])

        sql = """
            SELECT m.*, bm25(memories_fts) as score
            FROM memories_fts f
            JOIN memories m ON m.id = f.rowid
            WHERE memories_fts MATCH ?
              AND m.priority >= ?
              AND m.decay_score > 0.1
        """
        params: list = [fts_query, min_priority]
        if memory_type:
            sql += " AND m.type = ?"
            params.append(memory_type)
        if session_id:
            sql += " AND m.session_id = ?"
            params.append(session_id)
        sql += " ORDER BY score ASC LIMIT ?"  # bm25 lower = better in SQLite
        params.append(limit)

        try:
            rows = self._conn.execute(sql, params).fetchall()
            # normalize bm25 score (SQLite returns negative; better = less negative)
            max_score = max(abs(r["score"]) for r in rows) if rows else 1.0
            return [
                (self._row_to_memory(r), 1.0 - (abs(r["score"]) / max_score if max_score > 0 else 0))
                for r in rows
            ]
        except sqlite3.OperationalError:
            # fallback لـ LIKE
            sql = """
                SELECT * FROM memories
                WHERE content LIKE ? AND priority >= ? AND decay_score > 0.1
            """
            params = [f"%{query}%", min_priority]
            if memory_type:
                sql += " AND type = ?"
                params.append(memory_type)
            sql += " ORDER BY priority DESC, access_count DESC LIMIT ?"
            params.append(limit)
            rows = self._conn.execute(sql, params).fetchall()
            return [(self._row_to_memory(r), 0.5) for r in rows]

    def _vector_search(
        self,
        query_embedding: list[float],
        limit: int,
        memory_type: str | None,
        min_priority: int,
        session_id: str | None,
    ) -> list[tuple[Memory, float]]:
        """بحث vector similarity."""
        # اجلب كل الذكريات (with embeddings)
        sql = """
            SELECT * FROM memories
            WHERE embedding IS NOT NULL
              AND priority >= ?
              AND decay_score > 0.1
        """
        params: list = [min_priority]
        if memory_type:
            sql += " AND type = ?"
            params.append(memory_type)
        if session_id:
            sql += " AND session_id = ?"
            params.append(session_id)
        sql += " ORDER BY priority DESC LIMIT ?"
        params.append(500)  # limit scan

        rows = self._conn.execute(sql, params).fetchall()
        results = []
        for row in rows:
            embedding = deserialize_vector(row["embedding"])
            if not embedding:
                continue
            sim = cosine_similarity(query_embedding, embedding)
            results.append((self._row_to_memory(row), sim))

        # رتّب
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:limit]

    def _merge_results(
        self,
        bm25: list[tuple[Memory, float]],
        vector: list[tuple[Memory, float]],
    ) -> list[SearchResult]:
        """يدمج نتائج BM25 و Vector."""
        merged: dict[int, SearchResult] = {}

        for mem, score in bm25:
            merged[mem.id] = SearchResult(
                memory=mem,
                score=score * BM25_WEIGHT,
                bm25_score=score,
                vector_score=0.0,
            )

        for mem, score in vector:
            if mem.id in merged:
                merged[mem.id].vector_score = score
                merged[mem.id].score += score * VECTOR_WEIGHT
            else:
                merged[mem.id] = SearchResult(
                    memory=mem,
                    score=score * VECTOR_WEIGHT,
                    bm25_score=0.0,
                    vector_score=score,
                )

        return list(merged.values())

    def _row_to_memory(self, row: sqlite3.Row) -> Memory:
        """يحوّل row لـ Memory object."""
        return Memory(
            id=row["id"],
            content=row["content"],
            type=row["type"],
            priority=row["priority"],
            tags=[t for t in (row["tags"] or "").split(",") if t],
            source=row["source"],
            session_id=row["session_id"],
            created_at=row["created_at"],
            accessed_at=row["accessed_at"],
            access_count=row["access_count"],
            decay_score=row["decay_score"],
            metadata=json.loads(row["metadata"] or "{}"),
        )

    # ============================================================
    # Decay — نقص الأولوية مع الوقت
    # ============================================================

    def _apply_decay(self) -> None:
        """يقلل الـ decay_score للذكريات القديمة غير المستخدمة."""
        # لو اتعمل decay قريب، تجاوز
        last_decay = getattr(self, "_last_decay", 0)
        if time.time() - last_decay < 3600:  # ساعة
            return
        self._last_decay = time.time()

        # صيغة: decay_score = exp(-elapsed_days / half_life)
        sql = """
            UPDATE memories
            SET decay_score = CASE
                WHEN accessed_at IS NULL THEN
                    exp(-julianday('now') - julianday(created_at) / ?)
                ELSE
                    exp(-julianday('now') - julianday(accessed_at) / ?)
            END
            WHERE decay_score > 0.05
        """
        try:
            self._conn.execute(sql, (DECAY_HALF_LIFE_DAYS, DECAY_HALF_LIFE_DAYS))
        except sqlite3.OperationalError:
            # SQLite القديم ما عنده exp — استخدم صيغة أبسط
            sql = """
                UPDATE memories
                SET decay_score = MAX(0.05,
                    1.0 - (julianday('now') - COALESCE(julianday(accessed_at), julianday(created_at))) / ?
                )
                WHERE decay_score > 0.05
            """
            self._conn.execute(sql, (DECAY_HALF_LIFE_DAYS * 2,))

    # ============================================================
    # Consolidation — دمج الذكريات المتشابهة
    # ============================================================

    async def _consolidate_similar(self) -> int:
        """يدمج الذكريات المتشابهة (لو تشابه > threshold)."""
        if not self._conn:
            return 0

        # اجلب آخر 50 ذكرى
        rows = self._conn.execute(
            "SELECT id, content, embedding, type FROM memories WHERE embedding IS NOT NULL ORDER BY id DESC LIMIT 50"
        ).fetchall()

        if len(rows) < 2:
            return 0

        merged_count = 0
        # قارن كل زوج
        for i, r1 in enumerate(rows):
            emb1 = deserialize_vector(r1["embedding"])
            if not emb1:
                continue
            for r2 in rows[i+1:]:
                if r1["type"] != r2["type"]:
                    continue
                emb2 = deserialize_vector(r2["embedding"])
                if not emb2:
                    continue
                sim = cosine_similarity(emb1, emb2)
                if sim > CONSOLIDATION_SIMILARITY_THRESHOLD:
                    # ادمج — احتفظ بالـ priority الأعلى
                    try:
                        async with self._lock:
                            # حدّث الأول
                            self._conn.execute(
                                """UPDATE memories SET
                                   priority = MAX(priority, ?),
                                   access_count = access_count + ?,
                                   metadata = ?
                                   WHERE id = ?""",
                                (
                                    r2["priority"],
                                    r2["access_count"] if "access_count" in r2.keys() else 0,
                                    json.dumps({"merged_from": r2["id"], "similarity": sim}),
                                    r1["id"],
                                ),
                            )
                            # احذف الثاني
                            self._conn.execute("DELETE FROM memories WHERE id = ?", (r2["id"],))
                            # سجل الدمج
                            self._conn.execute(
                                """INSERT INTO memory_consolidations
                                   (source_ids, target_id, similarity_score, timestamp)
                                   VALUES (?, ?, ?, ?)""",
                                (json.dumps([r2["id"]]), r1["id"], sim, datetime.now().isoformat()),
                            )
                            merged_count += 1
                    except Exception as e:
                        logger.debug(f"Consolidation failed: {e}")
                        break  # اخرج من الـ inner loop

        if merged_count:
            logger.info(f"Consolidated {merged_count} similar memories")
        return merged_count

    # ============================================================
    # Recall — استرجاع للسياق
    # ============================================================

    async def recall_for_context(
        self,
        query: str,
        max_memories: int = 5,
        max_chars: int = 1500,
    ) -> str:
        """يرجع نص الذكريات المناسبة للسياق."""
        results = await self.search(query, top_k=max_memories)
        if not results:
            return ""

        lines = []
        total_chars = 0
        for r in results:
            mem = r.memory
            line = f"- [{mem.type}] {mem.content}"
            if total_chars + len(line) > max_chars:
                break
            lines.append(line)
            total_chars += len(line)

        return "\n".join(lines) if lines else ""

    # ============================================================
    # Stats & Management
    # ============================================================

    def stats(self) -> dict:
        """إحصائيات."""
        if not self._conn:
            return {"available": False}

        total = self._conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        with_embedding = self._conn.execute(
            "SELECT COUNT(*) FROM memories WHERE embedding IS NOT NULL"
        ).fetchone()[0]
        by_type = {}
        for row in self._conn.execute(
            "SELECT type, COUNT(*) as cnt FROM memories GROUP BY type"
        ).fetchall():
            by_type[row["type"]] = row["cnt"]

        consolidations = self._conn.execute(
            "SELECT COUNT(*) FROM memory_consolidations"
        ).fetchone()[0]

        # متوسط الـ decay
        avg_decay = self._conn.execute(
            "SELECT AVG(decay_score) FROM memories"
        ).fetchone()[0] or 0.0

        return {
            "available": True,
            "total": total,
            "with_embeddings": with_embedding,
            "by_type": by_type,
            "consolidations_performed": consolidations,
            "avg_decay_score": round(avg_decay, 3),
            "embedding_model": self.embedding_client.model,
            "db_path": self.db_path,
        }

    async def health_check(self) -> dict:
        """فحص صحة."""
        embedding_ok = await self.embedding_client.health_check()
        return {
            "db_connected": self._conn is not None,
            "embedding_available": embedding_ok,
            "embedding_model": self.embedding_client.model,
            "extractor_available": self.extractor is not None,
        }

    async def delete(self, memory_id: int) -> bool:
        """يحذف ذكرى."""
        async with self._lock:
            cursor = self._conn.execute(
                "DELETE FROM memories WHERE id = ?", (memory_id,)
            )
            return cursor.rowcount > 0

    async def delete_all(self, memory_type: str | None = None) -> int:
        """يحذف كل الذكريات (أو نوع معين)."""
        async with self._lock:
            if memory_type:
                cursor = self._conn.execute(
                    "DELETE FROM memories WHERE type = ?", (memory_type,)
                )
            else:
                cursor = self._conn.execute("DELETE FROM memories")
            return cursor.rowcount
