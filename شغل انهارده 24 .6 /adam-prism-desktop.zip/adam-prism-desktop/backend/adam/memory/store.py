"""
Adam Memory Store — Persistent SQLite Memory
============================================
ذاكرة دائمة بـ SQLite + FTS5 للبحث الكامل.

Features:
- WAL mode للأداء العالي
- Full-text search مع دعم العربية
- Tags و priority
- Source tracking (chat/api/tool)
- TTL اختياري للذكريات

Usage:
    from adam.memory.store import MemoryStore
    store = MemoryStore("/path/to/memory.db")
    mem_id = store.store("معلومة مهمة", priority=5, tags="مهم")
    results = store.search("معلومة", limit=5)
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import sqlite3
import time
from datetime import datetime
from pathlib import Path
from typing import Any

logger = logging.getLogger("adam_prism.memory")


class MemoryStore:
    """مخزن الذاكرة المستمر."""

    def __init__(self, db_path: str = "~/.adam/memory.db"):
        self.db_path = str(Path(db_path).expanduser())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._init_db()

    def _init_db(self) -> None:
        """يهيّئ الـ DB."""
        self._conn = sqlite3.connect(
            self.db_path,
            check_same_thread=False,
            isolation_level=None,
            timeout=30.0,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")

        # جدول الذكريات
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                content TEXT NOT NULL,
                content_hash TEXT,
                priority INTEGER DEFAULT 3,
                tags TEXT DEFAULT '',
                source TEXT DEFAULT 'chat',
                created_at TEXT NOT NULL,
                accessed_at TEXT,
                access_count INTEGER DEFAULT 0,
                ttl_seconds INTEGER DEFAULT 0,
                metadata TEXT DEFAULT '{}'
            )
        """)

        # فهرس الـ FTS5 للبحث الكامل
        try:
            self._conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts
                USING fts5(content, tags, source, content='memories', content_rowid='id')
            """)
            # triggers للمزامنة
            self._conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories
                BEGIN
                    INSERT INTO memories_fts(rowid, content, tags, source)
                    VALUES (new.id, new.content, new.tags, new.source);
                END
            """)
            self._conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories
                BEGIN
                    INSERT INTO memories_fts(memories_fts, rowid, content, tags, source)
                    VALUES('delete', old.id, old.content, old.tags, old.source);
                END
            """)
            self._conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories
                BEGIN
                    INSERT INTO memories_fts(memories_fts, rowid, content, tags, source)
                    VALUES('delete', old.id, old.content, old.tags, old.source);
                    INSERT INTO memories_fts(rowid, content, tags, source)
                    VALUES (new.id, new.content, new.tags, new.source);
                END
            """)
            logger.info(f"MemoryStore initialized with FTS5: {self.db_path}")
        except sqlite3.OperationalError as e:
            logger.warning(f"FTS5 not available, using LIKE: {e}")
            # fallback — استخدم LIKE
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_memories_content ON memories(content)"
            )
            self._conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_memories_tags ON memories(tags)"
            )

        # فهارس إضافية
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_memories_priority ON memories(priority DESC)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at DESC)"
        )

    def store(
        self,
        content: str,
        priority: int = 3,
        tags: str = "",
        source: str = "chat",
        ttl_seconds: int = 0,
        metadata: dict | None = None,
    ) -> int:
        """يخزّن ذكرى جديدة. يرجع ID."""
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
        now = datetime.now().isoformat()

        # لو نفس المحتوى موجود، حدّث priority و access
        existing = self._conn.execute(
            "SELECT id FROM memories WHERE content_hash = ?",
            (content_hash,),
        ).fetchone()
        if existing:
            self._conn.execute(
                "UPDATE memories SET priority = MAX(priority, ?), accessed_at = ? WHERE id = ?",
                (priority, now, existing["id"]),
            )
            return existing["id"]

        cursor = self._conn.execute(
            """INSERT INTO memories
               (content, content_hash, priority, tags, source, created_at,
                accessed_at, ttl_seconds, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                content,
                content_hash,
                max(1, min(5, priority)),
                tags,
                source,
                now,
                now,
                ttl_seconds,
                str(metadata) if metadata else "{}",
            ),
        )
        mem_id = cursor.lastrowid
        logger.debug(f"Stored memory {mem_id}: {content[:50]}...")
        return mem_id

    def search(
        self,
        query: str,
        limit: int = 10,
        min_priority: int = 1,
        tags: str | None = None,
    ) -> list[dict]:
        """يبحث في الذكريات. يدعم FTS5 و LIKE fallback."""
        if not query.strip():
            return []

        # امسح الـ TTL منتهي الصلاحية
        self._cleanup_expired()

        results: list[sqlite3.Row] = []

        # جرب FTS5 الأول
        try:
            # escape special chars لـ FTS5
            fts_query = self._build_fts_query(query)
            sql = """
                SELECT m.* FROM memories m
                JOIN memories_fts f ON m.id = f.rowid
                WHERE memories_fts MATCH ?
                  AND m.priority >= ?
            """
            params: list = [fts_query, min_priority]
            if tags:
                sql += " AND m.tags LIKE ?"
                params.append(f"%{tags}%")
            sql += " ORDER BY m.priority DESC, m.accessed_at DESC LIMIT ?"
            params.append(limit)
            results = self._conn.execute(sql, params).fetchall()
        except (sqlite3.OperationalError, sqlite3.DatabaseError):
            # fallback لـ LIKE
            sql = """
                SELECT * FROM memories
                WHERE content LIKE ?
                  AND priority >= ?
            """
            params = [f"%{query}%", min_priority]
            if tags:
                sql += " AND tags LIKE ?"
                params.append(f"%{tags}%")
            sql += " ORDER BY priority DESC, accessed_at DESC LIMIT ?"
            params.append(limit)
            results = self._conn.execute(sql, params).fetchall()

        # حدّث access_count
        for r in results:
            self._conn.execute(
                "UPDATE memories SET access_count = access_count + 1, accessed_at = ? WHERE id = ?",
                (datetime.now().isoformat(), r["id"]),
            )

        return [dict(r) for r in results]

    def _build_fts_query(self, query: str) -> str:
        """يبني استعلام FTS5 آمن."""
        # شيل الأحرف الخاصة
        clean = re.sub(r'[^\w\s\u0600-\u06FF]', ' ', query)
        # قسّم لكلمات
        words = clean.split()
        if not words:
            return query
        # استخدم prefix matching لكل كلمة
        return " OR ".join(f'"{w}"*' for w in words[:5])

    def get(self, mem_id: int) -> dict | None:
        """يرجع ذكرى بـ ID."""
        row = self._conn.execute(
            "SELECT * FROM memories WHERE id = ?",
            (mem_id,),
        ).fetchone()
        return dict(row) if row else None

    def update(
        self,
        mem_id: int,
        content: str | None = None,
        priority: int | None = None,
        tags: str | None = None,
    ) -> bool:
        """يحدّث ذكرى."""
        updates = []
        params = []
        if content is not None:
            updates.append("content = ?")
            params.append(content)
            updates.append("content_hash = ?")
            params.append(hashlib.sha256(content.encode()).hexdigest()[:16])
        if priority is not None:
            updates.append("priority = ?")
            params.append(max(1, min(5, priority)))
        if tags is not None:
            updates.append("tags = ?")
            params.append(tags)

        if not updates:
            return False

        updates.append("accessed_at = ?")
        params.append(datetime.now().isoformat())
        params.append(mem_id)

        cursor = self._conn.execute(
            f"UPDATE memories SET {', '.join(updates)} WHERE id = ?",
            params,
        )
        return cursor.rowcount > 0

    def delete(self, mem_id: int) -> bool:
        """يحذف ذكرى."""
        cursor = self._conn.execute(
            "DELETE FROM memories WHERE id = ?",
            (mem_id,),
        )
        return cursor.rowcount > 0

    def stats(self) -> dict:
        """إحصائيات."""
        total = self._conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        by_priority = {}
        for row in self._conn.execute(
            "SELECT priority, COUNT(*) as cnt FROM memories GROUP BY priority"
        ).fetchall():
            by_priority[row["priority"]] = row["cnt"]
        by_source = {}
        for row in self._conn.execute(
            "SELECT source, COUNT(*) as cnt FROM memories GROUP BY source"
        ).fetchall():
            by_source[row["source"]] = row["cnt"]
        # أعلى الذكريات وصولاً
        top_accessed = [
            dict(r) for r in self._conn.execute(
                "SELECT id, content, access_count FROM memories ORDER BY access_count DESC LIMIT 5"
            ).fetchall()
        ]
        return {
            "total": total,
            "by_priority": by_priority,
            "by_source": by_source,
            "top_accessed": top_accessed,
            "db_path": self.db_path,
        }

    def _cleanup_expired(self) -> int:
        """يحذف الذكريات منتهية الصلاحية."""
        cursor = self._conn.execute(
            """DELETE FROM memories
               WHERE ttl_seconds > 0
                 AND julianday('now') - julianday(created_at) > ttl_seconds / 86400.0"""
        )
        return cursor.rowcount

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None
