"""
Adam Prism v3 — Comprehensive Test Suite
=========================================
يختبر كل المكونات:
1. Engine v3 initialization
2. Long-term memory (vector + BM25)
3. Browser automation (Playwright)
4. Session management
5. Tool execution
6. Context compression
7. API endpoints (28+)
8. WebSocket
9. Streaming
"""

import asyncio
import os
import sys
import json
import tempfile
from pathlib import Path

# setup
sys.path.insert(0, str(Path(__file__).parent / "backend"))

# env — disable LLMs للاختبار
os.environ["ADAM_AUXILIARY_ENABLED"] = "false"
os.environ["ADAM_BROWSER_ENABLED"] = "false"  # Playwright محتاج تثبيت
os.environ["LORA_SERVER_URL"] = "http://localhost:99999"
os.environ["ADAM_OLLAMA_URL"] = "http://localhost:99999"
os.environ["ADAM_SESSION_DB"] = "/tmp/adam_v3_test_sessions.db"
os.environ["ADAM_MEMORY_DB"] = "/tmp/adam_v3_test_memory.db"
os.environ["ADAM_LTM_DB"] = "/tmp/adam_v3_test_ltm.db"


async def test_engine_v3():
    """اختبار المحرك v3."""
    print("=" * 60)
    print("Adam Prism v3 — Comprehensive Test Suite")
    print("=" * 60)

    # import
    from adam.engine.engine_v3 import AdamEngineV3, EngineConfigV3

    config = EngineConfigV3.from_env()
    config.auxiliary_enabled = False
    config.browser_enabled = False  # Playwright مش متاح في الاختبار
    engine = AdamEngineV3(config)
    await engine.init()

    print(f"\n📊 Engine v3 initialized:")
    print(f"   LoRA: {engine.config.lora_url}")
    print(f"   Ollama: {engine.config.ollama_url}/{engine.config.ollama_model}")
    print(f"   Auxiliary: {'on' if engine.auxiliary else 'off'}")
    print(f"   LTM: {'on' if engine.ltm else 'off'}")
    print(f"   Browser: {'on' if engine.browser else 'off'}")

    # Test 1: Health check
    print("\n" + "─" * 60)
    print("Test 1: Health Check")
    print("─" * 60)
    health = await engine.health_check()
    print(f"Status: {health['status']}")
    for svc, ok in health["services"].items():
        print(f"  {svc}: {'✅' if ok else '❌'}")

    # Test 2: Tool Manifest
    print("\n" + "─" * 60)
    print("Test 2: Tool Manifest (v3)")
    print("─" * 60)
    manifest = engine.get_tool_manifest()
    print(f"Total tools: {manifest['total']}")
    print(f"Available: {manifest['available']}")
    for name, info in manifest["tools"].items():
        status = "✅" if info["available"] else "❌"
        print(f"  {status} {name}: {info['description'][:50]}")

    # Test 3: Long-term Memory (بدون embeddings لأن auxiliary off)
    print("\n" + "─" * 60)
    print("Test 3: Long-term Memory")
    print("─" * 60)
    if engine.ltm:
        # store
        mem_id = await engine.ltm.store(
            "اسم المستخدم محمد عثمان",
            type="semantic",
            priority=5,
            tags=["user", "name"],
        )
        print(f"Stored memory: {mem_id}")

        mem_id2 = await engine.ltm.store(
            "المستخدم يفضل البرمجة بـ Python",
            type="preference",
            priority=4,
            tags=["programming", "preference"],
        )
        print(f"Stored memory: {mem_id2}")

        # search (BM25 only لأن embeddings off)
        results = await engine.ltm.search("محمد", top_k=5)
        print(f"Search 'محمد': {len(results)} results")
        for r in results:
            print(f"  - score={r.score:.3f} bm25={r.bm25_score:.3f} vec={r.vector_score:.3f}")
            print(f"    content: {r.memory.content[:60]}")

        # recall for context
        context = await engine.ltm.recall_for_context("محمد عثمان", max_memories=3)
        print(f"Recall for context:\n{context}")

        # stats
        stats = engine.ltm.stats()
        print(f"LTM stats: total={stats['total']}, with_embeddings={stats['with_embeddings']}")

    # Test 4: Tool Execution
    print("\n" + "─" * 60)
    print("Test 4: Tool Execution")
    print("─" * 60)

    # memory_store (LTM)
    if engine.ltm:
        result = await engine.tools.execute(
            "memory_store",
            {"content": "اختبار من tool", "type": "semantic", "priority": 3},
        )
        print(f"memory_store (LTM): success={result.success}")

    # memory_recall (LTM)
    if engine.ltm:
        result = await engine.tools.execute("memory_recall", {"query": "اختبار"})
        print(f"memory_recall: success={result.success}")
        if result.success:
            print(f"  results: {len(result.result.get('results', []))}")

    # file operations
    result = await engine.tools.execute("file_write", {
        "path": "/tmp/adam_v3_test.txt",
        "content": "test from v3",
    })
    print(f"file_write: success={result.success}")

    result = await engine.tools.execute("file_read", {"path": "/tmp/adam_v3_test.txt"})
    print(f"file_read: success={result.success}")

    # shell
    result = await engine.tools.execute("shell", {"command": "echo v3test"})
    print(f"shell (allowed): success={result.success}")

    result = await engine.tools.execute("shell", {"command": "rm -rf /"})
    print(f"shell (blocked): success={result.success}, error={result.error}")

    # browser tools (متعطلة في الاختبار)
    result = await engine.tools.execute("browser_open", {"url": "https://example.com"})
    print(f"browser_open (disabled): success={result.success}, error={result.error}")

    # Test 5: Chat (mock fallback)
    print("\n" + "─" * 60)
    print("Test 5: Chat (Mock Fallback)")
    print("─" * 60)
    result = await engine.chat("مرحبا")
    print(f"Backend: {result['backend']}")
    print(f"Response: {result['response'][:150]}")
    print(f"LTM used: {result.get('ltm_used', False)}")
    print(f"Usage: {result['usage']}")

    # Test 6: Stats
    print("\n" + "─" * 60)
    print("Test 6: Engine Stats")
    print("─" * 60)
    stats = engine.get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")

    await engine.cleanup()
    print("\n" + "=" * 60)
    print("✅ Engine v3 tests passed!")
    print("=" * 60)


async def test_api_v3():
    """اختبار الـ API server v3."""
    print("\n" + "=" * 60)
    print("Adam Prism v3 — API Server Tests")
    print("=" * 60)

    from fastapi.testclient import TestClient
    from adam.api.server_v3 import app

    client = TestClient(app)

    tests_passed = 0
    tests_failed = 0

    def check(name, condition, details=""):
        nonlocal tests_passed, tests_failed
        if condition:
            tests_passed += 1
            print(f"  ✅ {name}")
            if details:
                print(f"     {details}")
        else:
            tests_failed += 1
            print(f"  ❌ {name}")
            if details:
                print(f"     {details}")

    # 1. Basic
    print("\n─── 1. Basic Endpoints ───")
    r = client.get("/healthz/live")
    check("GET /healthz/live", r.status_code == 200, f"version={r.json().get('version')}")

    r = client.get("/api/status")
    check("GET /api/status", r.status_code == 200)

    r = client.get("/api/engine/health")
    data = r.json()
    check("GET /api/engine/health", r.status_code == 200, f"services: {data['services']}")

    # 2. Chat
    print("\n─── 2. Chat ───")
    r = client.post("/api/chat", json={"message": "مرحبا"})
    data = r.json()
    check("POST /api/chat", r.status_code == 200, f"backend={data.get('backend')}")

    # 3. Sessions
    print("\n─── 3. Sessions ───")
    r = client.get("/api/chat/sessions")
    check("GET /api/chat/sessions", r.status_code == 200)

    # 4. LTM
    print("\n─── 4. Long-Term Memory ───")
    r = client.post("/api/ltm/store", json={
        "content": "test memory from API",
        "type": "semantic",
        "priority": 3
    })
    check("POST /api/ltm/store", r.status_code == 200 and r.json()["success"])

    r = client.get("/api/ltm/search?query=test")
    data = r.json()
    check("GET /api/ltm/search", r.status_code == 200, f"total={data['total']}")

    r = client.get("/api/ltm/stats")
    check("GET /api/ltm/stats", r.status_code == 200)

    r = client.get("/api/ltm/health")
    check("GET /api/ltm/health", r.status_code == 200)

    # 5. Browser (متعطل في الاختبار)
    print("\n─── 5. Browser (disabled in test) ───")
    r = client.post("/api/browser/open", json={"url": "https://example.com"})
    check("POST /api/browser/open (disabled)", r.status_code == 503)

    r = client.get("/api/browser/stats")
    check("GET /api/browser/stats", r.status_code == 200)

    # 6. Tools
    print("\n─── 6. Tools ───")
    r = client.get("/api/tools/manifest")
    data = r.json()
    check("GET /api/tools/manifest", r.status_code == 200, f"total={data['total']}, available={data['available']}")

    r = client.post("/api/tools/action", json={"name": "disk_space", "arguments": {}})
    check("POST /api/tools/action (disk_space)", r.json()["success"])

    r = client.post("/api/tools/action", json={"name": "shell", "arguments": {"command": "echo apitest"}})
    check("POST /api/tools/action (shell allowed)", r.json()["success"])

    r = client.post("/api/tools/action", json={"name": "shell", "arguments": {"command": "rm -rf /"}})
    check("POST /api/tools/action (shell blocked)", not r.json()["success"])

    r = client.post("/api/tools/action", json={"name": "memory_store", "arguments": {"content": "API test memory"}})
    check("POST /api/tools/action (memory_store LTM)", r.json()["success"])

    # 7. Memory (short-term)
    print("\n─── 7. Short-term Memory ───")
    r = client.post("/api/memory/store", json={"content": "short term test"})
    check("POST /api/memory/store", r.status_code == 200)

    r = client.get("/api/memory/recall?query=short")
    check("GET /api/memory/recall", r.status_code == 200)

    # 8. JSON Mode
    print("\n─── 8. JSON Mode ───")
    r = client.post("/api/json-mode", json={
        "schema": {"name": "string"},
        "query": "ما اسم المستخدم؟"
    })
    check("POST /api/json-mode", r.status_code == 200)

    # 9. Metrics
    print("\n─── 9. Metrics ───")
    r = client.get("/metrics")
    check("GET /metrics", r.status_code == 200 and "adam_" in r.text)

    # 10. WebSocket
    print("\n─── 10. WebSocket ───")
    try:
        with client.websocket_connect("/ws/chat") as ws:
            ws.send_json({"message": "hello"})
            data = ws.receive_json()
            check("WebSocket /ws/chat", data.get("type") == "response")
    except Exception as e:
        check("WebSocket /ws/chat", False, str(e)[:100])

    # Summary
    print("\n" + "=" * 60)
    print(f"  API Tests: {tests_passed} passed, {tests_failed} failed")
    print("=" * 60)

    return tests_failed == 0


async def main():
    # cleanup
    for f in ["/tmp/adam_v3_test_sessions.db", "/tmp/adam_v3_test_memory.db",
              "/tmp/adam_v3_test_ltm.db", "/tmp/adam_v3_test_sessions.db-wal",
              "/tmp/adam_v3_test_sessions.db-shm", "/tmp/adam_v3_test_ltm.db-wal",
              "/tmp/adam_v3_test_ltm.db-shm"]:
        try:
            os.unlink(f)
        except Exception:
            pass

    await test_engine_v3()
    api_ok = await test_api_v3()

    print("\n" + "=" * 60)
    if api_ok:
        print("🎉 كل الاختبارات نجحت! Adam Prism v3 جاهز للنشر.")
    else:
        print("⚠️  فيه اختبارات فشلت. راجع التفاصيل فوق.")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
