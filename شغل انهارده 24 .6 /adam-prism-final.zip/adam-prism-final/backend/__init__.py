"""Adam Prism — backend package marker."""
