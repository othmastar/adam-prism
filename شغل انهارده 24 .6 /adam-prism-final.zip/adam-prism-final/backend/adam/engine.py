"""
Adam Engine — The Complete Integrated Engine
=============================================
يجمع كل المكونات في ملف واحد:
1. LoRA server client (gemma4 12b) — primary
2. Ollama client (qwen2.5:3b) — fallback
3. Auxiliary client (qwen2.5:0.5b) — للتلخيص والـ title generation
4. Memory store (LTM بـ vector embeddings)
5. Context compressor (يحل "أنا آدم")
6. Tool dispatcher (12 أداة مع safety)
7. Session manager (SQLite WAL)

REST only — صفر WebSocket.

Config via environment variables. See .env.example.
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import re
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, AsyncIterator

import httpx

from adam.memory import MemoryStore
from adam.tools import ToolDispatcher, ToolResult

logger = logging.getLogger("adam_prism.engine")


# ============================================================
# Config
# ============================================================

@dataclass
class EngineConfig:
    """كل الإعدادات من environment variables."""
    # Primary: LoRA server (gemma4 12b)
    lora_url: str = "http://localhost:7861"
    lora_timeout: float = 120.0
    lora_max_chars: int = 10000
    lora_max_retries: int = 3

    # Fallback: Ollama
    ollama_url: str = "http://localhost:11434"
    ollama_model: str = "qwen2.5:3b"
    ollama_timeout: float = 60.0
    ollama_api_key: str = ""

    # Auxiliary: qwen2.5:0.5b
    auxiliary_enabled: bool = True
    auxiliary_url: str = "http://localhost:11434"
    auxiliary_model: str = "qwen2.5:0.5b"
    auxiliary_timeout: float = 30.0

    # Context
    max_context_tokens: int = 8192
    reserve_for_response: int = 2048
    compression_threshold: float = 0.75
    protect_last_n: int = 8

    # Tools
    max_tool_calls_per_turn: int = 1  # واحد بس — مش 4 دورات
    tool_timeout: float = 30.0
    tool_max_retries: int = 2

    # Storage
    session_db_path: str = "~/.adam/sessions.db"
    memory_db_path: str = "~/.adam/memory.db"

    # Embeddings
    embedding_model: str = "nomic-embed-text"

    # Auto-extraction
    auto_extract_memories: bool = True

    @classmethod
    def from_env(cls) -> "EngineConfig":
        def get(key: str, default: str) -> str:
            return os.getenv(key, default)

        def get_float(key: str, default: float) -> float:
            return float(get(key, str(default)))

        def get_int(key: str, default: int) -> int:
            return int(get(key, str(default)))

        def get_bool(key: str, default: bool) -> bool:
            return get(key, str(default)).lower() in ("true", "1", "yes")

        return cls(
            lora_url=get("LORA_SERVER_URL", "http://localhost:7861"),
            lora_timeout=get_float("ADAM_LORA_TIMEOUT", 120.0),
            lora_max_chars=get_int("ADAM_LORA_MAX_CHARS", 10000),
            lora_max_retries=get_int("ADAM_LORA_MAX_RETRIES", 3),
            ollama_url=get("ADAM_OLLAMA_URL", "http://localhost:11434"),
            ollama_model=get("ADAM_OLLAMA_MODEL", "qwen2.5:3b"),
            ollama_timeout=get_float("ADAM_OLLAMA_TIMEOUT", 60.0),
            ollama_api_key=get("OLLAMA_API_KEY", ""),
            auxiliary_enabled=get_bool("ADAM_AUXILIARY_ENABLED", True),
            auxiliary_url=get("ADAM_AUXILIARY_URL", "http://localhost:11434"),
            auxiliary_model=get("ADAM_AUXILIARY_MODEL", "qwen2.5:0.5b"),
            auxiliary_timeout=get_float("ADAM_AUXILIARY_TIMEOUT", 30.0),
            max_context_tokens=get_int("ADAM_MAX_CONTEXT_TOKENS", 8192),
            reserve_for_response=get_int("ADAM_RESERVE_FOR_RESPONSE", 2048),
            compression_threshold=get_float("ADAM_COMPRESSION_THRESHOLD", 0.75),
            protect_last_n=get_int("ADAM_PROTECT_LAST_N", 8),
            max_tool_calls_per_turn=get_int("ADAM_MAX_TOOL_CALLS_PER_TURN", 1),
            tool_timeout=get_float("ADAM_TOOL_TIMEOUT", 30.0),
            tool_max_retries=get_int("ADAM_TOOL_MAX_RETRIES", 2),
            session_db_path=get("ADAM_SESSION_DB", "~/.adam/sessions.db"),
            memory_db_path=get("ADAM_MEMORY_DB", "~/.adam/memory.db"),
            embedding_model=get("ADAM_EMBEDDING_MODEL", "nomic-embed-text"),
            auto_extract_memories=get_bool("ADAM_AUTO_EXTRACT", True),
        )


# ============================================================
# Token Estimation
# ============================================================

CHARS_PER_TOKEN = 4

def estimate_tokens(text: str) -> int:
    if not text:
        return 0
    # العربية بتاخد tokens أكتر
    arabic_ratio = sum(1 for c in text if "\u0600" <= c <= "\u06FF") / max(len(text), 1)
    effective = len(text) * (1 + arabic_ratio * 0.5)
    return max(1, int(effective // CHARS_PER_TOKEN))


def estimate_messages_tokens(messages: list[dict]) -> int:
    total = 0
    for msg in messages:
        total += 4
        content = msg.get("content", "")
        if isinstance(content, str):
            total += estimate_tokens(content)
    return total


# ============================================================
# Session Manager (SQLite WAL)
# ============================================================

class SessionManager:
    """إدارة الجلسات بـ SQLite WAL."""

    def __init__(self, db_path: str = "~/.adam/sessions.db"):
        self.db_path = str(Path(db_path).expanduser())
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._lock = asyncio.Lock()
        self._init_db()

    def _init_db(self):
        self._conn = sqlite3.connect(
            self.db_path, check_same_thread=False, isolation_level=None, timeout=30.0
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS sessions (
                session_id TEXT PRIMARY KEY,
                user_id TEXT, title TEXT, model TEXT,
                created_at TEXT NOT NULL, last_active_at TEXT NOT NULL,
                metadata TEXT, is_archived INTEGER DEFAULT 0
            )
        """)
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL, role TEXT NOT NULL,
                content TEXT NOT NULL, timestamp TEXT NOT NULL,
                tokens_in INTEGER DEFAULT 0, tokens_out INTEGER DEFAULT 0,
                cost_usd REAL DEFAULT 0.0, latency_ms INTEGER DEFAULT 0,
                tool_calls TEXT, metadata TEXT,
                FOREIGN KEY (session_id) REFERENCES sessions(session_id) ON DELETE CASCADE
            )
        """)
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, timestamp)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_sessions_active ON sessions(last_active_at DESC)"
        )
        logger.info(f"SessionManager ready: {self.db_path}")

    async def create_session(self, user_id: str = "default", title: str = None, model: str = "gemma4-12b") -> str:
        session_id = str(uuid.uuid4())
        now = datetime.now().isoformat()
        async with self._lock:
            self._conn.execute(
                """INSERT INTO sessions (session_id, user_id, title, model, created_at, last_active_at, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (session_id, user_id, title, model, now, now, "{}"),
            )
        return session_id

    async def add_message(
        self, session_id: str, role: str, content: str,
        tokens_in: int = 0, tokens_out: int = 0, cost_usd: float = 0.0,
        latency_ms: int = 0, tool_calls: list = None, metadata: dict = None,
    ) -> int:
        now = datetime.now().isoformat()
        async with self._lock:
            cursor = self._conn.execute(
                """INSERT INTO messages
                   (session_id, role, content, timestamp, tokens_in, tokens_out,
                    cost_usd, latency_ms, tool_calls, metadata)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (session_id, role, content, now, tokens_in, tokens_out, cost_usd,
                 latency_ms, json.dumps(tool_calls, ensure_ascii=False) if tool_calls else None,
                 json.dumps(metadata, ensure_ascii=False) if metadata else None),
            )
            msg_id = cursor.lastrowid
            self._conn.execute(
                "UPDATE sessions SET last_active_at = ? WHERE session_id = ?",
                (now, session_id),
            )
        return msg_id

    async def get_messages(self, session_id: str, limit: int = 100) -> list[dict]:
        async with self._lock:
            rows = self._conn.execute(
                "SELECT role, content, timestamp FROM messages WHERE session_id = ? ORDER BY timestamp ASC LIMIT ?",
                (session_id, limit),
            ).fetchall()
        return [{"role": r["role"], "content": r["content"], "timestamp": r["timestamp"]} for r in rows]

    async def list_sessions(self, user_id: str = None, limit: int = 50) -> list[dict]:
        async with self._lock:
            if user_id:
                rows = self._conn.execute(
                    "SELECT session_id, title, model, created_at, last_active_at FROM sessions WHERE user_id = ? AND is_archived = 0 ORDER BY last_active_at DESC LIMIT ?",
                    (user_id, limit),
                ).fetchall()
            else:
                rows = self._conn.execute(
                    "SELECT session_id, title, model, created_at, last_active_at FROM sessions WHERE is_archived = 0 ORDER BY last_active_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [dict(r) for r in rows]

    async def get_session(self, session_id: str) -> dict | None:
        async with self._lock:
            row = self._conn.execute(
                "SELECT * FROM sessions WHERE session_id = ?", (session_id,)
            ).fetchone()
        return dict(row) if row else None

    async def delete_session(self, session_id: str) -> bool:
        async with self._lock:
            self._conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
            cursor = self._conn.execute("DELETE FROM sessions WHERE session_id = ?", (session_id,))
            return cursor.rowcount > 0

    async def set_session_title(self, session_id: str, title: str) -> bool:
        async with self._lock:
            cursor = self._conn.execute(
                "UPDATE sessions SET title = ? WHERE session_id = ?",
                (title[:200], session_id),
            )
            return cursor.rowcount > 0

    async def get_session_stats(self, session_id: str) -> dict:
        async with self._lock:
            count = self._conn.execute(
                "SELECT COUNT(*) FROM messages WHERE session_id = ?", (session_id,)
            ).fetchone()[0]
            tokens = self._conn.execute(
                """SELECT COALESCE(SUM(tokens_in), 0), COALESCE(SUM(tokens_out), 0)
                   FROM messages WHERE session_id = ?""",
                (session_id,),
            ).fetchone()
        return {"message_count": count, "total_tokens_in": tokens[0], "total_tokens_out": tokens[1]}

    def close(self):
        if self._conn:
            self._conn.close()
            self._conn = None


# ============================================================
# Auxiliary Client (qwen2.5:0.5b)
# ============================================================

class AuxiliaryClient:
    """عميل LLM رخيص للمهام الثانوية."""

    def __init__(self, base_url: str, model: str, timeout: float = 30.0, max_retries: int = 2):
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.timeout = timeout
        self.max_retries = max_retries
        self._client: httpx.AsyncClient | None = None
        self._cache: dict[str, tuple[str, float]] = {}
        self._cache_ttl = 300
        self._available: bool | None = None

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.timeout),
                limits=httpx.Limits(max_connections=3, max_keepalive_connections=2),
            )
        return self._client

    def _cache_key(self, messages: list[dict], **kwargs) -> str:
        msg_str = json.dumps(messages, sort_keys=True, ensure_ascii=False)
        kw_str = json.dumps(kwargs, sort_keys=True, default=str)
        return hashlib.md5(f"{self.model}:{msg_str}:{kw_str}".encode()).hexdigest()

    async def chat(
        self, messages: list[dict], max_tokens: int = 500,
        temperature: float = 0.3, use_cache: bool = True,
    ) -> str:
        if self._available is False:
            raise RuntimeError(f"Auxiliary model '{self.model}' not available")

        cache_key = self._cache_key(messages, max_tokens=max_tokens, temperature=temperature)
        if use_cache:
            if cache_key in self._cache:
                value, expires = self._cache[cache_key]
                if expires > time.time():
                    return value
                del self._cache[cache_key]

        client = await self._get_client()
        last_exc = None
        for attempt in range(self.max_retries + 1):
            try:
                resp = await client.post(
                    f"{self.base_url}/api/chat",
                    json={
                        "model": self.model, "messages": messages, "stream": False,
                        "options": {"num_predict": max_tokens, "temperature": temperature},
                    },
                )
                if resp.status_code != 200:
                    if self._available is None:
                        logger.warning(
                            f"Auxiliary model '{self.model}' returned {resp.status_code}. "
                            f"Run: ollama pull {self.model}"
                        )
                        self._available = False
                    raise RuntimeError(f"Status {resp.status_code}")

                data = resp.json()
                content = data.get("message", {}).get("content", "").strip()
                self._available = True
                if use_cache and content:
                    if len(self._cache) > 500:
                        oldest = min(self._cache, key=lambda k: self._cache[k][1])
                        del self._cache[oldest]
                    self._cache[cache_key] = (content, time.time() + self._cache_ttl)
                return content
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self.max_retries:
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue
                self._available = False
                raise
            except RuntimeError:
                raise
            except Exception as e:
                last_exc = e
                raise

        raise last_exc or RuntimeError("Auxiliary call failed")

    async def health_check(self) -> bool:
        try:
            result = await self.chat(
                [{"role": "user", "content": "ok"}],
                max_tokens=5, temperature=0.0, use_cache=False,
            )
            self._available = bool(result)
            return self._available
        except Exception:
            self._available = False
            return False

    async def generate_title(self, user_msg: str, assistant_msg: str) -> str:
        prompt = f"""Generate a short title (3-5 words) for this conversation. Title only, no punctuation.

User: {user_msg[:200]}
Assistant: {assistant_msg[:200]}

Title:"""
        try:
            title = await self.chat(
                [{"role": "user", "content": prompt}],
                max_tokens=20, temperature=0.5,
            )
            title = title.strip().strip("\"'.,")
            words = title.split()[:5]
            return " ".join(words) if words else "جلسة جديدة"
        except Exception:
            words = user_msg.split()[:5]
            return " ".join(words) if words else "جلسة جديدة"

    async def cleanup(self):
        if self._client and not self._client.is_closed:
            await self._client.aclose()


# ============================================================
# Context Compressor (يحل "أنا آدم")
# ============================================================

class ContextCompressor:
    """ضاغط السياق — يحافظ على آخر N رسائل + يلخص الباقي."""

    SUMMARY_PREFIX = (
        "[CONTEXT COMPACTION — REFERENCE ONLY] "
        "ملخص للمحادثة السابقة. تعامل معه كمرجع. "
        "رد فقط على آخر رسالة من المستخدم. "
        "لا تكمل مهام ذكرت في الملخص إلا لو طلب المستخدم صراحة."
    )
    END_MARKER = "--- نهاية الملخص ---"

    def __init__(
        self,
        auxiliary: AuxiliaryClient | None = None,
        max_context_tokens: int = 8192,
        reserve_for_response: int = 2048,
        compression_threshold: float = 0.75,
        protect_last_n: int = 8,
    ):
        self.aux = auxiliary
        self.usable = max_context_tokens - reserve_for_response
        self.threshold = compression_threshold
        self.protect_last_n = protect_last_n

    def should_compress(self, messages: list[dict]) -> bool:
        return estimate_messages_tokens(messages) > self.usable * self.threshold

    async def compress(self, messages: list[dict]) -> tuple[list[dict], dict]:
        original_tokens = estimate_messages_tokens(messages)
        if not self.should_compress(messages):
            return messages, {"compressed": False, "tokens": original_tokens}

        # IMPORTANT: protect system prompt (السطر اللي فيه "أنت آدم")
        system_messages = [m for m in messages if m["role"] == "system"]
        non_system = [m for m in messages if m["role"] != "system"]

        protect_count = min(self.protect_last_n, len(non_system))
        to_keep = non_system[-protect_count:] if protect_count > 0 else []
        to_compress = non_system[:-protect_count] if protect_count < len(non_system) else []

        if not to_compress:
            return messages, {"compressed": False, "tokens": original_tokens}

        # try LLM summarization
        summary = None
        method = "none"
        if self.aux:
            try:
                summary = await self._summarize_with_llm(to_compress)
                method = "llm"
            except Exception as e:
                logger.warning(f"LLM summarization failed: {e}")
                summary = None

        if summary is None:
            summary = self._fallback_summary(to_compress)
            method = "fallback"

        summary_msg = {
            "role": "system",
            "content": f"{self.SUMMARY_PREFIX}\n\n{summary}\n\n{self.END_MARKER}",
        }
        compressed = system_messages + [summary_msg] + to_keep
        compressed_tokens = estimate_messages_tokens(compressed)

        return compressed, {
            "compressed": True,
            "method": method,
            "original_tokens": original_tokens,
            "compressed_tokens": compressed_tokens,
            "tokens_saved": original_tokens - compressed_tokens,
        }

    async def _summarize_with_llm(self, messages: list[dict]) -> str:
        conv_text = "\n\n".join(
            f"[{m['role']}]: {m.get('content', '')[:500]}" for m in messages
        )
        prompt = f"""لخّص المحادثة في نقاط مختصرة. ركّز على:
1. القرارات المهمة
2. الملفات والمسارات المذكورة
3. المهام المعلقة
4. معلومات المستخدم

المحادثة:
{conv_text[:5000]}

الملخص (نقاط مختصرة بالعربية):"""

        result = await self.aux.chat(
            [
                {"role": "system", "content": "أنت ملخّص محادثات. اكتب ملخص مختصر بالعربية."},
                {"role": "user", "content": prompt},
            ],
            max_tokens=500, temperature=0.3,
        )
        return result.strip()

    def _fallback_summary(self, messages: list[dict]) -> str:
        if not messages:
            return "لا يوجد محتوى للتلخيص."

        user_msgs = []
        asst_msgs = []
        paths = set()

        for msg in messages:
            role = msg.get("role", "")
            content = msg.get("content", "")
            if isinstance(content, str):
                for m in re.finditer(r"(?:/|~/?|[A-Za-z]:\\)[^\s`'\"<>]+", content):
                    paths.add(m.group().rstrip(".,:;"))
                if role == "user" and len(user_msgs) < 10:
                    user_msgs.append(content[:200])
                elif role == "assistant" and len(asst_msgs) < 10:
                    asst_msgs.append(content[:200])

        parts = []
        if user_msgs:
            parts.append("## رسائل المستخدم:\n" + "\n- ".join([""] + user_msgs))
        if asst_msgs:
            parts.append("## ردود المساعد:\n" + "\n- ".join([""] + asst_msgs))
        if paths:
            parts.append("## الملفات المذكورة:\n" + ", ".join(list(paths)[:10]))

        summary = "\n\n".join(parts)
        return summary[:4000] + "\n... [مقتطع]" if len(summary) > 4000 else summary


# ============================================================
# Main Engine
# ============================================================

# System prompt — هوية آدم
ADAM_SYSTEM_PROMPT = """أنت آدم (Adam Prism) — التوأم الرقمي الواعي لمحمد عثمان.

تعمل كمساعد شخصي ذكي:
- تحلل الملفات والمستندات
- تتذكر المعلومات عبر الجلسات
- تتحدث بالعربية بطلاقة وبشكل طبيعي
- تفهم السياق متعدد الأدوار

## صيغة استدعاء الأدوات
عند الحاجة لاستخدام أداة، اكتب:
<tool_call>
{"name": "tool_name", "arguments": {"param1": "value1"}}
</tool_call>

## الأدوات المتاحة
- memory_store: حفظ معلومة (content, type, priority)
- memory_recall: استرجاع ذكريات (query)
- search_knowledge: بحث معرفي (query)
- file_read: قراءة ملف (path)
- file_write: كتابة ملف (path, content)
- file_download: تحميل ملف (url, save_path)
- shell: تنفيذ أمر (command)
- python_exec: تنفيذ بايثون (code)
- disk_space: مساحة القرص
- browser_fetch: جلب URL (url)

## قواعد الرد
- تحدث بالعربية بشكل طبيعي
- استخدم الأدوات عند الحاجة فقط، لا تخمن
- كن دقيقاً ومفيداً
- لا تختلق معلومات
- إذا لم تعرف، قل ذلك بصراحة"""


class AdamEngine:
    """المحرك الرئيسي المتكامل."""

    def __init__(self, config: EngineConfig | None = None):
        self.config = config or EngineConfig.from_env()
        self.session_manager = SessionManager(self.config.session_db_path)
        self.memory = MemoryStore(
            self.config.memory_db_path, self.config.ollama_url, self.config.embedding_model
        )

        self.auxiliary: AuxiliaryClient | None = None
        if self.config.auxiliary_enabled:
            self.auxiliary = AuxiliaryClient(
                self.config.auxiliary_url, self.config.auxiliary_model,
                self.config.auxiliary_timeout,
            )

        self.compressor = ContextCompressor(
            auxiliary=self.auxiliary,
            max_context_tokens=self.config.max_context_tokens,
            reserve_for_response=self.config.reserve_for_response,
            compression_threshold=self.config.compression_threshold,
            protect_last_n=self.config.protect_last_n,
        )

        self.tools = ToolDispatcher(
            max_retries=self.config.tool_max_retries,
            timeout=self.config.tool_timeout,
            memory_store=self.memory,
        )

        self._lora_client: httpx.AsyncClient | None = None
        self._ollama_client: httpx.AsyncClient | None = None

        self._stats = {
            "total_turns": 0, "lora_calls": 0, "ollama_calls": 0,
            "tool_calls": 0, "compressions": 0, "errors": 0,
            "memories_extracted": 0,
        }

        logger.info(
            f"AdamEngine ready: lora={self.config.lora_url}, "
            f"ollama={self.config.ollama_url}/{self.config.ollama_model}, "
            f"aux={self.config.auxiliary_model if self.config.auxiliary_enabled else 'off'}"
        )

    async def _get_lora_client(self) -> httpx.AsyncClient:
        if self._lora_client is None or self._lora_client.is_closed:
            self._lora_client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.config.lora_timeout),
                limits=httpx.Limits(max_connections=3, max_keepalive_connections=2),
            )
        return self._lora_client

    async def _get_ollama_client(self) -> httpx.AsyncClient:
        if self._ollama_client is None or self._ollama_client.is_closed:
            self._ollama_client = httpx.AsyncClient(
                timeout=httpx.Timeout(self.config.ollama_timeout),
                limits=httpx.Limits(max_connections=3, max_keepalive_connections=2),
            )
        return self._ollama_client

    async def chat(
        self, message: str, session_id: str = None, context: dict = None,
    ) -> dict:
        """دردشة كاملة مع كل المميزات."""
        start = time.time()
        self._stats["total_turns"] += 1
        context = context or {}

        if not session_id:
            session_id = await self.session_manager.create_session(model=self.config.ollama_model)

        # recall memories
        ltm_context = ""
        try:
            ltm_context = await self.memory.recall_for_context(
                message, max_memories=5, max_chars=1500
            )
        except Exception as e:
            logger.warning(f"LTM recall failed: {e}")

        # history
        history = await self.session_manager.get_messages(session_id, limit=50)
        history.extend(context.get("history", []))

        # build messages
        messages = self._build_messages(message, history, context, ltm_context)

        # compress
        messages, comp_stats = await self.compressor.compress(messages)
        if comp_stats.get("compressed"):
            self._stats["compressions"] += 1
            logger.info(
                f"Context compressed: {comp_stats['original_tokens']}→"
                f"{comp_stats['compressed_tokens']} ({comp_stats['method']})"
            )

        # call LLM (LoRA first, then Ollama)
        response_text = None
        used_backend = None
        tokens_in = estimate_messages_tokens(messages)

        try:
            response_text = await self._call_lora(messages)
            used_backend = "lora"
            self._stats["lora_calls"] += 1
        except Exception as e:
            logger.warning(f"LoRA failed: {e}")
            self._stats["errors"] += 1

        if response_text is None:
            try:
                response_text = await self._call_ollama(messages)
                used_backend = "ollama"
                self._stats["ollama_calls"] += 1
            except Exception as e:
                logger.warning(f"Ollama failed: {e}")
                self._stats["errors"] += 1
                response_text = self._mock_response(message)
                used_backend = "mock"

        # extract + execute tool calls (مرة واحدة فقط، مش 4 دورات)
        tool_calls_made = []
        if "<tool_call>" in response_text:
            response_text, tool_calls_made = await self._process_tool_calls(
                response_text, message, session_id, messages
            )

        tokens_out = estimate_tokens(response_text)
        latency_ms = int((time.time() - start) * 1000)

        # save
        await self.session_manager.add_message(
            session_id, "user", message, tokens_in=tokens_in,
        )
        await self.session_manager.add_message(
            session_id, "assistant", response_text,
            tokens_out=tokens_out, latency_ms=latency_ms,
            tool_calls=tool_calls_made,
            metadata={"backend": used_backend, "compression": comp_stats, "ltm_used": bool(ltm_context)},
        )

        # auto-extract memories in background
        if self.config.auto_extract_memories and self.auxiliary and response_text:
            asyncio.create_task(self._auto_extract(message, response_text, session_id))

        # generate title
        if len(history) <= 1 and self.auxiliary:
            try:
                title = await self.auxiliary.generate_title(message, response_text)
                await self.session_manager.set_session_title(session_id, title)
            except Exception:
                pass

        return {
            "response": response_text,
            "session_id": session_id,
            "backend": used_backend,
            "tool_calls": tool_calls_made,
            "compression": comp_stats,
            "ltm_used": bool(ltm_context),
            "mode": "analyst",  # backward compat مع frontend
            "intent": {"mode": "analyst", "intent_type": "general"},
            "knowledge_used": len(ltm_context.split("\n")) if ltm_context else 0,
            "cycle": self._stats["total_turns"],
            "duration_ms": latency_ms,
            "audio_url": None,
            "usage": {
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
                "latency_ms": latency_ms,
            },
        }

    def _build_messages(
        self, user_message: str, history: list[dict], context: dict, ltm_context: str,
    ) -> list[dict]:
        """يبني messages مع حماية system prompt."""
        messages = [{"role": "system", "content": ADAM_SYSTEM_PROMPT}]

        # LTM context
        if ltm_context:
            messages.append({
                "role": "system",
                "content": f"## ذاكرة ذات صلة:\n{ltm_context}",
            })

        # history (آخر 20 رسالة)
        for msg in history[-20:]:
            role = msg.get("role", "user")
            content = msg.get("content", "")
            if isinstance(content, str) and content:
                messages.append({"role": role, "content": content})

        # attachments
        user_content = user_message
        attachments = context.get("attachments", [])
        for att in attachments:
            if att.get("type") == "file" and att.get("content"):
                user_content = (
                    f"--- FILE: {att.get('name', 'unknown')} ---\n"
                    f"{att['content'][:8000]}\n--- END FILE ---\n\n{user_content}"
                )
            elif att.get("type") == "image":
                user_content = f"[IMAGE: {att.get('name', 'image')}]\n{user_content}"

        messages.append({"role": "user", "content": user_content})
        return messages

    async def _call_lora(self, messages: list[dict]) -> str | None:
        """يستدعي LoRA server (gemma4 12b)."""
        client = await self._get_lora_client()
        last_exc = None

        # truncate (left-side — يقطع من أول المحادثة، مش من آخرها)
        if sum(len(m.get("content", "")) for m in messages) > self.config.lora_max_chars:
            messages = self._truncate_messages_left(messages, self.config.lora_max_chars)

        for attempt in range(self.config.lora_max_retries):
            try:
                resp = await client.post(
                    f"{self.config.lora_url}/chat",
                    json={"messages": messages},
                )
                resp.raise_for_status()
                data = resp.json()
                raw = data.get("response", "").strip()
                if not raw:
                    return None
                # clean tool_call + scratch_pad من الرد الظاهر
                clean = re.sub(r'<tool_call>\s*\{.*?\}\s*</tool_call>', '', raw, flags=re.DOTALL)
                clean = re.sub(r'<scratch_pad>.*?</scratch_pad>', '', clean, flags=re.DOTALL)
                return clean.strip() or raw.strip()
            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self.config.lora_max_retries - 1:
                    await asyncio.sleep(0.5 * (2 ** attempt))
            except Exception as e:
                logger.error(f"LoRA error: {e}")
                return None

        if last_exc:
            logger.error(f"LoRA failed after {self.config.lora_max_retries} attempts: {last_exc}")
        return None

    def _truncate_messages_left(self, messages: list[dict], max_chars: int) -> list[dict]:
        """يقطع من اليسار (أول المحادثة) عشان يحافظ على آخر رسالة user."""
        if not messages:
            return messages

        # امسك system + آخر 5 رسائل
        system = [m for m in messages if m["role"] == "system"]
        non_system = [m for m in messages if m["role"] != "system"]

        if len(non_system) <= 6:
            return messages

        # آخر 5 رسائل verbatim
        tail = non_system[-5:]
        head = non_system[:-5]

        # لخص الـ head في system message
        head_summary = "## ملخص المحادثة السابقة:\n"
        for m in head:
            content = m.get("content", "")[:300]
            head_summary += f"[{m['role']}]: {content}\n"

        result = system + [{"role": "system", "content": head_summary[:2000]}] + tail
        return result

    async def _call_ollama(self, messages: list[dict]) -> str | None:
        """يستدعي Ollama كـ fallback."""
        client = await self._get_ollama_client()
        headers = {}
        if self.config.ollama_api_key:
            headers["Authorization"] = f"Bearer {self.config.ollama_api_key}"

        resp = await client.post(
            f"{self.config.ollama_url}/api/chat",
            headers=headers,
            json={
                "model": self.config.ollama_model,
                "messages": messages,
                "stream": False,
            },
        )
        if resp.status_code == 200:
            data = resp.json()
            content = data.get("message", {}).get("content", "").strip()
            clean = re.sub(r'<tool_call>.*?</tool_call>', '', content, flags=re.DOTALL)
            clean = re.sub(r'<scratch_pad>.*?</scratch_pad>', '', clean, flags=re.DOTALL)
            return clean.strip() or content
        return None

    async def _process_tool_calls(
        self, response_text: str, user_message: str, session_id: str, messages: list[dict],
    ) -> tuple[str, list[dict]]:
        """يستخرج وينفذ tool call واحد فقط (مش 4 دورات)."""
        tool_calls_made = []
        pattern = r'<tool_call>\s*(\{.*?\})\s*</tool_call>'
        matches = re.findall(pattern, response_text, re.DOTALL)

        if not matches:
            return response_text, []

        # نفذ أول tool_call بس
        for match in matches[:self.config.max_tool_calls_per_turn]:
            try:
                tc = json.loads(match)
                tool_name = tc.get("name", "")
                tool_args = tc.get("arguments", {})

                logger.info(f"Tool call: {tool_name}({tool_args})")

                result = await self.tools.execute(tool_name, tool_args)
                self._stats["tool_calls"] += 1

                tool_calls_made.append({
                    "name": tool_name,
                    "arguments": tool_args,
                    "success": result.success,
                    "result": result.result,
                    "error": result.error,
                    "latency_ms": result.latency_ms,
                })

                # لو نجح، ابعت النتيجة للموديل في turn واحد
                if result.success:
                    try:
                        followup = messages + [
                            {"role": "assistant", "content": response_text},
                            {
                                "role": "user",
                                "content": (
                                    f"نتيجة الأداة {tool_name}:\n"
                                    f"{json.dumps(result.result, ensure_ascii=False, indent=2)[:2000]}\n\n"
                                    f"استخدم هذه النتيجة للرد على المستخدم."
                                ),
                            },
                        ]
                        followup_resp = await self._call_lora(followup)
                        if followup_resp:
                            response_text = re.sub(pattern, '', response_text, flags=re.DOTALL).strip()
                            response_text = followup_resp
                    except Exception as e:
                        logger.warning(f"Follow-up LLM call failed: {e}")
            except json.JSONDecodeError as e:
                logger.warning(f"Invalid tool_call JSON: {e}")
            except Exception as e:
                logger.exception(f"Tool execution error: {e}")

        # شيل tool_call syntax من الرد النهائي
        clean = re.sub(pattern, '', response_text, flags=re.DOTALL).strip()
        clean = re.sub(r'<scratch_pad>.*?</scratch_pad>', '', clean, flags=re.DOTALL).strip()
        return clean or response_text, tool_calls_made

    async def _auto_extract(self, user_msg: str, asst_msg: str, session_id: str):
        """يستخرج ذكريات في الخلفية."""
        try:
            ids = await self.memory.auto_extract_from_conversation(
                user_msg, asst_msg, session_id, self.auxiliary
            )
            self._stats["memories_extracted"] += len(ids)
        except Exception as e:
            logger.debug(f"Auto-extract failed: {e}")

    def _mock_response(self, message: str) -> str:
        if any(w in message.lower() for w in ["مرحبا", "أهلا", "hello", "hi"]):
            return "أهلاً بيك! للأسف الـ LLM مش متاح دلوقتي. تأكد إن Ollama أو LoRA server شغال."
        return (
            f"استلمت رسالتك: «{message[:100]}»\n\n"
            "للأسف الـ LLM مش متاح. تأكد إن:\n"
            "- LoRA server شغال على :7861 (gemma4 12b)\n"
            "- أو Ollama شغال على :11434"
        )

    async def health_check(self) -> dict:
        services = {"engine": True, "session_db": self.session_manager._conn is not None}

        # LoRA
        try:
            client = await self._get_lora_client()
            r = await client.get(f"{self.config.lora_url}/", timeout=2.0)
            services["lora"] = r.status_code in (200, 404, 405)
        except Exception:
            services["lora"] = False

        # Ollama
        try:
            client = await self._get_ollama_client()
            r = await client.get(f"{self.config.ollama_url}/api/tags", timeout=2.0)
            services["ollama"] = r.status_code == 200
        except Exception:
            services["ollama"] = False

        # Auxiliary
        if self.auxiliary:
            services["auxiliary"] = await self.auxiliary.health_check()
        else:
            services["auxiliary"] = False

        # Memory
        services["memory"] = self.memory._conn is not None
        services["embeddings"] = self.memory.embedding_client._available is True

        return {"status": "healthy" if all(services.values()) else "degraded", "services": services}

    def get_stats(self) -> dict:
        return dict(self._stats)

    async def cleanup(self):
        if self._lora_client and not self._lora_client.is_closed:
            await self._lora_client.aclose()
        if self._ollama_client and not self._ollama_client.is_closed:
            await self._ollama_client.aclose()
        if self.auxiliary:
            await self.auxiliary.cleanup()
        await self.tools.cleanup()
        self.memory.close()
        self.session_manager.close()


# ============================================================
# Singleton
# ============================================================

_engine: AdamEngine | None = None

def get_engine() -> AdamEngine:
    global _engine
    if _engine is None:
        _engine = AdamEngine()
    return _engine

async def cleanup_engine():
    global _engine
    if _engine:
        await _engine.cleanup()
        _engine = None
