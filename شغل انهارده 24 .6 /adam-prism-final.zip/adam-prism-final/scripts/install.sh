#!/usr/bin/env bash
# ============================================================
# Adam Prism — Auto Installer
# ============================================================
# بينزّل كل الـ dependencies + الموديلات المطلوبة
# شغّله مرة واحدة قبل أول تشغيل
# ============================================================

set -e

echo "╔══════════════════════════════════════════════════╗"
echo "║   Adam Prism — Auto Installer                    ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""

# 1. فحص Python
echo "─── 1. فحص Python ───"
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 مش متثبت. ثبّته الأول:"
    echo "   sudo apt install -y python3 python3-pip python3-venv"
    exit 1
fi
PYTHON_VERSION=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo "✅ Python $PYTHON_VERSION"

# 2. إنشاء virtual environment
echo ""
echo "─── 2. إنشاء virtual environment ───"
if [ ! -d "venv" ]; then
    python3 -m venv venv
    echo "✅ venv created"
else
    echo "ℹ️  venv موجود بالفعل"
fi
source venv/bin/activate

# 3. تثبيت Python dependencies
echo ""
echo "─── 3. تثبيت Python dependencies ───"
pip install --upgrade pip --quiet
pip install -r requirements.txt --quiet
echo "✅ Python dependencies مثبتة"

# 4. فحص Ollama
echo ""
echo "─── 4. فحص Ollama ───"
if ! command -v ollama &> /dev/null; then
    echo "⚠️  Ollama مش متثبت. جاري التثبيت..."
    curl -fsSL https://ollama.ai/install.sh | sh
    echo "✅ Ollama مثبت"
else
    echo "✅ Ollama متثبت"
fi

# 5. تشغيل Ollama في الخلفية لو مش شغال
echo ""
echo "─── 5. تشغيل Ollama ───"
if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
    echo "▶️  تشغيل Ollama في الخلفية..."
    ollama serve &
    OLLAMA_PID=$!
    echo "✅ Ollama started (PID: $OLLAMA_PID)"
    # ننتظر تبقى جاهزة
    for i in {1..30}; do
        if curl -s http://localhost:11434/api/tags &> /dev/null; then
            break
        fi
        sleep 1
    done
else
    echo "✅ Ollama شغال بالفعل"
fi

# 6. تثبيت الموديلات المطلوبة
echo ""
echo "─── 6. تثبيت الموديلات ───"

# Auxiliary model (مهم جداً)
if ! ollama list 2>/dev/null | grep -q "qwen2.5:0.5b"; then
    echo "⬇️  تثبيت qwen2.5:0.5b (500MB)..."
    ollama pull qwen2.5:0.5b
    echo "✅ qwen2.5:0.5b مثبت"
else
    echo "✅ qwen2.5:0.5b موجود"
fi

# Embedding model (مهم جداً)
if ! ollama list 2>/dev/null | grep -q "nomic-embed-text"; then
    echo "⬇️  تثبيت nomic-embed-text (280MB)..."
    ollama pull nomic-embed-text
    echo "✅ nomic-embed-text مثبت"
else
    echo "✅ nomic-embed-text موجود"
fi

# Fallback model
if ! ollama list 2>/dev/null | grep -q "qwen2.5:3b"; then
    echo "⬇️  تثبيت qwen2.5:3b (2GB) — fallback..."
    ollama pull qwen2.5:3b
    echo "✅ qwen2.5:3b مثبت"
else
    echo "✅ qwen2.5:3b موجود"
fi

# 7. إنشاء .env لو مش موجود
echo ""
echo "─── 7. إعداد .env ───"
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "✅ .env created from .env.example"
    echo "ℹ️  عدّله لو محتاج (خصوصاً LORA_SERVER_URL)"
else
    echo "✅ .env موجود"
fi

# 8. إنشاء مجلد البيانات
echo ""
echo "─── 8. إعداد مجلد البيانات ───"
mkdir -p ~/.adam
echo "✅ ~/.adam ready"

# 9. فحص PyMuPDF (اختياري للـ PDF)
echo ""
echo "─── 9. فحص PyMuPDF (اختياري) ───"
if python3 -c "import fitz" 2>/dev/null; then
    echo "✅ PyMuPDF متثبت — دعم PDF متاح"
else
    echo "⚠️  PyMuPDF مش متثبت — دعم PDF مش متاح"
    echo "   ثبّته بـ: pip install PyMuPDF"
fi

# 10. فحص Tesseract (اختياري للـ OCR)
echo ""
echo "─── 10. فحص Tesseract (اختياري للـ OCR) ───"
if command -v tesseract &> /dev/null; then
    echo "✅ Tesseract متثبت — دعم OCR متاح"
else
    echo "⚠️  Tesseract مش متثبت — OCR مش متاح"
    echo "   ثبّته بـ: sudo apt install -y tesseract-ocr tesseract-ocr-ara"
fi

# 11. اختبار سريع
echo ""
echo "─── 11. اختبار سريع ───"
python3 -c "
import sys
sys.path.insert(0, 'backend')
try:
    from adam.engine import AdamEngine, EngineConfig
    from adam.memory import MemoryStore
    from adam.tools import ToolDispatcher
    from adam.server import app
    print('✅ كل المكونات تشتغل')
except Exception as e:
    print(f'❌ خطأ: {e}')
    sys.exit(1)
"

# 12. تعليمات التشغيل
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║   ✅ التثبيت اكتمل بنجاح!                        ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║                                                  ║"
echo "║   للتشغيل:                                       ║"
echo "║     ./scripts/run.sh                             ║"
echo "║                                                  ║"
echo "║   أو يدوياً:                                     ║"
echo "║     source venv/bin/activate                     ║"
echo "║     export \$(cat .env | xargs)                   ║"
echo "║     cd backend                                   ║"
echo "║     uvicorn adam.server:app --port 8000          ║"
echo "║                                                  ║"
echo "║   تحقق:                                          ║"
echo "║     curl http://localhost:8000/healthz/live      ║"
echo "║                                                  ║"
echo "╚══════════════════════════════════════════════════╝"
