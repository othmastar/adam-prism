#!/usr/bin/env bash
# ============================================================
# Adam Prism — Runner
# ============================================================
# يشغّل الـ backend على :8000
# ============================================================

set -e

cd "$(dirname "$0")/.."

# فعّل venv
if [ -d "venv" ]; then
    source venv/bin/activate
fi

# فعّل env vars
if [ -f ".env" ]; then
    export $(grep -v '^#' .env | xargs)
fi

# اذهب للـ backend
cd backend

# شغّل
PORT=${PORT:-8000}
HOST=${HOST:-0.0.0.0}

echo "╔══════════════════════════════════════════════════╗"
echo "║   Adam Prism — Starting...                       ║"
echo "╠══════════════════════════════════════════════════╣"
echo "║   Host: $HOST                                     "
echo "║   Port: $PORT                                     "
echo "║   URL:  http://localhost:$PORT                    "
echo "║   Docs: http://localhost:$PORT/docs               "
echo "╚══════════════════════════════════════════════════╝"

# تحقق من Ollama
if ! curl -s http://localhost:11434/api/tags &> /dev/null; then
    echo "⚠️  Ollama مش شغّال. شغّله بـ: ollama serve &"
fi

# شغّل السيرفر
exec uvicorn adam.server:app --host "$HOST" --port "$PORT" --reload
